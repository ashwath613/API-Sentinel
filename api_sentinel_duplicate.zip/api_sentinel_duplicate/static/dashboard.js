
/* ---------------------------------------------------------------------
 1. CONFIG
 --------------------------------------------------------------------- */
const CONFIG = {
 API_BASE: "", // same-origin FastAPI backend; adjust if served from a different host
 HEALTH_ENDPOINTS: ["/health", "/api/v1/health"],
 SCANS_ENDPOINT: "/api/v1/scans/",
 POLL_INTERVAL_MS: 4000,
 CONN_CHECK_INTERVAL_MS: 30000,
 REQUEST_TIMEOUT_MS: 15000,
};
/* ---------------------------------------------------------------------
 2. UTILITIES
 --------------------------------------------------------------------- */
const Utils = (() => {
 function escapeHtml(value) {
 if (value === null || value === undefined) return "";
 return String(value)
 .replace(/&/g, "&amp;")
 .replace(/</g, "&lt;")
 .replace(/>/g, "&gt;")
 .replace(/"/g, "&quot;")
 .replace(/'/g, "&#39;");
 }
 function qs(selector, scope) { return (scope || document).querySelector(selector); }
 function qsa(selector, scope) { return Array.from((scope || document).querySelectorAll(selector)); }
 function debounce(fn, wait) {
 let t;
 return (...args) => {
 clearTimeout(t);
 t = setTimeout(() => fn(...args), wait);
 };
 }
 function formatDateTime(iso) {
 if (!iso) return "\u2014";
 const d = new Date(iso);
 if (isNaN(d.getTime())) return "\u2014";
 return d.toLocaleString(undefined, {
 year: "numeric", month: "short", day: "numeric",
 hour: "2-digit", minute: "2-digit",
 });
 }
 function formatRelative(iso) {

 if (!iso) return "\u2014";
 const d = new Date(iso);
 if (isNaN(d.getTime())) return "\u2014";
 const diffMs = Date.now() - d.getTime();
 const diffSec = Math.round(diffMs / 1000);
 if (diffSec < 60) return "just now";
 const diffMin = Math.round(diffSec / 60);
 if (diffMin < 60) return `${diffMin}m ago`;
 const diffHr = Math.round(diffMin / 60);
 if (diffHr < 24) return `${diffHr}h ago`;
 const diffDay = Math.round(diffHr / 24);
 return `${diffDay}d ago`;
 }
 function formatDuration(startIso, endIso) {
 if (!startIso || !endIso) return "\u2014";
 const start = new Date(startIso).getTime();
 const end = new Date(endIso).getTime();
 if (isNaN(start) || isNaN(end) || end < start) return "\u2014";
 const totalSec = Math.round((end - start) / 1000);
 if (totalSec < 60) return `${totalSec}s`;
 const min = Math.floor(totalSec / 60);
 const sec = totalSec % 60;
 if (min < 60) return `${min}m ${sec}s`;
 const hr = Math.floor(min / 60);
 return `${hr}h ${min % 60}m`;
 }
 function severityRank(sev) {
 const order = { CRITICAL: 0, HIGH: 1, MEDIUM: 2, LOW: 3 };
 return order[String(sev || "").toUpperCase()] ?? 9;
 }
 function severityClass(sev) {
 const s = String(sev || "").toUpperCase();
 if (s === "CRITICAL") return "critical";
 if (s === "HIGH") return "high";
 if (s === "MEDIUM") return "medium";
 if (s === "LOW") return "low";
 return "low";
 }
 function statusClass(status) {
 const s = String(status || "").toUpperCase();
 if (s === "COMPLETED") return "completed";
 if (s === "RUNNING") return "running";
 if (s === "QUEUED") return "queued";
 if (s === "FAILED") return "failed";
 return "queued";
 }
 function riskColorVar(score) {
 const n = Number(score) || 0;
 if (n >= 7) return "var(--sev-critical-text)";
 if (n >= 5) return "var(--sev-high-text)";
 if (n >= 3) return "var(--sev-medium-text)";
 return "var(--sev-low-text)";
 }
 function badgeHtml(label, kind) {
 return `<span class="badge badge-${kind}">${escapeHtml(label)}</span>`;
 }
 function severityBadge(sev) {
 const s = String(sev || "UNKNOWN").toUpperCase();
 return badgeHtml(s.charAt(0) + s.slice(1).toLowerCase(), severityClass(s));
 }
 function statusBadge(status) {
 const s = String(status || "UNKNOWN").toUpperCase();
 return `<span class="badge badge-status-${statusClass(s)}">${escapeHtml(s.charAt(0) + s.slice(1).toLowerCase())}</span>`;
 }
 function methodBadge(method) {
 return `<span class="badge badge-method">${escapeHtml(String(method || "\u2014").toUpperCase())}</span>`;
 }
 function riskGauge(score) {
 const n = Math.max(0, Math.min(10, Number(score) || 0));
 const pct = (n / 10) * 100;
 const color = riskColorVar(n);
 return `<div class="risk-gauge">
 <span class="risk-gauge-track"><span class="risk-gauge-fill" style="width:${pct}%;background:${color}"></span></span>
 <span class="risk-gauge-value">${n.toFixed(1)}</span>
 </div>`;
 }
 function confidencePct(conf) {
 const n = Number(conf);
 if (isNaN(n)) return "\u2014";
 return `${Math.round(n * 100)}%`;
 }
 return {
 escapeHtml, qs, qsa, debounce, formatDateTime, formatRelative, formatDuration,
 severityRank, severityClass, statusClass, riskColorVar,
 severityBadge, statusBadge, methodBadge, riskGauge, confidencePct,
 };
})();
/* ---------------------------------------------------------------------
 3. API CLIENT
 --------------------------------------------------------------------- */
const Api = (() => {
 async function request(path, options = {}) {
 const controller = new AbortController();
 const timeout = setTimeout(() => controller.abort(), CONFIG.REQUEST_TIMEOUT_MS);
 let response;
 try {
 response = await fetch(`${CONFIG.API_BASE}${path}`, {
 ...options,
 signal: controller.signal,
 headers: {
 Accept: "application/json",
 ...(options.headers || {}),
 },
 });
 } catch (err) {
 clearTimeout(timeout);
 if (err.name === "AbortError") {
 throw new ApiError("Request timed out. The backend may be unreachable.", 0);
 }
 throw new ApiError("Network error \u2014 could not reach the backend.", 0);
 }

 clearTimeout(timeout);
 if (!response.ok) {
 let detail = "";
 try {
 const body = await response.json();
 detail = body?.detail || body?.message || "";
 } catch (_) { /* non-JSON error body */ }
 const message = detail || `Request failed with status ${response.status}`;
 throw new ApiError(message, response.status);
 }
 if (response.status === 204) return null;
 try {
 return await response.json();
 } catch (_) {
 throw new ApiError("Received an invalid response from the backend.", response.status);
 }
 }
 class ApiError extends Error {
 constructor(message, status) {
 super(message);
 this.status = status;
 }
 }
 async function checkHealth() {
 for (const ep of CONFIG.HEALTH_ENDPOINTS) {
 try {
 const res = await fetch(`${CONFIG.API_BASE}${ep}`, { headers: { Accept: "application/json" } });
 if (res.ok) return { ok: true, source: ep };
 } catch (_) { /* try next */ }
 }
 // No dedicated health endpoint found — fall back to a lightweight reachability check.
 try {
 await request(CONFIG.SCANS_ENDPOINT);
 return { ok: true, source: CONFIG.SCANS_ENDPOINT, fallback: true };
 } catch (err) {
 return { ok: false, error: err };
 }
 }
 function listScans() {
 return request(CONFIG.SCANS_ENDPOINT);
 }
 function getScan(scanId) {
 return request(`/api/v1/scans/${scanId}`);
 }
 function getScanResults(scanId) {
 return request(`/api/v1/scans/${scanId}/results`);
 }
 function getScanSummary(scanId) {
 return request(`/api/v1/scans/${scanId}/summary`);
 }
 function getScanReport(scanId) {
 return request(`/api/v1/scans/${scanId}/report`);
 }
 function createScanFromUrl(target, openapiUrl) {
 const form = new FormData();
 form.append("target", target);

 form.append("openapi_url", openapiUrl);
 return request("/api/v1/scans/openapi-url", { method: "POST", body: form });
 }
 function createScanFromFile(target, file) {
 const form = new FormData();
 form.append("target", target);
 form.append("file", file);
 return request("/api/v1/scans/openapi", { method: "POST", body: form });
 }
 return {
 ApiError, checkHealth, listScans, getScan, getScanResults, getScanSummary, getScanReport,
 createScanFromUrl, createScanFromFile,
 };
})();
/* ---------------------------------------------------------------------
 4. STATE
 --------------------------------------------------------------------- */
const State = {
 route: { view: "dashboard", param: null },
 scansCache: null,
 scansCacheAt: 0,
 scanResultsCache: new Map(), // scanId -> results response
 scanSummaryCache: new Map(), // scanId -> summary response
 findingsFilters: { scan: "", severity: "", type: "", method: "", search: "", sort: "priority_score_desc" },
 endpointsFilterScan: "",
 pollTimers: new Map(),
 sidebarCollapsed: false,
};
function invalidateScanCaches(scanId) {
 State.scansCache = null;
 if (scanId) {
 State.scanResultsCache.delete(String(scanId));
 State.scanSummaryCache.delete(String(scanId));
 } else {
 State.scanResultsCache.clear();
 State.scanSummaryCache.clear();
 }
}
/* ---------------------------------------------------------------------
 5. DATA TRANSFORMS
 --------------------------------------------------------------------- */
function flattenFindings(resultsResponse) {
 if (!resultsResponse || !Array.isArray(resultsResponse.endpoints)) return [];
 const findings = [];
 for (const ep of resultsResponse.endpoints) {
 const vulns = Array.isArray(ep.vulnerabilities) ? ep.vulnerabilities : [];
 for (const v of vulns) {
 findings.push({
 id: v.id,
 type: v.type,
 severity: v.severity,
 description: v.description,
 evidence: v.evidence,
 confidence: v.confidence,
 priority_score: v.priority_score,
 detected_at: v.detected_at,
 endpoint: ep.path,
 method: ep.method,
 url: ep.url,
 endpoint_id: ep.id,
 scan_id: resultsResponse.id,
 scan_target: resultsResponse.target,
 });
 }
 }
 return findings;
}
async function getScanResultsCached(scanId) {
 const key = String(scanId);
 if (State.scanResultsCache.has(key)) return State.scanResultsCache.get(key);
 const results = await Api.getScanResults(scanId);
 State.scanResultsCache.set(key, results);
 return results;
}
async function getScanSummaryCached(scanId) {
 const key = String(scanId);
 if (State.scanSummaryCache.has(key)) return State.scanSummaryCache.get(key);
 const summary = await Api.getScanSummary(scanId);
 State.scanSummaryCache.set(key, summary);
 return summary;
}
async function getScansCached() {
 if (State.scansCache) return State.scansCache;
 const scans = await Api.listScans();
 const list = Array.isArray(scans) ? scans : (scans?.items || scans?.scans || []);
 State.scansCache = list;
 return list;
}
/* Aggregate findings across every scan (used by dashboard + global findings view) */
async function getAllFindingsAcrossScans() {
 const scans = await getScansCached();
 const completed = scans.filter((s) => String(s.status).toUpperCase() === "COMPLETED");
 const resultsList = await Promise.all(
 completed.map((s) => getScanResultsCached(s.id).catch(() => null))
 );
 let all = [];
 resultsList.forEach((r) => { if (r) all = all.concat(flattenFindings(r)); });
 return { findings: all, scans };
}
/* ---------------------------------------------------------------------
 6. TOASTS & ERROR BANNERS
 --------------------------------------------------------------------- */
function toast(message, type = "default") {
 const region = Utils.qs("#toastRegion");
 const el = document.createElement("div");
 el.className = `toast ${type === "error" ? "toast-error" : type === "success" ? "toast-success" : ""}`;
 el.textContent = message;
 region.appendChild(el);
 setTimeout(() => el.remove(), 4200);
}
function showBanner(bannerId, message, retryFn) {
 const el = document.getElementById(bannerId);

 if (!el) return;
 el.innerHTML = "";
 const span = document.createElement("span");
 span.textContent = message;
 el.appendChild(span);
 if (retryFn) {
 const btn = document.createElement("button");
 btn.className = "state-banner-retry";
 btn.textContent = "Retry";
 btn.addEventListener("click", retryFn);
 el.appendChild(btn);
 }
 el.hidden = false; }
function hideBanner(bannerId) {
 const el = document.getElementById(bannerId);
 if (el) el.hidden = true; }
function errorMessage(err) {
 if (err instanceof Api.ApiError) {
 if (err.status === 404) return "Not found. The record may have been removed.";
 if (err.status === 0) return err.message;
 if (err.status >= 500) return "The backend encountered an internal error. Please try again.";
 return err.message;
 }
 return "Something went wrong. Please try again."; }
/* ---------------------------------------------------------------------
 7. CONNECTION STATUS
 --------------------------------------------------------------------- */
async function refreshConnectionStatus() {
 const connDot = Utils.qs("#connDot");
 const connLabel = Utils.qs("#connLabel");
 const engineDot = Utils.qs("#engineStatusDot");
 const engineLabel = Utils.qs("#engineStatusLabel");
 connDot.className = "status-dot dot-pulse";
 connLabel.textContent = "Checking\u2026";
 const result = await Api.checkHealth();
 if (result.ok) {
 connDot.className = "status-dot dot-ok";
 connLabel.textContent = "Connected";
 engineDot.className = "status-dot dot-ok";
 engineLabel.textContent = result.fallback ? "Backend reachable" : "Engine online";
 } else {
 connDot.className = "status-dot dot-err";
 connLabel.textContent = "Disconnected";
 engineDot.className = "status-dot dot-err";
 engineLabel.textContent = "Backend unreachable";
 }
 const apiBaseEl = Utils.qs("#settingsApiBase");
 const healthEl = Utils.qs("#settingsHealth");
 if (apiBaseEl) apiBaseEl.textContent = CONFIG.API_BASE || window.location.origin;
 if (healthEl) healthEl.textContent = result.ok ? `OK (${result.source})` : "Unreachable"; }
/* ---------------------------------------------------------------------
 8. ROUTER
 --------------------------------------------------------------------- */

const ROUTE_TITLES = {
 dashboard: { title: "Dashboard", crumb: "API Sentinel" },
 scans: { title: "Scans", crumb: "API Sentinel / Scans" },
 "scan-detail": { title: "Scan detail", crumb: "API Sentinel / Scans / Detail" },
 endpoints: { title: "Endpoints", crumb: "API Sentinel / Endpoints" },
 "endpoint-detail": { title: "Endpoint detail", crumb: "API Sentinel / Endpoints / Detail" },
 vulnerabilities: { title: "Vulnerabilities", crumb: "API Sentinel / Vulnerabilities" },
 reports: { title: "Reports", crumb: "API Sentinel / Reports" },
 settings: { title: "Settings", crumb: "API Sentinel / Settings" },
};
function parseHash() {
 const hash = window.location.hash.replace(/^#\/?/, "");
 const [view, param] = hash.split("/");
 return { view: view || "dashboard", param: param || null };
}
function setActiveNav(view) {
 Utils.qsa(".nav-item").forEach((el) => {
 el.classList.toggle("is-active", el.dataset.route === view);
 });
}
function showView(viewKey) {
 Utils.qsa(".view").forEach((el) => el.classList.remove("is-active"));
 const target = document.getElementById(`view-${viewKey}`);
 if (target) target.classList.add("is-active");
}
async function router() {
 const { view, param } = parseHash();
 State.route = { view, param };
 const knownViews = ["dashboard", "scans", "scan-detail", "endpoints", "endpoint-detail", "vulnerabilities", "reports", "settings"];
 const resolvedView = knownViews.includes(view) ? view : "not-found";
 showView(resolvedView);
 setActiveNav(view);
 const meta = ROUTE_TITLES[view] || { title: "Not found", crumb: "API Sentinel" };
 Utils.qs("#pageTitle").textContent = meta.title;
 Utils.qs("#breadcrumb").innerHTML = `<span>${Utils.escapeHtml(meta.crumb)}</span>`;
 switch (resolvedView) {
 case "dashboard": await loadDashboard(); break;
 case "scans": await loadScansList(); break;
 case "scan-detail": await loadScanDetail(param); break;
 case "endpoints": await loadEndpointsView(); break;
 case "endpoint-detail": await loadEndpointDetail(param); break;
 case "vulnerabilities": await loadFindingsView(); break;
 case "reports": await loadReportsView(); break;
 case "settings": /* static view */ break;
 default: break;
 }
}
function navigate(hash) {
 window.location.hash = hash;
}
/* ---------------------------------------------------------------------
 9. DASHBOARD VIEW
 --------------------------------------------------------------------- */
async function loadDashboard() {

 hideBanner("dashboardError");
 renderMetricSkeletons();
 Utils.qs("#latestScanBody").innerHTML = '<div class="skeleton-block"></div>';
 Utils.qs("#severityDistBody").innerHTML = '<div class="skeleton-block"></div>';
 Utils.qs("#topRisksBody").innerHTML = '<div class="skeleton-block"></div>';
 Utils.qs("#recentScansBody").innerHTML = '<div class="skeleton-block"></div>';
 try {
 const scans = await getScansCached();
 renderRecentScans(scans);
 if (!scans.length) {
 renderMetricGrid({ total_endpoints: 0, total_vulnerabilities: 0, critical_count: 0, high_count: 0, medium_count: 0, low_count: 0, highest_risk_score: 0 });
 Utils.qs("#latestScanBody").innerHTML = emptyStateHtml("No scans yet", "Create your first API security scan to begin.", true);
 Utils.qs("#severityDistBody").innerHTML = emptyStateHtml("No data yet", "Severity distribution appears once a scan completes.", false);
 Utils.qs("#topRisksBody").innerHTML = emptyStateHtml("No findings yet", "Top risks will appear once a scan completes.", false);
 return;
 }
 const sorted = [...scans].sort((a, b) => new Date(b.started_at || 0) - new Date(a.started_at || 0));
 const latest = sorted[0];
 const latestCompleted = sorted.find((s) => String(s.status).toUpperCase() === "COMPLETED") || latest;
 renderLatestScan(latest);
 if (String(latestCompleted.status).toUpperCase() === "COMPLETED") {
 const summary = await getScanSummaryCached(latestCompleted.id);
 renderMetricGrid(summary);
 renderSeverityDist(summary);
 const results = await getScanResultsCached(latestCompleted.id);
 const findings = flattenFindings(results).sort((a, b) => (b.priority_score || 0) - (a.priority_score || 0)).slice(0, 8);
 renderTopRisksTable(findings);
 } else {
 renderMetricGrid({ total_endpoints: 0, total_vulnerabilities: 0, critical_count: 0, high_count: 0, medium_count: 0, low_count: 0, highest_risk_score: 0 });
 Utils.qs("#severityDistBody").innerHTML = emptyStateHtml("Scan in progress", "Severity data will appear once the latest scan completes.", false);
 Utils.qs("#topRisksBody").innerHTML = emptyStateHtml("Scan in progress", "Top risks will appear once the latest scan completes.", false);
 }
 } catch (err) {
 showBanner("dashboardError", errorMessage(err), () => loadDashboard());
 Utils.qs("#latestScanBody").innerHTML = "";
 Utils.qs("#severityDistBody").innerHTML = "";
 Utils.qs("#topRisksBody").innerHTML = "";
 Utils.qs("#recentScansBody").innerHTML = "";
 }
}
function renderMetricSkeletons() {
 const grid = Utils.qs("#metricGrid");
 grid.innerHTML = Array.from({ length: 7 }).map(() =>
 `<div class="metric-card"><div class="skeleton-block" style="height:16px;margin:0 0 8px;"></div><div class="skeleton-block" style="height:26px;margin:0;"></div></div>`
 ).join("");
}
function renderMetricGrid(summary) {
 const metrics = [
 { label: "Total endpoints", value: summary.total_endpoints ?? 0, cls: "" },
 { label: "Total findings", value: summary.total_vulnerabilities ?? 0, cls: "" },
 { label: "Critical", value: summary.critical_count ?? 0, cls: "metric-critical" },
 { label: "High", value: summary.high_count ?? 0, cls: "metric-high" },
 { label: "Medium", value: summary.medium_count ?? 0, cls: "metric-medium" },
 { label: "Low", value: summary.low_count ?? 0, cls: "metric-low" },
 { label: "Highest risk score", value: (summary.highest_risk_score ?? 0).toFixed ? summary.highest_risk_score.toFixed(1) : summary.highest_risk_score, cls: "" },

 ];
 Utils.qs("#metricGrid").innerHTML = metrics.map((m) => `
 <div class="metric-card ${m.cls}">
 <span class="metric-card-label">${Utils.escapeHtml(m.label)}</span>
 <span class="metric-card-value">${Utils.escapeHtml(String(m.value))}</span>
 </div>
 `).join("");
}
function renderLatestScan(scan) {
 const duration = Utils.formatDuration(scan.started_at, scan.completed_at);
 Utils.qs("#latestScanBody").innerHTML = `
 <div class="latest-scan">
 <div class="latest-scan-top">
 <span class="latest-scan-target">${Utils.escapeHtml(scan.target || "Untitled target")}</span>
 ${Utils.statusBadge(scan.status)}
 </div>
 <dl class="latest-scan-meta">
 <div><dt>Scan ID</dt><dd class="mono">${Utils.escapeHtml(scan.id)}</dd></div>
 <div><dt>Input type</dt><dd>${Utils.escapeHtml(scan.input_type || "\u2014")}</dd></div>
 <div><dt>Started</dt><dd>${Utils.formatDateTime(scan.started_at)}</dd></div>
 <div><dt>Completed</dt><dd>${Utils.formatDateTime(scan.completed_at)}</dd></div>
 <div><dt>Duration</dt><dd>${duration}</dd></div>
 </dl>
 <div>
 <a class="btn btn-secondary" href="#/scans/${scan.id}">View scan</a>
 </div>
 </div>
 `;
}
function renderSeverityDist(summary) {
 const total = (summary.critical_count || 0) + (summary.high_count || 0) + (summary.medium_count || 0) + (summary.low_count || 0);
 const pct = (n) => (total ? (n / total) * 100 : 0);
 const rows = [
 ["Critical", summary.critical_count || 0, "sev-seg-critical", "var(--sev-critical-text)"],
 ["High", summary.high_count || 0, "sev-seg-high", "var(--sev-high-text)"],
 ["Medium", summary.medium_count || 0, "sev-seg-medium", "var(--sev-medium-text)"],
 ["Low", summary.low_count || 0, "sev-seg-low", "var(--sev-low-border)"],
 ];
 Utils.qs("#severityDistBody").innerHTML = `
 <div class="sev-dist">
 <div class="sev-dist-bar">
 ${rows.map(([, n, cls]) => n ? `<span class="${cls}" style="width:${pct(n)}%"></span>` : "").join("")}
 </div>
 <div class="sev-dist-legend">
 ${rows.map(([label, n, , color]) => `
 <div class="sev-dist-row">
 <span class="sev-dist-row-label"><span class="sev-dist-swatch" style="background:${color}"></span>${label}</span>
 <span class="sev-dist-row-value">${n}</span>
 </div>
 `).join("")}
 </div>
 </div>
 `;
}
function renderTopRisksTable(findings) {
 if (!findings.length) {
 Utils.qs("#topRisksBody").innerHTML = emptyStateHtml("No vulnerabilities detected", "This scan did not surface any findings.", false);

 return;
 }
 Utils.qs("#topRisksBody").innerHTML = `
 <div class="data-table-wrap">
 <table class="data-table">
 <thead><tr>
 <th>Severity</th><th>Vulnerability</th><th>Method</th><th>Endpoint</th><th>Confidence</th><th>Risk score</th>
 </tr></thead>
 <tbody>
 ${findings.map((f) => `
 <tr class="is-clickable" data-finding='${Utils.escapeHtml(JSON.stringify(f))}'>
 <td>${Utils.severityBadge(f.severity)}</td>
 <td class="cell-mono">${Utils.escapeHtml(f.type)}</td>
 <td>${Utils.methodBadge(f.method)}</td>
 <td class="cell-mono">${Utils.escapeHtml(f.endpoint)}</td>
 <td class="cell-num">${Utils.confidencePct(f.confidence)}</td>
 <td>${Utils.riskGauge(f.priority_score)}</td>
 </tr>
 `).join("")}
 </tbody>
 </table>
 </div>
 `;
 wireFindingRowClicks(Utils.qs("#topRisksBody"));
}
function renderRecentScans(scans) {
 if (!scans.length) {
 Utils.qs("#recentScansBody").innerHTML = emptyStateHtml("No scans yet", "Create your first API security scan to begin.", true);
 return;
 }
 const sorted = [...scans].sort((a, b) => new Date(b.started_at || 0) - new Date(a.started_at || 0)).slice(0, 6);
 Utils.qs("#recentScansBody").innerHTML = buildScansTable(sorted);
 wireScanRowClicks(Utils.qs("#recentScansBody"));
}
function emptyStateHtml(title, body, showAction) {
 return `
 <div class="empty-state">
 <p class="empty-state-title">${Utils.escapeHtml(title)}</p>
 <p class="empty-state-body">${Utils.escapeHtml(body)}</p>
 ${showAction ? `<button class="btn btn-primary" id="emptyStateNewScanBtn">New scan</button>` : ""}
 </div>
 `;
}
/* ---------------------------------------------------------------------
 10. SCANS LIST VIEW
 --------------------------------------------------------------------- */
function buildScansTable(scans) {
 return `
 <div class="data-table-wrap">
 <table class="data-table">
 <thead><tr>
 <th>Scan ID</th><th>Target</th><th>Input type</th><th>Status</th><th>Started</th><th>Completed</th><th></th>
 </tr></thead>
 <tbody>
 ${scans.map((s) => `
 <tr class="is-clickable" data-scan-id="${Utils.escapeHtml(s.id)}">
 <td class="cell-mono">#${Utils.escapeHtml(s.id)}</td>
 <td>${Utils.escapeHtml(s.target || "\u2014")}</td>
 <td>${Utils.escapeHtml(s.input_type || "\u2014")}</td>
 <td>${Utils.statusBadge(s.status)}</td>
 <td class="cell-muted">${Utils.formatDateTime(s.started_at)}</td>
 <td class="cell-muted">${Utils.formatDateTime(s.completed_at)}</td>
 <td class="cell-actions"><a class="btn btn-ghost" href="#/scans/${Utils.escapeHtml(s.id)}">View</a></td>
 </tr>
 `).join("")}
 </tbody>
 </table>
 </div>
 `;
}
function wireScanRowClicks(scope) {
 Utils.qsa("tr[data-scan-id]", scope).forEach((row) => {
 row.addEventListener("click", (e) => {
 if (e.target.closest("a, button")) return;
 navigate(`#/scans/${row.dataset.scanId}`);
 });
 });
 const emptyBtn = Utils.qs("#emptyStateNewScanBtn", scope);
 if (emptyBtn) emptyBtn.addEventListener("click", () => openNewScanModal());
}
async function loadScansList() {
 hideBanner("scansError");
 Utils.qs("#scansTableBody").innerHTML = '<div class="skeleton-block"></div>';
 try {
 invalidateScanCaches();
 const scans = await getScansCached();
 if (!scans.length) {
 Utils.qs("#scansTableBody").innerHTML = emptyStateHtml("No scans yet", "Create your first API security scan to begin.", true);
 wireScanRowClicks(Utils.qs("#scansTableBody"));
 return;
 }
 const sorted = [...scans].sort((a, b) => new Date(b.started_at || 0) - new Date(a.started_at || 0));
 Utils.qs("#scansTableBody").innerHTML = buildScansTable(sorted);
 wireScanRowClicks(Utils.qs("#scansTableBody"));
 } catch (err) {
 showBanner("scansError", errorMessage(err), () => loadScansList());
 Utils.qs("#scansTableBody").innerHTML = "";
 }
}
/* ---------------------------------------------------------------------
 11. SCAN DETAIL VIEW
 --------------------------------------------------------------------- */
async function loadScanDetail(scanId) {
 hideBanner("scanDetailError");
 const container = Utils.qs("#scanDetailContent");
 container.innerHTML = '<div class="skeleton-block"></div>';
 if (!scanId) {
 showBanner("scanDetailError", "No scan ID provided.");
 container.innerHTML = "";
 return;
 }
 try {
 const scan = await Api.getScan(scanId);

 const isCompleted = String(scan.status).toUpperCase() === "COMPLETED";
 const isFailed = String(scan.status).toUpperCase() === "FAILED";
 let summary = null;
 let results = null;
 if (isCompleted) {
 [summary, results] = await Promise.all([
 getScanSummaryCached(scanId).catch(() => null),
 getScanResultsCached(scanId).catch(() => null),
 ]);
 }
 const findings = results ? flattenFindings(results) : [];
 const duration = Utils.formatDuration(scan.started_at, scan.completed_at);
 container.innerHTML = `
 <div class="panel">
 <div class="panel-header">
 <h2>${Utils.escapeHtml(scan.target || "Untitled target")}</h2>
 ${Utils.statusBadge(scan.status)}
 </div>
 <div class="panel-body">
 <dl class="kv-list">
 <div><dt>Scan ID</dt><dd class="mono">#${Utils.escapeHtml(scan.id)}</dd></div>
 <div><dt>Input type</dt><dd>${Utils.escapeHtml(scan.input_type || "\u2014")}</dd></div>
 <div><dt>Started</dt><dd>${Utils.formatDateTime(scan.started_at)}</dd></div>
 <div><dt>Completed</dt><dd>${Utils.formatDateTime(scan.completed_at)}</dd></div>
 <div><dt>Duration</dt><dd>${duration}</dd></div>
 <div><dt>Total endpoints</dt><dd>${summary ? summary.total_endpoints ?? "\u2014" : "\u2014"}</dd></div>
 <div><dt>Total findings</dt><dd>${summary ? summary.total_vulnerabilities ?? "\u2014" : "\u2014"}</dd></div>
 <div><dt>Highest risk score</dt><dd>${summary ? (summary.highest_risk_score ?? "\u2014") : "\u2014"}</dd></div>
 </dl>
 ${isFailed ? `<div class="state-banner state-banner-error" style="margin-top:14px;">This scan failed to complete. Check backend logs for details.</div>` : ""}
 ${!isCompleted && !isFailed ? `<div class="coming-soon" style="margin-top:14px;"><span class="coming-soon-badge">${Utils.escapeHtml(scan.status)}</span>Results will
appear once this scan finishes running.</div>` : ""}
 </div>
 </div>
 <div class="tabs" role="tablist">
 <button class="tab-btn is-active" data-tab="overview">Overview</button>
 <button class="tab-btn" data-tab="findings">Findings ${findings.length ? `(${findings.length})` : ""}</button>
 <button class="tab-btn" data-tab="endpoints">Endpoints ${results?.endpoints?.length ? `(${results.endpoints.length})` : ""}</button>
 <button class="tab-btn" data-tab="timeline">Timeline</button>
 </div>
 <div class="tab-panel is-active" data-tab-panel="overview">
 ${summary ? `<div class="panel"><div class="panel-header"><h2>Severity distribution</h2></div><div class="panel-body" id="scanDetailSevDist"></div></div>` : `<div
class="panel"><div class="panel-body">${emptyStateHtml("No summary yet", "This scan has not produced summary data.", false)}</div></div>`}
 </div>
 <div class="tab-panel" data-tab-panel="findings">
 <div class="panel"><div class="panel-body panel-body-flush" id="scanDetailFindings"></div></div>
 </div>
 <div class="tab-panel" data-tab-panel="endpoints">
 <div class="panel"><div class="panel-body panel-body-flush" id="scanDetailEndpoints"></div></div>
 </div>
 <div class="tab-panel" data-tab-panel="timeline">
 <div class="panel"><div class="panel-body" id="scanDetailTimeline"></div></div>
 </div>
 `;

 if (summary) {
 const temp = document.createElement("div");
 document.body.appendChild(temp);
 const originalTarget = "#severityDistBody";
 // reuse renderSeverityDist by targeting the scan-detail element
 Utils.qs("#scanDetailSevDist").innerHTML = "";
 renderSeverityDistInto("#scanDetailSevDist", summary);
 temp.remove();
 }
 const findingsHost = Utils.qs("#scanDetailFindings");
 if (findings.length) {
 const sortedFindings = [...findings].sort((a, b) => (b.priority_score || 0) - (a.priority_score || 0));
 findingsHost.innerHTML = buildFindingsTable(sortedFindings);
 wireFindingRowClicks(findingsHost);
 } else {
 findingsHost.innerHTML = emptyStateHtml("No vulnerabilities detected", "This scan did not surface any findings.", false);
 }
 const endpointsHost = Utils.qs("#scanDetailEndpoints");
 if (results?.endpoints?.length) {
 endpointsHost.innerHTML = buildEndpointsTable(results.endpoints, scan);
 wireEndpointRowClicks(endpointsHost, scan.id);
 } else {
 endpointsHost.innerHTML = emptyStateHtml("No endpoints discovered", "This scan did not discover any endpoints.", false);
 }
 Utils.qs("#scanDetailTimeline").innerHTML = `
 <dl class="kv-list">
 <div><dt>Queued / started</dt><dd>${Utils.formatDateTime(scan.started_at)}</dd></div>
 <div><dt>Completed</dt><dd>${Utils.formatDateTime(scan.completed_at)}</dd></div>
 <div><dt>Total duration</dt><dd>${duration}</dd></div>
 </dl>
 `;
 Utils.qsa(".tab-btn", container).forEach((btn) => {
 btn.addEventListener("click", () => {
 Utils.qsa(".tab-btn", container).forEach((b) => b.classList.remove("is-active"));
 Utils.qsa(".tab-panel", container).forEach((p) => p.classList.remove("is-active"));
 btn.classList.add("is-active");
 Utils.qs(`.tab-panel[data-tab-panel="${btn.dataset.tab}"]`, container).classList.add("is-active");
 });
 });
 if (!isCompleted && !isFailed) {
 pollScanUntilDone(scanId, () => loadScanDetail(scanId));
 }
 } catch (err) {
 showBanner("scanDetailError", errorMessage(err), () => loadScanDetail(scanId));
 container.innerHTML = "";
 }
}
function renderSeverityDistInto(selector, summary) {
 const total = (summary.critical_count || 0) + (summary.high_count || 0) + (summary.medium_count || 0) + (summary.low_count || 0);
 const pct = (n) => (total ? (n / total) * 100 : 0);
 const rows = [
 ["Critical", summary.critical_count || 0, "sev-seg-critical", "var(--sev-critical-text)"],
 ["High", summary.high_count || 0, "sev-seg-high", "var(--sev-high-text)"],
 ["Medium", summary.medium_count || 0, "sev-seg-medium", "var(--sev-medium-text)"],
 ["Low", summary.low_count || 0, "sev-seg-low", "var(--sev-low-border)"],
 ];

 Utils.qs(selector).innerHTML = `
 <div class="sev-dist">
 <div class="sev-dist-bar">${rows.map(([, n, cls]) => n ? `<span class="${cls}" style="width:${pct(n)}%"></span>` : "").join("")}</div>
 <div class="sev-dist-legend">
 ${rows.map(([label, n, , color]) => `
 <div class="sev-dist-row">
 <span class="sev-dist-row-label"><span class="sev-dist-swatch" style="background:${color}"></span>${label}</span>
 <span class="sev-dist-row-value">${n}</span>
 </div>
 `).join("")}
 </div>
 </div>
 `;
}
/* ---------------------------------------------------------------------
 12. ENDPOINTS VIEW
 --------------------------------------------------------------------- */
function buildEndpointsTable(endpoints, scan) {
 return `
 <div class="data-table-wrap">
 <table class="data-table">
 <thead><tr>
 <th>Method</th><th>Path</th><th>URL</th><th>Findings</th><th>Highest risk</th><th>Discovered</th>
 </tr></thead>
 <tbody>
 ${endpoints.map((ep) => {
 const vulns = ep.vulnerabilities || [];
 const highest = vulns.reduce((max, v) => Math.max(max, v.priority_score || 0), 0);
 return `
 <tr class="is-clickable" data-endpoint-id="${Utils.escapeHtml(ep.id)}" data-scan-id="${Utils.escapeHtml(scan.id)}">
 <td>${Utils.methodBadge(ep.method)}</td>
 <td class="cell-mono">${Utils.escapeHtml(ep.path)}</td>
 <td class="cell-mono cell-muted">${Utils.escapeHtml(ep.url || "\u2014")}</td>
 <td class="cell-num">${vulns.length}</td>
 <td>${vulns.length ? Utils.riskGauge(highest) : "\u2014"}</td>
 <td class="cell-muted">${Utils.formatDateTime(ep.discovered_at)}</td>
 </tr>
 `;
 }).join("")}
 </tbody>
 </table>
 </div>
 `;
}
function wireEndpointRowClicks(scope, scanId) {
 Utils.qsa("tr[data-endpoint-id]", scope).forEach((row) => {
 row.addEventListener("click", () => {
 navigate(`#/endpoints/${row.dataset.endpointId}__${row.dataset.scanId || scanId}`);
 });
 });
}
async function populateEndpointsScanFilter(selectEl) {
 const scans = await getScansCached();
 const completed = scans.filter((s) => String(s.status).toUpperCase() === "COMPLETED");
 const current = selectEl.value;
 selectEl.innerHTML = `<option value="">Select a scan\u2026</option>` +
 completed.map((s) => `<option value="${Utils.escapeHtml(s.id)}">#${Utils.escapeHtml(s.id)} \u2014 ${Utils.escapeHtml(s.target || "Untitled")}</option>`).join("");

 if (current) selectEl.value = current;
 return completed;
}
async function loadEndpointsView() {
 hideBanner("endpointsError");
 const select = Utils.qs("#endpointsScanFilter");
 try {
 await populateEndpointsScanFilter(select);
 if (State.endpointsFilterScan) {
 select.value = State.endpointsFilterScan;
 await renderEndpointsForScan(State.endpointsFilterScan);
 }
 } catch (err) {
 showBanner("endpointsError", errorMessage(err), () => loadEndpointsView());
 }
}
async function renderEndpointsForScan(scanId) {
 const host = Utils.qs("#endpointsTableBody");
 if (!scanId) {
 host.innerHTML = `<div class="empty-state"><p class="empty-state-title">Select a scan</p><p class="empty-state-body">Choose a scan above to view its discovered
endpoints.</p></div>`;
 return;
 }
 host.innerHTML = '<div class="skeleton-block"></div>';
 try {
 const [results, scan] = await Promise.all([getScanResultsCached(scanId), Api.getScan(scanId)]);
 if (!results.endpoints?.length) {
 host.innerHTML = emptyStateHtml("No endpoints discovered", "This scan did not discover any endpoints.", false);
 return;
 }
 host.innerHTML = buildEndpointsTable(results.endpoints, scan);
 wireEndpointRowClicks(host, scanId);
 } catch (err) {
 showBanner("endpointsError", errorMessage(err), () => renderEndpointsForScan(scanId));
 host.innerHTML = "";
 }
}
async function loadEndpointDetail(compositeId) {
 const container = Utils.qs("#endpointDetailContent");
 container.innerHTML = '<div class="skeleton-block"></div>';
 if (!compositeId || !compositeId.includes("__")) {
 container.innerHTML = emptyStateHtml("Endpoint not found", "This endpoint reference is invalid.", false);
 return;
 }
 const [endpointId, scanId] = compositeId.split("__");
 try {
 const results = await getScanResultsCached(scanId);
 const ep = (results.endpoints || []).find((e) => String(e.id) === String(endpointId));
 if (!ep) {
 container.innerHTML = emptyStateHtml("Endpoint not found", "This endpoint may have been removed.", false);
 return;
 }
 const vulns = ep.vulnerabilities || [];
 container.innerHTML = `
 <div class="panel">
 <div class="panel-header">
 <h2>${Utils.methodBadge(ep.method)} <span class="mono" style="margin-left:8px;">${Utils.escapeHtml(ep.path)}</span></h2>

 </div>
 <div class="panel-body">
 <dl class="kv-list">
 <div><dt>URL</dt><dd class="mono">${Utils.escapeHtml(ep.url || "\u2014")}</dd></div>
 <div><dt>Discovered</dt><dd>${Utils.formatDateTime(ep.discovered_at)}</dd></div>
 <div><dt>Findings</dt><dd>${vulns.length}</dd></div>
 </dl>
 ${ep.request_metadata ? `<div class="finding-section" style="margin-top:16px;"><h3>Request metadata</h3><div
class="evidence-block">${Utils.escapeHtml(JSON.stringify(ep.request_metadata, null, 2))}</div></div>` : ""}
 </div>
 </div>
 <div class="panel">
 <div class="panel-header"><h2>Vulnerabilities</h2></div>
 <div class="panel-body panel-body-flush">
 ${vulns.length ? buildFindingsTable(vulns.map((v) => ({ ...v, endpoint: ep.path, method: ep.method, url: ep.url, scan_id: scanId, scan_target: results.target }))) :
emptyStateHtml("No vulnerabilities detected", "This endpoint has no associated findings.", false)}
 </div>
 </div>
 `;
 wireFindingRowClicks(container);
 } catch (err) {
 showBanner("endpointDetailContent", errorMessage(err));
 container.innerHTML = `<div class="state-banner state-banner-error">${Utils.escapeHtml(errorMessage(err))}</div>`;
 }
}
/* ---------------------------------------------------------------------
 13. FINDINGS / VULNERABILITIES VIEW
 --------------------------------------------------------------------- */
function buildFindingsTable(findings) {
 if (!findings.length) {
 return emptyStateHtml("No vulnerabilities detected", "No findings match the current filters.", false);
 }
 return `
 <div class="data-table-wrap">
 <table class="data-table">
 <thead><tr>
 <th>Severity</th><th>Vulnerability</th><th>Method</th><th>Endpoint</th><th>Confidence</th><th>Risk score</th><th>Detected</th><th></th>
 </tr></thead>
 <tbody>
 ${findings.map((f) => `
 <tr class="is-clickable" data-finding='${Utils.escapeHtml(JSON.stringify(f))}'>
 <td>${Utils.severityBadge(f.severity)}</td>
 <td class="cell-mono">${Utils.escapeHtml(f.type)}</td>
 <td>${Utils.methodBadge(f.method)}</td>
 <td>
 <div class="path-cell">
 <span class="path-cell-path">${Utils.escapeHtml(f.endpoint)}</span>
 ${f.scan_target ? `<span class="path-cell-target">${Utils.escapeHtml(f.scan_target)}</span>` : ""}
 </div>
 </td>
 <td class="cell-num">${Utils.confidencePct(f.confidence)}</td>
 <td>${Utils.riskGauge(f.priority_score)}</td>
 <td class="cell-muted">${Utils.formatRelative(f.detected_at)}</td>
 <td class="cell-actions"><button class="btn btn-ghost">View</button></td>
 </tr>
 `).join("")}
 </tbody>
 </table>

 </div>
 `;
}
function wireFindingRowClicks(scope) {
 Utils.qsa("tr[data-finding]", scope).forEach((row) => {
 row.addEventListener("click", () => {
 try {
 const finding = JSON.parse(row.dataset.finding.replace(/&quot;/g, '"').replace(/&amp;/g, "&").replace(/&#39;/g, "'").replace(/&lt;/g, "<").replace(/&gt;/g, ">"));
 openFindingModal(finding);
 } catch (_) {
 openFindingModal(JSON.parse(row.getAttribute("data-finding")));
 }
 });
 });
}
async function populateFindingsFilterOptions(findings) {
 const scanSelect = Utils.qs("#findingsScanFilter");
 const scans = await getScansCached();
 const completed = scans.filter((s) => String(s.status).toUpperCase() === "COMPLETED");
 const currentScan = scanSelect.value;
 scanSelect.innerHTML = `<option value="">All scans</option>` +
 completed.map((s) => `<option value="${Utils.escapeHtml(s.id)}">#${Utils.escapeHtml(s.id)} \u2014 ${Utils.escapeHtml(s.target || "Untitled")}</option>`).join("");
 if (currentScan) scanSelect.value = currentScan;
 const typeSelect = Utils.qs("#findingsTypeFilter");
 const types = Array.from(new Set(findings.map((f) => f.type))).sort();
 const currentType = typeSelect.value;
 typeSelect.innerHTML = `<option value="">All types</option>` + types.map((t) => `<option value="${Utils.escapeHtml(t)}">${Utils.escapeHtml(t)}</option>`).join("");
 if (currentType) typeSelect.value = currentType;
 const methodSelect = Utils.qs("#findingsMethodFilter");
 const methods = Array.from(new Set(findings.map((f) => f.method))).sort();
 const currentMethod = methodSelect.value;
 methodSelect.innerHTML = `<option value="">All methods</option>` + methods.map((m) => `<option value="${Utils.escapeHtml(m)}">${Utils.escapeHtml(m)}</option>`).join("");
 if (currentMethod) methodSelect.value = currentMethod;
}
let AllFindingsCache = null;
async function loadFindingsView() {
 hideBanner("findingsError");
 Utils.qs("#findingsTableBody").innerHTML = '<div class="skeleton-block"></div>';
 try {
 const { findings } = await getAllFindingsAcrossScans();
 AllFindingsCache = findings;
 await populateFindingsFilterOptions(findings);
 applyFindingsFiltersAndRender();
 } catch (err) {
 showBanner("findingsError", errorMessage(err), () => loadFindingsView());
 Utils.qs("#findingsTableBody").innerHTML = "";
 }
}
function applyFindingsFiltersAndRender() {
 if (!AllFindingsCache) return;
 const f = State.findingsFilters;
 let list = AllFindingsCache.filter((item) => {
 if (f.scan && String(item.scan_id) !== String(f.scan)) return false;
 if (f.severity && String(item.severity).toUpperCase() !== f.severity) return false;
 if (f.type && item.type !== f.type) return false;

 if (f.method && item.method !== f.method) return false;
 if (f.search) {
 const hay = [
 item.endpoint || "",
 item.type || "",
 item.description || "",
 item.method || "",
 item.url || "",
 item.evidence || ""
 ]
 .join(" ")
 .toLowerCase();
 if (
 !hay.includes(
 f.search.toLowerCase()
 )
 ) {
 return false;
 }
}
 return true;
 });
 list.sort((a, b) => {
 if (f.sort === "confidence_desc") return (b.confidence || 0) - (a.confidence || 0);
 if (f.sort === "detected_at_desc") return new Date(b.detected_at || 0) - new Date(a.detected_at || 0);
 return (b.priority_score || 0) - (a.priority_score || 0);
 });
 Utils.qs("#findingsCount").textContent = `${list.length} finding${list.length === 1 ? "" : "s"}`;
 Utils.qs("#findingsTableBody").innerHTML = buildFindingsTable(list);
 wireFindingRowClicks(Utils.qs("#findingsTableBody"));
}
/* ---------------------------------------------------------------------
 14. REPORTS VIEW
 --------------------------------------------------------------------- */
async function loadReportsView() {
 hideBanner("reportsError");
 const host = Utils.qs("#reportsTableBody");
 host.innerHTML = '<div class="skeleton-block"></div>';
 try {
 const scans = await getScansCached();
 const completed = scans.filter(
 (s) => String(s.status).toUpperCase() === "COMPLETED"
 );
 if (!completed.length) {
 host.innerHTML = emptyStateHtml(
 "No reports available",
 "Reports become available once a scan completes.",
 false
 );
 return;
 }
 host.innerHTML = `
 <div class="data-table-wrap">
 <table class="data-table">

 <thead>
 <tr>
 <th>Scan ID</th>
 <th>Target</th>
 <th>Completed</th>
 <th>Findings</th>
 <th></th>
 </tr>
 </thead>
 <tbody>
 ${completed.map((scan) => `
 <tr>
 <td class="cell-mono">
 #${Utils.escapeHtml(scan.id)}
 </td>
 <td>
 ${Utils.escapeHtml(scan.target || "—")}
 </td>
 <td class="cell-muted">
 ${Utils.formatDateTime(scan.completed_at)}
 </td>
 <td class="report-finding-count cell-muted" data-report-id="${Utils.escapeHtml(scan.id)}">
 Loading...
 </td>
 <td class="cell-actions">
 <button
 class="btn btn-secondary"
 data-report-id="${Utils.escapeHtml(scan.id)}"
 type="button"
 >
 View report
 </button>
 </td>
 </tr>
 `).join("")}
 </tbody>
 </table>
 </div>
 `;
 // Load report summaries so the table shows the actual finding count.
 await Promise.all(
 completed.map(async (scan) => {
 try {
 const report = await Api.getScanReport(scan.id);
 const countCell = Utils.qs(
 `[data-report-id="${CSS.escape(String(scan.id))}"]`,
 host
 );
 if (countCell) {
 countCell.textContent =
 String(report?.summary?.total_vulnerabilities ?? 0);
 countCell.classList.remove("cell-muted");
 }
 } catch (_) {
 const countCell = Utils.qs(
 `[data-report-id="${CSS.escape(String(scan.id))}"]`,
 host

 );
 if (countCell) {
 countCell.textContent = "—";
 }
 }
 })
 );
 Utils.qsa(
 "button[data-report-id]",
 host
 ).forEach((button) => {
 button.addEventListener("click", () => {
 const scanId = button.dataset.reportId;
 if (!scanId) {
 return;
 }
 const reportUrl =
 `${CONFIG.API_BASE}/api/v1/scans/${scanId}/report/html`;
 window.open(
 reportUrl,
 "_blank",
 "noopener,noreferrer"
 );
 });
 });
 } catch (err) {
 showBanner(
 "reportsError",
 errorMessage(err),
 () => loadReportsView()
 );
 host.innerHTML = "";
 }
}
/* ---------------------------------------------------------------------
 15. FINDING DETAIL MODAL
 --------------------------------------------------------------------- */
function openFindingModal(finding) {
 Utils.qs("#findingTitle").textContent = finding.type || "Finding detail";
 Utils.qs("#findingModalBody").innerHTML = `
 <div class="finding-detail-head">
 <span class="finding-detail-type">${Utils.escapeHtml(finding.type)}</span>
 ${Utils.severityBadge(finding.severity)}
 </div>
 <dl class="finding-detail-grid">
 <div><dt>Confidence</dt><dd>${Utils.confidencePct(finding.confidence)}</dd></div>
 <div><dt>Risk score</dt><dd>${finding.priority_score ?? "\u2014"}</dd></div>
 <div><dt>Method</dt><dd>${Utils.escapeHtml((finding.method || "\u2014").toUpperCase())}</dd></div>
 <div><dt>Endpoint</dt><dd class="mono">${Utils.escapeHtml(finding.endpoint || "\u2014")}</dd></div>
 <div><dt>URL</dt><dd class="mono">${Utils.escapeHtml(finding.url || "\u2014")}</dd></div>
 <div><dt>Detected</dt><dd>${Utils.formatDateTime(finding.detected_at)}</dd></div>
 </dl>
 <div class="finding-section">
 <h3>Description</h3>
 <p>${Utils.escapeHtml(finding.description || "No description provided.")}</p>
 </div>

 <div class="finding-section">
 <h3>Evidence</h3>
 <div
 class="evidence-block"
 id="evidenceBlockText"
 >
 ${Utils.escapeHtml(
 finding.evidence || "No evidence captured."
 )}
 </div>
 <div class="finding-detail-actions">
 <button
 class="evidence-copy-btn"
 id="copyEvidenceBtn"
 type="button"
 >
 Copy evidence
 </button>
 ${
 finding.endpoint_id && finding.scan_id
 ? `
 <button
 class="btn btn-secondary"
 id="viewEndpointBtn"
 type="button"
 >
 View endpoint
 </button>
 `
 : ""
 }
 </div>
</div>
 `;
 const copyBtn = Utils.qs("#copyEvidenceBtn");
 if (copyBtn) {
 copyBtn.addEventListener("click", async () => {
 try {
 await navigator.clipboard.writeText(finding.evidence || "");
 copyBtn.textContent = "Copied";
 copyBtn.classList.add("is-copied");
 setTimeout(() => { copyBtn.textContent = "Copy evidence"; copyBtn.classList.remove("is-copied"); }, 1800);
 }
 catch (_) {
 toast("Could not copy to clipboard.", "error");
 }
 });
 }
 const endpointBtn = Utils.qs(
 "#viewEndpointBtn"
);
if (
 endpointBtn &&
 finding.endpoint_id &&
 finding.scan_id
) {

 endpointBtn.addEventListener(
 "click",
 () => {
 closeFindingModal();
 navigate(
 `#/endpoints/${finding.endpoint_id}__${finding.scan_id}`
 );
 }
 );
}
 Utils.qs("#findingOverlay").hidden = false;
}
function closeFindingModal() { Utils.qs("#findingOverlay").hidden = true; }
/* ---------------------------------------------------------------------
 16. NEW SCAN MODAL / WORKFLOW
 --------------------------------------------------------------------- */
let newScanMode = "url";
function openNewScanModal() {
 Utils.qs("#newScanForm").reset();
 Utils.qs("#newScanFormError").hidden = true;
 setNewScanMode("url");
 Utils.qs("#newScanOverlay").hidden = false;
 Utils.qs("#scanTargetInput").focus();
}
function closeNewScanModal() { Utils.qs("#newScanOverlay").hidden = true; }
function setNewScanMode(mode) {
 newScanMode = mode;
 Utils.qs("#modeUrlBtn").classList.toggle("is-active", mode === "url");
 Utils.qs("#modeUrlBtn").setAttribute("aria-selected", String(mode === "url"));
 Utils.qs("#modeFileBtn").classList.toggle("is-active", mode === "file");
 Utils.qs("#modeFileBtn").setAttribute("aria-selected", String(mode === "file"));
 Utils.qs("#urlModeField").hidden = mode !== "url";
 Utils.qs("#fileModeField").hidden = mode !== "file";
}
async function submitNewScan() {
 const target = Utils.qs("#scanTargetInput").value.trim();
 const errorEl = Utils.qs("#newScanFormError");
 errorEl.hidden = true;
 if (!target) {
 errorEl.textContent = "Target name is required.";
 errorEl.hidden = false;
 return;
 }
 const submitBtn = Utils.qs("#newScanSubmit");
 const setLoading = (loading) => {
 submitBtn.disabled = loading;
 submitBtn.classList.toggle("is-loading", loading);
 Utils.qs(".btn-spinner", submitBtn).hidden = !loading;
 };
 try {
 let scan;
 if (newScanMode === "url") {
 const url = Utils.qs("#scanUrlInput").value.trim();
 if (!url) { errorEl.textContent = "OpenAPI URL is required."; errorEl.hidden = false; return; }

 setLoading(true);
 scan = await Api.createScanFromUrl(target, url);
 } else {
 const fileInput = Utils.qs("#scanFileInput");
 const file = fileInput.files[0];
 if (!file) { errorEl.textContent = "Please choose an OpenAPI file."; errorEl.hidden = false; return; }
 setLoading(true);
 scan = await Api.createScanFromFile(target, file);
 }
 invalidateScanCaches();
 closeNewScanModal();
 toast(`Scan #${scan.id} started for "${scan.target || target}"`, "success");
 navigate(`#/scans/${scan.id}`);
 } catch (err) {
 errorEl.textContent = errorMessage(err);
 errorEl.hidden = false;
 } finally {
 setLoading(false);
 }
}
/* ---------------------------------------------------------------------
 17. SCAN POLLING
 --------------------------------------------------------------------- */
function pollScanUntilDone(scanId, onUpdate) {
 const key = String(scanId);
 if (State.pollTimers.has(key)) return;
 const timer = setInterval(async () => {
 try {
 const scan = await Api.getScan(scanId);
 const status = String(scan.status).toUpperCase();
 if (status === "COMPLETED" || status === "FAILED") {
 clearInterval(timer);
 State.pollTimers.delete(key);
 invalidateScanCaches(scanId);
 if (State.route.view === "scan-detail" && String(State.route.param) === key) {
 onUpdate();
 }
 toast(status === "COMPLETED" ? `Scan #${scanId} completed` : `Scan #${scanId} failed`, status === "COMPLETED" ? "success" : "error");
 }
 } catch (_) {
 // transient error while polling — keep trying silently
 }
 }, CONFIG.POLL_INTERVAL_MS);
 State.pollTimers.set(key, timer);
}
/* ---------------------------------------------------------------------
 18. GLOBAL SEARCH
 --------------------------------------------------------------------- */
const runGlobalSearch = Utils.debounce(async (query) => {
 const resultsEl = Utils.qs("#searchResults");
 if (!query || query.trim().length < 2) {
 resultsEl.hidden = true;
 resultsEl.innerHTML = "";
 return;
 }
 const q = query.trim().toLowerCase();
 try {

 const scans = await getScansCached();
 const matchedScans = scans.filter((s) => String(s.target || "").toLowerCase().includes(q) || String(s.id).includes(q)).slice(0, 5);
 let matchedFindings = [];
 let matchedEndpoints = [];
 if (AllFindingsCache) {
 matchedFindings = AllFindingsCache.filter((f) =>
 String(f.type || "").toLowerCase().includes(q) || String(f.endpoint || "").toLowerCase().includes(q)
 ).slice(0, 6);
 const epMap = new Map();
 AllFindingsCache.forEach((f) => {
 if (String(f.endpoint || "").toLowerCase().includes(q)) epMap.set(`${f.endpoint_id}__${f.scan_id}`, f);
 });
 matchedEndpoints = Array.from(epMap.values()).slice(0, 5);
 }
 if (!matchedScans.length && !matchedFindings.length && !matchedEndpoints.length) {
 resultsEl.innerHTML = `<div class="search-empty">No matches for "${Utils.escapeHtml(query)}"</div>`;
 resultsEl.hidden = false;
 return;
 }
 let html = "";
 if (matchedScans.length) {
 html += `<div class="search-results-group"><div class="search-results-label">Scans</div>` +
 matchedScans.map((s) => `<div class="search-result-item" data-nav="#/scans/${Utils.escapeHtml(s.id)}"><span class="search-result-title">${Utils.escapeHtml(s.target || "Untitled")}</span><span class="search-result-sub">#${Utils.escapeHtml(s.id)} \u00b7 ${Utils.escapeHtml(s.status)}</span></div>`).join("") +
 `</div>`;
 }
 if (matchedEndpoints.length) {
 html += `<div class="search-results-group"><div class="search-results-label">Endpoints</div>` +
 matchedEndpoints.map((f) => `<div class="search-result-item" data-nav="#/endpoints/${Utils.escapeHtml(f.endpoint_id)}__${Utils.escapeHtml(f.scan_id)}"><span
class="search-result-title mono">${Utils.escapeHtml(f.endpoint)}</span><span class="search-result-sub">${Utils.escapeHtml(f.method)}</span></div>`).join("") +
 `</div>`;
 }
 if (matchedFindings.length) {
 html += `<div class="search-results-group"><div class="search-results-label">Findings</div>` +
 matchedFindings.map((f) => `<div class="search-result-item" data-nav="#/vulnerabilities" data-finding-preview='${Utils.escapeHtml(JSON.stringify(f))}'><span
class="search-result-title mono">${Utils.escapeHtml(f.type)}</span><span class="search-result-sub">${Utils.escapeHtml(f.endpoint)}</span></div>`).join("") +
 `</div>`;
 }
 resultsEl.innerHTML = html;
 resultsEl.hidden = false;
 Utils.qsa(".search-result-item", resultsEl).forEach((item) => {
 item.addEventListener("click", () => {
 resultsEl.hidden = true;
 Utils.qs("#globalSearchInput").value = "";
 if (item.dataset.findingPreview) {
 navigate(item.dataset.nav);
 setTimeout(() => openFindingModal(JSON.parse(item.dataset.findingPreview)), 250);
 } else {
 navigate(item.dataset.nav);
 }
 });
 });
 } catch (_) {
 resultsEl.hidden = true;
 }
}, 260);

/* ---------------------------------------------------------------------
 19. EVENT WIRING
 --------------------------------------------------------------------- */
function wireGlobalEvents() {
 window.addEventListener("hashchange", router);
 Utils.qs("#sidebarToggle").addEventListener("click", () => {
 document.querySelector(".app-shell").classList.toggle("sidebar-collapsed");
 });
 Utils.qs("#refreshBtn").addEventListener("click", () => router());
 document.addEventListener("click", (e) => {
 const searchWrap = Utils.qs("#globalSearchInput").closest(".header-search");
 if (!searchWrap.contains(e.target)) Utils.qs("#searchResults").hidden = true;
 });
 Utils.qs("#globalSearchInput").addEventListener("input", (e) => runGlobalSearch(e.target.value));
 // New scan modal triggers
 ["dashNewScanBtn", "scansNewScanBtn"].forEach((id) => {
 const el = document.getElementById(id);
 if (el) el.addEventListener("click", () => openNewScanModal());
 });
 document.addEventListener("click", (e) => {
 if (e.target && e.target.id === "emptyStateNewScanBtn") openNewScanModal();
 });
 Utils.qs("#dashHistoryBtn").addEventListener("click", () => navigate("#/scans"));
 Utils.qs("#dashReportsBtn").addEventListener("click", () => navigate("#/reports"));
 Utils.qs("#dashRefreshBtn").addEventListener("click", () => loadDashboard());
 Utils.qs("#scansRefreshBtn").addEventListener("click", () => loadScansList());
 Utils.qs("#endpointsRefreshBtn").addEventListener("click", () => renderEndpointsForScan(State.endpointsFilterScan));
 Utils.qs("#findingsRefreshBtn").addEventListener("click", () => loadFindingsView());
 Utils.qs("#reportsRefreshBtn").addEventListener("click", () => loadReportsView());
 Utils.qs("#newScanClose").addEventListener("click", closeNewScanModal);
 Utils.qs("#newScanCancel").addEventListener("click", closeNewScanModal);
 Utils.qs("#newScanOverlay").addEventListener("click", (e) => { if (e.target.id === "newScanOverlay") closeNewScanModal(); });
 Utils.qs("#modeUrlBtn").addEventListener("click", () => setNewScanMode("url"));
 Utils.qs("#modeFileBtn").addEventListener("click", () => setNewScanMode("file"));
 Utils.qs("#newScanSubmit").addEventListener("click", submitNewScan);
 Utils.qs("#newScanForm").addEventListener("submit", (e) => { e.preventDefault(); submitNewScan(); });
 Utils.qs("#findingClose").addEventListener("click", closeFindingModal);
 Utils.qs("#findingOverlay").addEventListener("click", (e) => { if (e.target.id === "findingOverlay") closeFindingModal(); });
 document.addEventListener("keydown", (e) => {
 if (e.key === "Escape") { closeNewScanModal(); closeFindingModal(); }
 });
 Utils.qs("#scanDetailBack").addEventListener("click", () => navigate("#/scans"));
 Utils.qs("#endpointDetailBack").addEventListener("click", () => navigate("#/endpoints"));
 // Endpoints filter
 Utils.qs("#endpointsScanFilter").addEventListener("change", (e) => {
 State.endpointsFilterScan = e.target.value;
 renderEndpointsForScan(e.target.value);
 });
 // Findings filters
 Utils.qs("#findingsScanFilter").addEventListener("change", (e) => { State.findingsFilters.scan = e.target.value; applyFindingsFiltersAndRender(); });
 Utils.qs("#findingsSeverityFilter").addEventListener("change", (e) => { State.findingsFilters.severity = e.target.value; applyFindingsFiltersAndRender(); });
 Utils.qs("#findingsTypeFilter").addEventListener("change", (e) => { State.findingsFilters.type = e.target.value; applyFindingsFiltersAndRender(); });
 Utils.qs("#findingsMethodFilter").addEventListener("change", (e) => { State.findingsFilters.method = e.target.value; applyFindingsFiltersAndRender(); });
 Utils.qs("#findingsSort").addEventListener("change", (e) => { State.findingsFilters.sort = e.target.value; applyFindingsFiltersAndRender(); });

 Utils.qs("#findingsSearchInput").addEventListener("input", Utils.debounce((e) => {
 State.findingsFilters.search = e.target.value;
 applyFindingsFiltersAndRender();
 }, 220));
 Utils.qs("#findingsClearFilters").addEventListener("click", () => {
 State.findingsFilters = { scan: "", severity: "", type: "", method: "", search: "", sort: "priority_score_desc" };
 Utils.qs("#findingsScanFilter").value = "";
 Utils.qs("#findingsSeverityFilter").value = "";
 Utils.qs("#findingsTypeFilter").value = "";
 Utils.qs("#findingsMethodFilter").value = "";
 Utils.qs("#findingsSearchInput").value = "";
 Utils.qs("#findingsSort").value = "priority_score_desc";
 applyFindingsFiltersAndRender();
 });
}
/* ---------------------------------------------------------------------
 20. BOOTSTRAP
 --------------------------------------------------------------------- */
document.addEventListener("DOMContentLoaded", () => {
 wireGlobalEvents();
 refreshConnectionStatus();
 setInterval(refreshConnectionStatus, CONFIG.CONN_CHECK_INTERVAL_MS);
 router();
});