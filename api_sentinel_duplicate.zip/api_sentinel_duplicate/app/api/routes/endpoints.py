from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from typing import List

from app.db.session import get_db
from app.schemas.endpoint import EndpointResponse
from app.services import endpoint_service

endpoint_router = APIRouter(prefix="/api/v1/scans", tags=["Endpoints"])


@endpoint_router.get("/{scan_id}/endpoints", response_model=List[EndpointResponse])
def get_scan_endpoints(scan_id: int, db: Session = Depends(get_db)):
    return endpoint_service.get_scan_endpoints(db, scan_id)