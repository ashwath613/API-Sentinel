from fastapi import (
    APIRouter,
    Depends,
    HTTPException,
    UploadFile,
    File,
    Form,
    BackgroundTasks,
)

from sqlalchemy.orm import Session
from typing import List

from app.db.session import get_db
from app.db.models import Scan, InputType

from app.services import scan_service
from app.services.openapi_service import discover_from_openapi
from app.services.openapi_url_service import discover_openapi_from_url
from app.services.scan_service import run_scan

from app.schemas.scan import (
    ScanCreate,
    ScanResponse,
    ScanStatusUpdate,
    ScanResultResponse,
    ScanListResponse,
)
from app.schemas.scan import (
    ScanCreate,
    ScanResponse,
    ScanStatusUpdate,
    ScanResultResponse,
    ScanListResponse,
    ScanSummaryResponse,
)
from app.services.scan_report import (
    generate_scan_report,
)
from fastapi import Request
from fastapi.templating import Jinja2Templates
templates = Jinja2Templates(
    directory="templates"
)

router = APIRouter(
    prefix="/api/v1/scans",
    tags=["Scans"],
)

@router.get(
    "/{scan_id}/dashboard",
    include_in_schema=False,
)
def scan_dashboard(
    request: Request,
    scan_id: int,
    db: Session = Depends(get_db),
):
    summary = scan_service.get_scan_summary(
        db=db,
        scan_id=scan_id,
    )

    if summary is None:
        raise HTTPException(
            status_code=404,
            detail="Scan not found",
        )

    scan = scan_service.get_scan(
        db=db,
        scan_id=scan_id,
    )

    return templates.TemplateResponse(
        request=request,
        name="dashboard.html",
        context={
            "summary": summary,
            "scan": scan,
        },
    )

@router.post(
    "/openapi-url",
    response_model=ScanResponse
)
def create_openapi_url_scan(
    background_tasks: BackgroundTasks,
    target: str = Form(...),
    openapi_url: str = Form(...),
    db: Session = Depends(get_db),
):
    scan = Scan(
        target=target,
        input_type=InputType.OPENAPI,
    )

    db.add(scan)
    db.commit()
    db.refresh(scan)

    discover_openapi_from_url(
        db=db,
        scan_id=scan.id,
        openapi_url=openapi_url,
    )

    background_tasks.add_task(
        run_scan,
        scan.id,
    )

    return scan


@router.post(
    "/openapi",
    response_model=ScanResponse
)
def create_openapi_scan(
    target: str = Form(...),
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
):
    scan = Scan(
        target=target,
        input_type=InputType.OPENAPI,
    )

    db.add(scan)
    db.commit()
    db.refresh(scan)

    file_path = f"data/{file.filename}"

    with open(file_path, "wb") as output_file:
        output_file.write(file.file.read())

    discover_from_openapi(
        db=db,
        scan_id=scan.id,
        file_path=file_path,
    )

    return scan



@router.post(
    "/",
    response_model=ScanResponse
)
def create_scan(
    scan_data: ScanCreate,
    db: Session = Depends(get_db),
):
    return scan_service.create_scan(
        db,
        scan_data,
    )

@router.get("/{scan_id}/report")
def get_scan_report(
    scan_id: int,
    db: Session = Depends(get_db),
):
    report = generate_scan_report(
        db=db,
        scan_id=scan_id,
    )

    if report is None:
        raise HTTPException(
            status_code=404,
            detail="Scan not found",
        )

    return report
@router.get(
    "/{scan_id}/report/html",
    include_in_schema=False,
)
def get_scan_report_html(
    request: Request,
    scan_id: int,
    db: Session = Depends(get_db),
):
    report = generate_scan_report(
        db=db,
        scan_id=scan_id,
    )

    if report is None:
        raise HTTPException(
            status_code=404,
            detail="Scan not found",
        )

    return templates.TemplateResponse(
        request=request,
        name="scan_report.html",
        context={
            "report": report,
        },
    )

@router.get(
    "/",
    response_model=List[ScanListResponse]
)
def get_all_scans(
    skip: int = 0,
    limit: int = 10,
    db: Session = Depends(get_db),
):
    return scan_service.get_all_scans(
        db=db,
        skip=skip,
        limit=limit,
    )

@router.get(
    "/{scan_id}/results",
    response_model=ScanResultResponse,
)
def get_scan_results(
    scan_id: int,
    db: Session = Depends(get_db),
):
    scan = scan_service.get_scan(
        db,
        scan_id,
    )

    if scan is None:
        raise HTTPException(
            status_code=404,
            detail="Scan not found",
        )

    return scan


@router.patch(
    "/{scan_id}/status",
    response_model=ScanResponse,
)
def update_status(
    scan_id: int,
    status_data: ScanStatusUpdate,
    db: Session = Depends(get_db),
):
    scan = scan_service.update_scan_status(
        db,
        scan_id,
        status_data.status,
    )

    if scan is None:
        raise HTTPException(
            status_code=404,
            detail="No scan found",
        )

    return scan


@router.get(
    "/{scan_id}",
    response_model=ScanResponse,
)
def get_scan_details(
    scan_id: int,
    db: Session = Depends(get_db),
):
    scan = scan_service.get_scan(
        db,
        scan_id,
    )

    if scan is None:
        raise HTTPException(
            status_code=404,
            detail="No scan found",
        )

    return scan

@router.get(
    "/{scan_id}/summary",
    response_model=ScanSummaryResponse,
)
def get_scan_summary(
    scan_id: int,
    db: Session = Depends(get_db),
):
    summary = scan_service.get_scan_summary(
        db=db,
        scan_id=scan_id,
    )

    if summary is None:
        raise HTTPException(
            status_code=404,
            detail="Scan not found",
        )

    return summary