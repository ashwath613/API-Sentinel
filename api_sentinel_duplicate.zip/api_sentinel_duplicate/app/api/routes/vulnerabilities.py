from typing import List, Optional

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.db.models import Severity
from app.db.session import get_db
from app.schemas.vulnerability import VulnerabilityResponse
from app.services import vulnerability_service
from fastapi import HTTPException
from app.schemas.vulnerability import (
    VulnerabilityResponse,
    VulnerabilityDetailResponse
)


router = APIRouter(
    prefix="/api/v1/vulnerabilities",
    tags=["Vulnerabilities"]
)



@router.get("/", response_model=List[VulnerabilityResponse])
def get_vulnerabilities(
    severity: Optional[Severity] = None,
    vulnerability_type: Optional[str] = None,
    skip: int = 0,
    limit: int = 20,
    db: Session = Depends(get_db)
):
    return vulnerability_service.get_vulnerabilities(
        db=db,
        severity=severity,
        vulnerability_type=vulnerability_type,
        skip=skip,
        limit=limit
    )

@router.get(
    "/{vulnerability_id}",
    response_model=VulnerabilityDetailResponse
)
def get_vulnerability(
    vulnerability_id: int,
    db: Session = Depends(get_db)
):
    vulnerability = vulnerability_service.get_vulnerability(
        db=db,
        vulnerability_id=vulnerability_id
    )

    if vulnerability is None:
        raise HTTPException(
            status_code=404,
            detail="Vulnerability not found"
        )

    return vulnerability