from datetime import datetime

from pydantic import BaseModel, ConfigDict


class EndpointResponse(BaseModel):
    id: int
    scan_id: int
    path: str
    method: str
    url: str
    discovered_at: datetime

    model_config = ConfigDict(from_attributes=True)