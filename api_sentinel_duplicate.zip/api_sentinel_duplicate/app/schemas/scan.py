from datetime import datetime
from app.db.models import InputType, Status, Severity
from pydantic import BaseModel, ConfigDict
from typing import Optional,List

class ScanCreate(BaseModel):
    target:str
    input_type: InputType

class ScanResponse(BaseModel):
    id :int
    target:str
    input_type:InputType
    status:Status
    started_at:Optional[datetime] = None
    completed_at:Optional[datetime]
    model_config = ConfigDict(from_attributes=True)

class ScanStatusUpdate(BaseModel):
    status:Status

    
class ScanSummaryResponse(BaseModel):

    scan_id: int
    target: str
    status: Status
    input_type: InputType

    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None

    total_endpoints: int
    total_vulnerabilities: int

    critical_count: int
    high_count: int
    medium_count: int
    low_count: int

    highest_risk_score: float
class VulnerabilityResponse(BaseModel):
    id: int
    type: str
    severity: Severity
    description: str
    evidence: str
    confidence: float
    priority_score: float
    detected_at: datetime

    model_config = {
        "from_attributes": True
    }


class EndpointResultResponse(BaseModel):
    id: int
    path: str
    method: str
    url: str
    discovered_at: datetime
    vulnerabilities: List[VulnerabilityResponse]

    model_config = {
        "from_attributes": True
    }


class ScanResultResponse(BaseModel):
    id: int
    target: str
    input_type: InputType
    status: Status
    started_at: datetime
    completed_at: Optional[datetime]
    endpoints: List[EndpointResultResponse]

    model_config = {
        "from_attributes": True
    }

class ScanListResponse(BaseModel):
    id: int
    target: str
    input_type: InputType
    status: Status
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None

    model_config = {
        "from_attributes": True
    }