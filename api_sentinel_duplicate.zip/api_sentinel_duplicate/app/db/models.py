from datetime import datetime, timezone
from enum import Enum
from typing import Optional, List

from sqlalchemy import (
    DateTime,
    Enum as SQLEnum,
    ForeignKey,
    String,
    Text,
    JSON,
)
from sqlalchemy.orm import (
    DeclarativeBase,
    Mapped,
    mapped_column,
    relationship,
)


class Base(DeclarativeBase):
    pass



class InputType(str, Enum):
    URL = "URL"
    OPENAPI = "OPENAPI"
    POSTMAN = "POSTMAN"


class Status(str, Enum):
    QUEUED = "QUEUED"
    RUNNING = "RUNNING"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"



class Scan(Base):
    __tablename__ = "scans"

    id: Mapped[int] = mapped_column(
        primary_key=True
    )

    target: Mapped[str] = mapped_column(
        String(100),
        nullable=False
    )

    input_type: Mapped[InputType] = mapped_column(
        SQLEnum(InputType),
        nullable=False
    )

    status: Mapped[Status] = mapped_column(
        SQLEnum(Status),
        nullable=False,
        default=Status.QUEUED
    )

    # A scan is QUEUED before execution starts.
    # Therefore started_at must be NULL initially.
    started_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True),
        nullable=True
    )

    # This remains NULL until the scan finishes.
    completed_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True),
        nullable=True
    )

    endpoints: Mapped[List["Endpoint"]] = relationship(
        back_populates="scan",
        cascade="all, delete-orphan"
    )


class Endpoint(Base):
    __tablename__ = "endpoints"

    id: Mapped[int] = mapped_column(
        primary_key=True
    )

    scan_id: Mapped[int] = mapped_column(
        ForeignKey(
            "scans.id",
            ondelete="CASCADE"
        ),
        nullable=False
    )

    path: Mapped[str] = mapped_column(
        nullable=False
    )

    method: Mapped[str] = mapped_column(
        nullable=False
    )

    url: Mapped[str] = mapped_column(
        nullable=False
    )

    discovered_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False
    )

    request_metadata: Mapped[Optional[dict]] = mapped_column(
        JSON,
        nullable=True
    )

    scan: Mapped["Scan"] = relationship(
        back_populates="endpoints"
    )

    vulnerabilities: Mapped[List["Vulnerability"]] = relationship(
        back_populates="endpoint",
        cascade="all, delete-orphan"
    )




class Severity(str, Enum):
    CRITICAL = "CRITICAL"
    HIGH = "HIGH"
    MEDIUM = "MEDIUM"
    LOW = "LOW"


class Vulnerability(Base):
    __tablename__ = "vulnerabilities"

    id: Mapped[int] = mapped_column(
        primary_key=True
    )

    endpoint_id: Mapped[int] = mapped_column(
        ForeignKey(
            "endpoints.id",
            ondelete="CASCADE"
        ),
        nullable=False
    )

    type: Mapped[str] = mapped_column(
        String(100),
        nullable=False
    )

    severity: Mapped[Severity] = mapped_column(
        SQLEnum(Severity),
        nullable=False
    )

    description: Mapped[str] = mapped_column(
        String(1000),
        nullable=False
    )

    evidence: Mapped[str] = mapped_column(
        Text,
        nullable=False
    )

    confidence: Mapped[float] = mapped_column(
        nullable=False
    )

    priority_score: Mapped[float] = mapped_column(
        nullable=False
    )

    detected_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False
    )

    endpoint: Mapped["Endpoint"] = relationship(
        back_populates="vulnerabilities"
    )