from typing import Any

import requests

from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.security import HTTPBearer


router = APIRouter(
    prefix="/target",
    tags=["Test Target"],
)

bearer_scheme = HTTPBearer(
    auto_error=False
)



@router.get("/users")
def get_users(
    limit: int = Query(
        10,
        ge=1,
        le=100
    )
):
    users = [
        {
            "id": 1,
            "name": "Alice",
            "email": "alice@example.com",
        },
        {
            "id": 2,
            "name": "Bob",
            "email": "bob@example.com",
        },
        {
            "id": 3,
            "name": "Charlie",
            "email": "charlie@example.com",
        },
    ]

    return users[:limit]


@router.get("/users/profile")
def users_profile(
    q: str = Query(
        "test",
        max_length=500
    )
):
    return {
        "username": "test-user",
        "email": "test@example.com",
        "role": "user",
        "profile_note": q,
    }


@router.get("/users/{user_id}")
def get_user(
    user_id: int
):
    users = {
        1: {
            "id": 1,
            "name": "Alice",
            "email": "alice@example.com",
        },
        2: {
            "id": 2,
            "name": "Bob",
            "email": "bob@example.com",
        },
        3: {
            "id": 3,
            "name": "Charlie",
            "email": "charlie@example.com",
        },
    }

    user = users.get(user_id)

    if user is None:
        raise HTTPException(
            status_code=404,
            detail="User not found",
        )

    return user



@router.get("/search")
def search(
    q: str = Query(
        ...,
        min_length=1,
        max_length=500
    )
):
    lowered = q.lower()

    if (
        "'"
        in lowered
        or " or "
        in lowered
        or "union"
        in lowered
        or "select"
        in lowered
    ):
        return {
            "results": [
                {
                    "id": 1,
                    "name": "Alice",
                },
                {
                    "id": 2,
                    "name": "Bob",
                },
            ],
            "debug": "Database query executed.",
        }

    return {
        "results": [],
        "query": q,
    }




@router.get("/accounts/{account_id}")
def get_account(
    account_id: int
):
    accounts = {
        1: {
            "id": 1,
            "owner": "Alice",
            "balance": 25000,
        },
        2: {
            "id": 2,
            "owner": "Bob",
            "balance": 48000,
        },
    }

    account = accounts.get(account_id)

    if account is None:
        raise HTTPException(
            status_code=404,
            detail="Account not found",
        )

    return account



@router.post("/mass-assignment-test")
def mass_assignment_test(
    data: dict[str, Any]
):
    # Intentionally vulnerable test endpoint.
    return data


@router.post("/mass-assignment-safe")
def mass_assignment_safe(
    data: dict[str, Any]
):
    allowed_fields = {
        "name",
    }

    return {
        key: value
        for key, value in data.items()
        if key in allowed_fields
    }



@router.get("/sensitive-data-test")
def sensitive_data_test():
    # Intentionally exposes test-only sensitive-looking values.
    return {
        "id": 1001,
        "name": "Test User",
        "email": "test@example.com",
        "phone": "+91-9000000000",
        "ssn": "TEST-SSN-0001",
        "api_key": "TEST-API-KEY-12345",
        "access_token": "TEST-TOKEN-12345",
    }




@router.get("/xss-html")
def xss_html(
    q: str = Query(
        "",
        max_length=2000
    )
):
    # Intentionally vulnerable reflected-XSS test endpoint.
    html = f"""
    <html>
        <body>
            <h1>Search Result</h1>
            <div>{q}</div>
        </body>
    </html>
    """

    return HTMLResponse(
        content=html
    )




@router.get(
    "/protected",
    openapi_extra={
        "security": [
            {
                "HTTPBearer": []
            }
        ]
    },
)
def protected():
    # Intentionally accepts unauthenticated access.
    return {
        "message": "Protected resource",
        "status": "authenticated",
    }


@router.get(
    "/protected-broken",
    openapi_extra={
        "security": [
            {
                "HTTPBearer": []
            }
        ]
    },
)
def protected_broken():
    # Intentionally broken authorization behavior.
    return {
        "message": "Protected resource",
        "status": "unauthenticated-access-accepted",
    }




@router.get("/ssrf-test")
def ssrf_test(
    url: str = Query(
        ...,
        min_length=1,
        max_length=2000
    )
):
    """
    Intentionally vulnerable SSRF test endpoint.

    This endpoint is only for the local SentinelAI test target.
    """

    try:
        parsed_response = requests.get(
            url,
            timeout=5,
            allow_redirects=False,
        )

        return {
            "status_code": parsed_response.status_code,
            "content": parsed_response.text[:2000],
        }

    except requests.exceptions.InvalidSchema:
        return JSONResponse(
            status_code=400,
            content={
                "error": "Invalid URL schema."
            },
        )

    except requests.exceptions.MissingSchema:
        return JSONResponse(
            status_code=400,
            content={
                "error": "URL scheme is required."
            },
        )

    except requests.exceptions.InvalidURL:
        return JSONResponse(
            status_code=400,
            content={
                "error": "Invalid URL."
            },
        )

    except requests.exceptions.Timeout:
        return JSONResponse(
            status_code=504,
            content={
                "error": "Target request timed out."
            },
        )

    except requests.RequestException as error:
        return JSONResponse(
            status_code=502,
            content={
                "error": str(error),
            },
        )




@router.get("/ssrf-safe")
def ssrf_safe(
    url: str = Query(
        ...,
        min_length=1,
        max_length=2000
    )
):
    lowered = url.lower()

    blocked_hosts = [
        "127.0.0.1",
        "localhost",
        "0.0.0.0",
    ]

    if any(
        host in lowered
        for host in blocked_hosts
    ):
        raise HTTPException(
            status_code=400,
            detail="Internal destinations are not allowed.",
        )

    return {
        "message": "URL accepted"
    }




@router.get("/rate-limit-test")
def rate_limit_test():
    # Intentionally has no rate limiting.
    return {
        "message": "Request accepted"
    }




@router.get("/products")
def products(
    q: str = Query(
        "",
        max_length=500
    )
):
    products_data = [
        {
            "id": 1,
            "name": "Laptop",
        },
        {
            "id": 2,
            "name": "Keyboard",
        },
    ]

    if q:
        lowered_query = q.lower()

        products_data = [
            product
            for product in products_data
            if lowered_query
            in product["name"].lower()
        ]

    return products_data




@router.get("/health")
def target_health():
    return {
        "status": "ok",
        "service": "SentinelAI Test Target",
    }