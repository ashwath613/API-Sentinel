from typing import Any

from app.security.requests.parameter_generator import (
    ParameterGenerator,
)


class RequestBuilder:

    def build(
        self,
        endpoint
    ) -> dict[str, Any]:

        metadata = (
            endpoint.request_metadata
            or {}
        )

        parameters = metadata.get(
            "parameters",
            []
        )

        request_body = metadata.get(
            "request_body"
        )

        

        components = metadata.get(
            "components",
            {}
        )

        schemas = components.get(
            "schemas",
            {}
        )

        params = {}
        path_params = {}
        headers = {}

        

        for parameter in parameters:

            if not isinstance(
                parameter,
                dict
            ):
                continue

            name = parameter.get(
                "name"
            )

            location = parameter.get(
                "in"
            )

            if not name or not location:
                continue

            value = self._generate_parameter_value(
                parameter,
                schemas
            )

            if location == "query":

                params[name] = value

            elif location == "path":

                path_params[name] = value

            elif location == "header":

                headers[name] = str(
                    value
                )

        
        url = endpoint.url

        for name, value in path_params.items():

            url = url.replace(
                "{" + name + "}",
                str(value)
            )

        body = None

        if request_body:

            body = self._generate_request_body(
                request_body,
                schemas
            )


        return {
            "url": url,
            "params": params,
            "json": body,
            "headers": headers,
        }

   

    def _generate_parameter_value(
        self,
        parameter: dict[str, Any],
        schemas: dict[str, Any]
    ) -> Any:

        schema = parameter.get(
            "schema",
            {}
        )

        resolved_schema = self._resolve_schema(
            schema,
            schemas
        )

        parameter_copy = dict(
            parameter
        )

        parameter_copy["schema"] = (
            resolved_schema
        )

        return ParameterGenerator.generate(
            parameter_copy
        )

    

    def _generate_request_body(
        self,
        request_body: dict[str, Any],
        schemas: dict[str, Any]
    ) -> Any:

        content = request_body.get(
            "content",
            {}
        )

        if not content:
            return {}

        # Prefer JSON
        schema_info = content.get(
            "application/json"
        )

        if not schema_info:

            schema_info = next(
                iter(
                    content.values()
                ),
                {}
            )

        schema = schema_info.get(
            "schema",
            {}
        )

        return self._generate_schema_value(
            schema,
            schemas
        )

    

    def _generate_schema_value(
        self,
        schema: dict[str, Any],
        schemas: dict[str, Any]
    ) -> Any:

        schema = self._resolve_schema(
            schema,
            schemas
        )

        if not schema:
            return {}

        

        if "example" in schema:
            return schema["example"]

        

        if "default" in schema:
            return schema["default"]

        

        enum_values = schema.get(
            "enum"
        )

        if enum_values:
            return enum_values[0]


        schema_type = schema.get(
            "type"
        )

        if schema_type == "object":

            properties = schema.get(
                "properties",
                {}
            )

            result = {}

            for name, property_schema in properties.items():

                result[name] = (
                    self._generate_schema_value(
                        property_schema,
                        schemas
                    )
                )

            return result


        if schema_type == "array":

            item_schema = schema.get(
                "items",
                {}
            )

            item_value = (
                self._generate_schema_value(
                    item_schema,
                    schemas
                )
            )

            return [
                item_value
            ]

        

        return ParameterGenerator.generate(
            {
                "schema": schema
            }
        )

    

    @staticmethod
    def _resolve_schema(
        schema: dict[str, Any],
        schemas: dict[str, Any]
    ) -> dict[str, Any]:

        if not isinstance(
            schema,
            dict
        ):
            return {}

        reference = schema.get(
            "$ref"
        )

        if not reference:
            return schema

        prefix = (
            "#/components/schemas/"
        )

        if not reference.startswith(
            prefix
        ):
            return {}

        schema_name = (
            reference[len(prefix):]
        )

        return schemas.get(
            schema_name,
            {}
        )