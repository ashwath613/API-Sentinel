from typing import Any


class ParameterGenerator:

    @staticmethod
    def generate(
        parameter: dict[str, Any]
    ) -> Any:

        schema = parameter.get(
            "schema",
            {}
        )

        return ParameterGenerator.generate_from_schema(
            schema
        )

    @staticmethod
    def generate_from_schema(
        schema: dict[str, Any]
    ) -> Any:

        if not isinstance(
            schema,
            dict
        ):
            return "test"

       
        if "example" in schema:
            return schema["example"]

        examples = schema.get(
            "examples"
        )

        if isinstance(
            examples,
            list
        ) and examples:

            return examples[0]

        

        if "default" in schema:
            return schema["default"]

        

        enum_values = schema.get(
            "enum"
        )

        if enum_values:
            return enum_values[0]

        

        any_of = schema.get(
            "anyOf"
        )

        if any_of:

            # Prefer a non-null schema.
            for option in any_of:

                if not isinstance(
                    option,
                    dict
                ):
                    continue

                if option.get(
                    "type"
                ) == "null":
                    continue

                return ParameterGenerator.generate_from_schema(
                    option
                )

            return None

        one_of = schema.get(
            "oneOf"
        )

        if one_of:

            for option in one_of:

                if not isinstance(
                    option,
                    dict
                ):
                    continue

                if option.get(
                    "type"
                ) == "null":
                    continue

                return ParameterGenerator.generate_from_schema(
                    option
                )

            return None

        
        schema_type = schema.get(
            "type"
        )

        

        if schema_type == "integer":

            minimum = schema.get(
                "minimum"
            )

            maximum = schema.get(
                "maximum"
            )

            if minimum is not None:
                value = int(minimum)

            else:
                value = 1

            if maximum is not None:
                value = min(
                    value,
                    int(maximum)
                )

            return value

       

        if schema_type == "number":

            minimum = schema.get(
                "minimum"
            )

            maximum = schema.get(
                "maximum"
            )

            if minimum is not None:
                value = float(minimum)

            else:
                value = 1.0

            if maximum is not None:
                value = min(
                    value,
                    float(maximum)
                )

            return value

        

        if schema_type == "boolean":
            return True

        

        if schema_type == "array":

            items = schema.get(
                "items",
                {}
            )

            return [
                ParameterGenerator.generate_from_schema(
                    items
                )
            ]

        

        if schema_type == "object":

            properties = schema.get(
                "properties",
                {}
            )

            result = {}

            for name, property_schema in properties.items():

                result[name] = (
                    ParameterGenerator.generate_from_schema(
                        property_schema
                    )
                )

            return result

        

        if schema_type == "string":

            value_format = schema.get(
                "format"
            )

            if value_format == "email":
                return "test@example.com"

            if value_format in {
                "uri",
                "url"
            }:
                return "https://example.com"

            if value_format == "uuid":
                return (
                    "00000000-0000-0000-0000-"
                    "000000000001"
                )

            if value_format == "date":
                return "2026-01-01"

            if value_format == "date-time":
                return "2026-01-01T00:00:00Z"

            min_length = schema.get(
                "minLength"
            )

            max_length = schema.get(
                "maxLength"
            )

            value = "test"

            if (
                min_length is not None
                and len(value) < min_length
            ):
                value = (
                    "x"
                    * int(min_length)
                )

            if (
                max_length is not None
                and len(value) > max_length
            ):
                value = value[
                    :int(max_length)
                ]

            return value

        

        if schema_type == "null":
            return None

        return "test"