from typing import List

from app.security.intelligence.security_intelligence import (
    EndpointIntelligence,
)


class RiskMapper:

    def map_risks(
        self,
        intelligence: EndpointIntelligence
    ) -> List[str]:

        risks = []

        endpoint = intelligence.endpoint_profile
        parameters = intelligence.parameter_profiles

       
        if endpoint.potential_object_endpoint:

            risks.append(
                "BOLA"
            )

        
        injection_candidates = [
            parameter
            for parameter in parameters
            if parameter.injection_candidate
        ]

        if injection_candidates:

            risks.append(
                "SQL_INJECTION"
            )


        ssrf_candidates = [
            parameter
            for parameter in parameters
            if (
                parameter.is_string
                and parameter.name.lower()
                in {
                    "url",
                    "uri",
                    "link",
                    "endpoint",
                    "callback",
                    "redirect",
                    "target",
                    "webhook",
                }
            )
        ]

        if ssrf_candidates:

            risks.append(
                "SSRF"
            )

        

        string_parameters = [
            parameter
            for parameter in parameters
            if parameter.is_string
        ]

        if string_parameters:

            risks.append(
                "XSS"
            )

        

        if any(
            parameter.location == "query"
            for parameter in parameters
        ):

            risks.append(
                "INPUT_VALIDATION"
            )

        
        if (
            endpoint.is_write_operation
            or endpoint.potential_rate_limit_endpoint
        ):

            risks.append(
                "RATE_LIMITING"
            )

        if endpoint.is_write_operation:

            risks.append(
                "MASS_ASSIGNMENT"
            )

        

        if endpoint.has_security_requirement:

            risks.append(
                "AUTHENTICATION"
            )


        sensitive_parameters = [
            parameter
            for parameter in parameters
            if parameter.is_sensitive_parameter
        ]

        if (
            sensitive_parameters
            or endpoint.potential_sensitive_data_endpoint
        ):

            risks.append(
                "SENSITIVE_DATA_EXPOSURE"
            )

        

        if endpoint.has_security_requirement:

            risks.append(
                "BROKEN_AUTHORIZATION"
            )

        

        risks.append(
            "CORS"
        )

        

        risks.append(
            "SECURITY_HEADERS"
        )

        return self._deduplicate(
            risks
        )

    def _deduplicate(
        self,
        risks: List[str]
    ) -> List[str]:

        return list(
            dict.fromkeys(
                risks
            )
        )