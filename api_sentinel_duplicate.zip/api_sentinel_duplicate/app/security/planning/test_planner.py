from dataclasses import dataclass
from typing import List

from app.security.intelligence.security_intelligence import (
    EndpointIntelligence,
)


@dataclass
class PlannedTest:
    tester_name: str
    risk: str
    priority: str
    reason: str


class TestPlanner:

    RISK_TO_TESTER = {
        "BOLA": "BOLATester",
        "SQL_INJECTION": "SQLInjectionTester",
        "RATE_LIMITING": "RateLimitTester",
        "CORS": "CORSTester",
        "SECURITY_HEADERS": "SecurityHeadersTester",
        "BROKEN_AUTHORIZATION": "AuthorizationTester",
        "AUTHENTICATION": "AuthenticationTester",
        "INPUT_VALIDATION": "InputValidationTester",
        "XSS": "XSSTester",
        "SENSITIVE_DATA_EXPOSURE": "SensitiveDataTester",
        "MASS_ASSIGNMENT": "MassAssignmentTester",
        "SSRF": "SSRFTester",
    }

    RISK_PRIORITY = {
        "BOLA": "HIGH",
        "BROKEN_AUTHORIZATION": "HIGH",
        "SQL_INJECTION": "HIGH",
        "RATE_LIMITING": "MEDIUM",
        "SENSITIVE_DATA_EXPOSURE": "HIGH",
        "INPUT_VALIDATION": "MEDIUM",
        "CORS": "MEDIUM",
        "SECURITY_HEADERS": "LOW",
        "AUTHENTICATION": "HIGH",
        "INPUT_VALIDATION": "MEDIUM",
        "XSS": "HIGH",
        "SENSITIVE_DATA_EXPOSURE": "HIGH",
        "MASS_ASSIGNMENT": "HIGH",
        "SSRF": "HIGH",
    }

    def create_plan(
        self,
        intelligence: EndpointIntelligence,
        risks: List[str]
    ) -> List[PlannedTest]:

        plan = []

        for risk in risks:

            tester_name = self.RISK_TO_TESTER.get(
                risk
            )

            if not tester_name:
                continue

            priority = self.RISK_PRIORITY.get(
                risk,
                "LOW"
            )

            reason = self._build_reason(
                risk,
                intelligence
            )

            plan.append(
                PlannedTest(
                    tester_name=tester_name,
                    risk=risk,
                    priority=priority,
                    reason=reason
                )
            )

        return self._sort_plan(plan)

    def _build_reason(
        self,
        risk: str,
        intelligence: EndpointIntelligence
    ) -> str:

        endpoint = intelligence.endpoint_profile
        parameters = intelligence.parameter_profiles

        if risk == "BOLA":

            return (
                "Endpoint contains an object-style "
                "path parameter."
            )
        if risk == "BROKEN_AUTHORIZATION":
            return (
        "Endpoint declares an authentication requirement "
        "and should be checked for unauthorized access."
            )
        if risk == "INPUT_VALIDATION":
            return (
        "Endpoint contains user-controlled parameters "
        "that should be checked against their declared "
        "input constraints."
            )   
        if risk == "SQL_INJECTION":

            injection_parameters = [
                parameter.name
                for parameter in parameters
                if parameter.injection_candidate
            ]

            return (
                "Endpoint contains injection-capable "
                f"parameters: {injection_parameters}"
            )

        if risk == "RATE_LIMITING":

            if endpoint.is_write_operation:
                return (
            "Endpoint performs a state-changing "
            "operation and should be tested for "
            "rate limiting."
                )

            if endpoint.potential_rate_limit_endpoint:
                return (
            "Endpoint was identified as a "
            "rate-limit candidate based on its "
            "path or request characteristics."
            )

            return (
            "Endpoint is a candidate for controlled "
            "rate-limit testing."
            )
        if risk == "SENSITIVE_DATA_EXPOSURE":
            return (
        "Endpoint accepts or exposes sensitive data "
        "and should be checked for unintended disclosure."

            )
        if risk == "SSRF":
            return (
        "Endpoint accepts a URL-like parameter and should be "
        "checked for server-side request forgery."
            )
        
        if risk == "SENSITIVE_DATA_EXPOSURE":

            sensitive_parameters = [
                parameter.name
                for parameter in parameters
                if parameter.is_sensitive_parameter
            ]

            return (
                "Endpoint contains sensitive "
                f"parameters: {sensitive_parameters}"
            )
        if risk == "BROKEN_AUTHORIZATION":
            return (
            "Endpoint appears to expose an object or "
            "protected resource and should be checked "
            "for unauthorized access."
            )
        if risk == "AUTHENTICATION":
            return (
        "Endpoint declares an authentication "
        "requirement and should be checked for "
        "authentication bypass."
        )

        if risk == "CORS":

            return (
                "Cross-origin policy should be "
                "validated for this endpoint."
            )

        if risk == "SECURITY_HEADERS":

            return (
                "Response security headers should "
                "be validated."
            )
        if risk == "MASS_ASSIGNMENT":
            return (
        "Endpoint accepts a request body and should be "
        "checked for unauthorized assignment of privileged fields."
            )

        return (
            f"Endpoint was classified with "
            f"{risk} risk."
        )
        if risk == "XSS":
            return (
        "Endpoint accepts user-controlled input that "
        "should be checked for reflected cross-site "
        "scripting."
    )

    def _sort_plan(
        self,
        plan: List[PlannedTest]
    ) -> List[PlannedTest]:

        priority_order = {
            "HIGH": 0,
            "MEDIUM": 1,
            "LOW": 2,
        }

        return sorted(
            plan,
            key=lambda test: priority_order.get(
                test.priority,
                99
            )
        )