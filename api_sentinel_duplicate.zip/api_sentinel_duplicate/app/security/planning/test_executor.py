from typing import Any, List


class TestExecutor:

    def __init__(self, registry):
        self.registry = registry

    def execute(self, endpoint, planned_tests) -> List[Any]:

        findings = []

        for planned_test in planned_tests:

            tester_name = planned_test.tester_name

            print()
            print(
                f"[EXECUTOR] Running {tester_name}"
            )

            tester = self.registry.get_tester(
                tester_name
            )

            if tester is None:

                print(
                    f"[EXECUTOR] Tester not found: "
                    f"{tester_name}"
                )

                continue

            try:

                tester_findings = tester.test(
                    endpoint
                )

            except Exception as error:

                print(
                    f"[EXECUTOR ERROR] "
                    f"{tester_name}: {error}"
                )

                continue

            if tester_findings:

                print(
                    f"[EXECUTOR] {tester_name} "
                    f"returned "
                    f"{len(tester_findings)} finding(s)"
                )

                findings.extend(
                    tester_findings
                )

            else:

                print(
                    f"[EXECUTOR] {tester_name} "
                    "returned no findings"
                )

        return findings