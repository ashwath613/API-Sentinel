from typing import Dict

from app.security.testers.bola import BOLATester
from app.security.testers.sqli import SQLInjectionTester
from app.security.testers.rate_limit import RateLimitTester
from app.security.testers.cors import CORSTester
from app.security.testers.security_headers import SecurityHeadersTester
from app.security.testers.authorization import AuthorizationTester
from app.security.testers.authorization import (
    AuthorizationTester,
)
from app.security.testers.auth import (
    AuthenticationTester,
)
from app.security.testers.input_validation import (
    InputValidationTester,
)
from app.security.testers.xss import XSSTester
from app.security.testers.sensitive_data import (
    SensitiveDataTester,
)
from app.security.testers.mass_assignment import (
    MassAssignmentTester,
)
from app.security.testers.ssrf import SSRFTester

class TestRegistry:

    def __init__(self):

        self._testers = {
            "BOLATester": BOLATester(),
            "SQLInjectionTester": SQLInjectionTester(),
            "RateLimitTester": RateLimitTester(),
            "CORSTester": CORSTester(),
            "SecurityHeadersTester": SecurityHeadersTester(),
            "AuthorizationTester": AuthorizationTester(),
            "AuthenticationTester": AuthenticationTester(),
            "InputValidationTester": InputValidationTester(),
            "XSSTester": XSSTester(),
            "SensitiveDataTester": SensitiveDataTester(),
            "MassAssignmentTester": MassAssignmentTester(),
            "SSRFTester": SSRFTester(),
        }

    def get_tester(self, tester_name: str):

        return self._testers.get(
            tester_name
        )

    def has_tester(self, tester_name: str) -> bool:

        return tester_name in self._testers

    def available_testers(self):

        return list(
            self._testers.keys()
        )