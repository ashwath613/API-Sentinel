from app.security.intelligence.security_intelligence import (
    SecurityIntelligence,
)

from app.security.planning.risk_mapper import (
    RiskMapper,
)

from app.security.planning.test_planner import (
    TestPlanner,
)

from app.security.planning.test_registry import (
    TestRegistry,
)

from app.security.planning.test_executor import (
    TestExecutor,
)

from app.security.findings.finding_pipeline import (
    FindingPipeline,
)


class SecurityScanEngine:

    def __init__(self):

        self.intelligence = SecurityIntelligence()

        self.risk_mapper = RiskMapper()

        self.test_planner = TestPlanner()

        self.test_registry = TestRegistry()

        self.test_executor = TestExecutor(
            self.test_registry
        )

        self.finding_pipeline = FindingPipeline()

    def run(self, endpoint):

        print()
        print("=" * 70)

        print(
            f"[SCAN ENGINE] "
            f"{endpoint.method} "
            f"{endpoint.path}"
        )

        # ==================================================
        # 1. SECURITY INTELLIGENCE
        # ==================================================

        intelligence = self.intelligence.analyze(
            endpoint
        )

        # ==================================================
        # 2. RISK MAPPING
        # ==================================================

        risks = self.risk_mapper.map_risks(
            intelligence
        )

        print()
        print(
            "[RISKS]",
            risks
        )

        # ==================================================
        # 3. TEST PLANNING
        # ==================================================

        plan = self.test_planner.create_plan(
            intelligence,
            risks
        )

        print()
        print("[PLAN]")

        for planned_test in plan:

            print(
                f"- {planned_test.tester_name} "
                f"[{planned_test.priority}]"
            )

        # ==================================================
        # 4. TEST EXECUTION
        # ==================================================

        raw_findings = self.test_executor.execute(
            endpoint,
            plan
        )

        print()
        print(
            f"[SCAN ENGINE] "
            f"Raw findings: "
            f"{len(raw_findings)}"
        )

        # ==================================================
        # 5. FINDING NORMALIZATION
        # ==================================================

        analyzed_findings = self.finding_pipeline.process(raw_findings)

        # ==================================================
        # 6. FINAL RESULT
        # ==================================================

        print()
        print(
        f"[SCAN ENGINE] "
        f"Analyzed findings: "
        f"{len(analyzed_findings)}"
        )

        for analyzed in analyzed_findings:

            print(
                f"[ANALYZED] "
                f"{analyzed.normalized.type} "
                f"| severity="
                f"{analyzed.normalized.severity} "
                f"| confidence="
                f"{analyzed.normalized.confidence} "
                f"| score="
                f"{analyzed.risk_score}"
    )

        return analyzed_findings