import requests

from app.db.models import Severity
from app.security.base import SecurityFinding, SecurityTester
from app.security.request_builder import RequestBuilder


class AuthorizationTester(SecurityTester):

    def __init__(self):
        self.request_builder = RequestBuilder()

    def test(self, endpoint):

        findings = []

        metadata = (
            endpoint.request_metadata
            or {}
        )

        security = metadata.get(
            "security"
        )

       
        if not security:

            print(
                f"[AUTHZ TEST] Skipping "
                f"{endpoint.method} {endpoint.path} "
                f"- no OpenAPI security requirement."
            )

            return findings

        request = self.request_builder.build(
            endpoint
        )

        url = request["url"]
        params = request["params"]

        method = (
            endpoint.method
            .upper()
        )

        print(
            f"[AUTHZ TEST] Testing "
            f"{method} {url}"
        )

       
        try:

            response = requests.request(
                method=method,
                url=url,
                params=params,
                timeout=10
            )

        except requests.RequestException as error:

            print(
                f"[AUTHZ TEST ERROR] "
                f"{error}"
            )

            return findings

        status_code = response.status_code

        print(
            f"[AUTHZ TEST] "
            f"Unauthenticated status: "
            f"{status_code}"
        )

        

        if status_code in {
            401,
            403
        }:

            print(
                "[AUTHZ TEST] "
                "Unauthenticated access rejected."
            )

            return findings

        

        if status_code == 404:

            print(
                "[AUTHZ TEST] "
                "Endpoint returned 404. "
                "Authorization result is inconclusive."
            )

            return findings

        

        if status_code >= 500:

            print(
                "[AUTHZ TEST] "
                "Server error received. "
                "Authorization result is inconclusive."
            )

            return findings

       
        if 200 <= status_code < 300:

            print(
                "[AUTHZ TEST] "
                "POSSIBLE BROKEN AUTHORIZATION DETECTED"
            )

            findings.append(
                SecurityFinding(
                    type="POSSIBLE_BROKEN_AUTHORIZATION",
                    severity=Severity.HIGH,
                    description=(
                        "An endpoint declared as protected "
                        "by its OpenAPI security requirements "
                        "accepted an unauthenticated request."
                    ),
                    evidence=(
                        f"{method} {url} returned HTTP "
                        f"{status_code} without an "
                        "authentication header."
                    ),
                    confidence=0.85
                )
            )

            return findings

        

        print(
            "[AUTHZ TEST] "
            "No authorization finding."
        )

        return findings