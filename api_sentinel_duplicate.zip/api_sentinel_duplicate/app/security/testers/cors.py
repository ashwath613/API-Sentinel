import requests

from app.db.models import Severity
from app.security.base import SecurityFinding, SecurityTester
from app.security.request_builder import RequestBuilder


class CORSTester(SecurityTester):

    TEST_ORIGINS = [
        "https://evil.example",
        "https://attacker.example",
        "null",
    ]

    def __init__(self):
        self.request_builder = RequestBuilder()

    def test(self, endpoint):
        method = endpoint.method.upper()

        if method == "DELETE":
            print(
        f"[CORS TEST] Skipping DELETE "
        f"{endpoint.path} - destructive testing "
        f"is disabled."
    )
            return []

        findings = []

        print(
            f"[CORS TEST] Endpoint: "
            f"{endpoint.method} {endpoint.url}"
        )

        for origin in self.TEST_ORIGINS:

            response = self._send_preflight(
                endpoint,
                origin
            )


            if (
                response is not None
                and response.status_code == 405
            ):

                print(
                    "[CORS TEST] OPTIONS returned 405. "
                    "Using fallback request."
                )

                response = self._send_fallback_request(
                    endpoint,
                    origin
                )

            if response is None:
                continue

            findings.extend(
                self._analyze_response(
                    origin,
                    response
                )
            )

        findings = self._deduplicate_findings(
            findings
        )

        print(
            f"[CORS TEST] Findings: "
            f"{len(findings)}"
        )

        return findings

    

    def _send_preflight(
        self,
        endpoint,
        origin
    ):

        url = self._build_url(
            endpoint
        )

        try:

            response = requests.options(
                url,
                headers={
                    "Origin": origin,
                    "Access-Control-Request-Method":
                        endpoint.method.upper(),
                    "Access-Control-Request-Headers":
                        "Authorization, Content-Type",
                },
                timeout=10
            )

            print(
                f"[CORS TEST] Origin: {origin}"
            )

            print(
                f"[CORS TEST] OPTIONS status: "
                f"{response.status_code}"
            )

            print(
                "[CORS TEST] "
                "Access-Control-Allow-Origin:",
                response.headers.get(
                    "Access-Control-Allow-Origin"
                )
            )

            print(
                "[CORS TEST] "
                "Access-Control-Allow-Credentials:",
                response.headers.get(
                    "Access-Control-Allow-Credentials"
                )
            )

            return response

        except requests.RequestException as error:

            print(
                f"[CORS TEST ERROR] "
                f"OPTIONS request failed: "
                f"{error}"
            )

            return None

    

    def _send_fallback_request(
        self,
        endpoint,
        origin
    ):

        request = self.request_builder.build(
            endpoint
        )

        url = request["url"]
        params = request.get(
            "params",
            {}
        )
        json_body = request.get(
            "json"
        )
        headers = dict(
            request.get(
                "headers",
                {}
            )
        )

        headers["Origin"] = origin

        method = request["method"]

        print(
            f"[CORS TEST] Fallback {method}"
        )

        if json_body is not None:

            print(
                f"[CORS TEST] "
                f"Fallback JSON body: "
                f"{json_body}"
            )

        try:

            response = requests.request(
                method=method,
                url=url,
                params=params,
                json=json_body,
                headers=headers,
                timeout=10
            )

            print(
                f"[CORS TEST] Fallback {method} "
                f"status: {response.status_code}"
            )

            print(
                "[CORS TEST] Fallback "
                "Access-Control-Allow-Origin:",
                response.headers.get(
                    "Access-Control-Allow-Origin"
                )
            )

            print(
                "[CORS TEST] Fallback "
                "Access-Control-Allow-Credentials:",
                response.headers.get(
                    "Access-Control-Allow-Credentials"
                )
            )

            return response

        except requests.RequestException as error:

            print(
                f"[CORS TEST ERROR] "
                f"Fallback request failed: "
                f"{error}"
            )

            return None

    

    def _analyze_response(
        self,
        origin,
        response
    ):

        findings = []

        allow_origin = response.headers.get(
            "Access-Control-Allow-Origin"
        )

        allow_credentials = response.headers.get(
            "Access-Control-Allow-Credentials"
        )

        
        if allow_origin == "*":

            findings.append(
                SecurityFinding(
                    type="CORS_WILDCARD",
                    severity=Severity.MEDIUM,
                    description=(
                        "The API allows cross-origin "
                        "requests from any origin."
                    ),
                    evidence=(
                        f"Origin sent: {origin}. "
                        "Access-Control-Allow-Origin: *."
                    ),
                    confidence=0.90
                )
            )

        
        elif allow_origin == origin:

            if self._is_true(
                allow_credentials
            ):

                findings.append(
                    SecurityFinding(
                        type=(
                            "CORS_REFLECTS_ORIGIN_"
                            "WITH_CREDENTIALS"
                        ),
                        severity=Severity.HIGH,
                        description=(
                            "The API reflected an arbitrary "
                            "requester-supplied origin while "
                            "also allowing credentials."
                        ),
                        evidence=(
                            f"Origin sent: {origin}. "
                            f"Access-Control-Allow-Origin: "
                            f"{allow_origin}. "
                            "Access-Control-Allow-Credentials: "
                            "true."
                        ),
                        confidence=0.95
                    )
                )

            else:

                findings.append(
                    SecurityFinding(
                        type="CORS_REFLECTS_ORIGIN",
                        severity=Severity.HIGH,
                        description=(
                            "The API reflected a requester-"
                            "supplied origin in the CORS "
                            "response."
                        ),
                        evidence=(
                            f"Origin sent: {origin}. "
                            "The same value was returned in "
                            "Access-Control-Allow-Origin."
                        ),
                        confidence=0.90
                    )
                )

        
        if (
            allow_origin == "*"
            and self._is_true(
                allow_credentials
            )
        ):

            findings.append(
                SecurityFinding(
                    type="CORS_WILDCARD_WITH_CREDENTIALS",
                    severity=Severity.HIGH,
                    description=(
                        "The API returned a wildcard CORS "
                        "origin together with credentials."
                    ),
                    evidence=(
                        "Access-Control-Allow-Origin: *. "
                        "Access-Control-Allow-Credentials: true."
                    ),
                    confidence=0.95
                )
            )

        return findings

    

    def _build_url(
        self,
        endpoint
    ):

        request = self.request_builder.build(
            endpoint
        )

        return request["url"]

    

    @staticmethod
    def _is_true(value):

        if value is None:
            return False

        return (
            value.strip().lower()
            == "true"
        )

    @staticmethod
    def _deduplicate_findings(
        findings
    ):

        unique = []

        seen = set()

        for finding in findings:

            fingerprint = (
                finding.type,
                finding.evidence
            )

            if fingerprint in seen:
                continue

            seen.add(
                fingerprint
            )

            unique.append(
                finding
            )

        return unique