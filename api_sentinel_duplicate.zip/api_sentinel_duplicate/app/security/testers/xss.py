import requests

from app.db.models import Severity
from app.security.base import SecurityFinding, SecurityTester
from app.security.request_builder import RequestBuilder


class XSSTester(SecurityTester):

    TEST_PAYLOADS = [
        "<script>alert(1)</script>",
        '"><script>alert(1)</script>',
        "<img src=x onerror=alert(1)>",
    ]

    HTML_CONTENT_TYPES = {
        "text/html",
        "application/xhtml+xml",
    }

    def __init__(self):
        self.request_builder = RequestBuilder()

    
    

    def test(self, endpoint):

        findings = []

        metadata = (
            endpoint.request_metadata
            or {}
        )

        parameters = metadata.get(
            "parameters",
            []
        )

        query_parameters = [
            parameter
            for parameter in parameters
            if parameter.get("in") == "query"
        ]

        if not query_parameters:

            print(
                f"[XSS TEST] Skipping "
                f"{endpoint.method} {endpoint.path} "
                f"- no query parameters."
            )

            return findings

        for parameter in query_parameters:

            parameter_name = parameter.get(
                "name"
            )

            if not parameter_name:
                continue

            print(
                f"[XSS TEST] Parameter: "
                f"{parameter_name}"
            )

            finding = self._test_parameter(
                endpoint=endpoint,
                parameter_name=parameter_name,
            )

            if finding:
                findings.append(
                    finding
                )

        return self._deduplicate(
            findings
        )

    

    def _test_parameter(
        self,
        endpoint,
        parameter_name
    ):

        for payload in self.TEST_PAYLOADS:

            try:

                request = (
                    self.request_builder.build(
                        endpoint
                    )
                )

            except Exception as error:

                print(
                    f"[XSS TEST ERROR] "
                    f"Could not build request: {error}"
                )

                return None

            params = dict(
                request.get(
                    "params",
                    {}
                )
            )

            params[parameter_name] = payload

            print(
                f"[XSS TEST] "
                f"{parameter_name}={payload}"
            )

            try:

                response = requests.request(
                    method=endpoint.method.upper(),
                    url=request["url"],
                    params=params,
                    json=request.get("json"),
                    headers=request.get(
                        "headers",
                        {}
                    ),
                    timeout=10,
                )

            except requests.RequestException as error:

                print(
                    f"[XSS TEST ERROR] "
                    f"{error}"
                )

                continue

            print(
                f"[XSS TEST] "
                f"Status: {response.status_code}"
            )

            

            if response.status_code < 200:
                continue

            if response.status_code >= 500:
                continue

            content_type = (
                response.headers.get(
                    "Content-Type",
                    ""
                )
                .lower()
                .split(";")[0]
                .strip()
            )

            body = response.text

            exact_reflection = (
                payload in body
            )

            html_response = (
                content_type
                in self.HTML_CONTENT_TYPES
            )

            print(
                f"[XSS TEST] "
                f"Content-Type: {content_type}"
            )

            print(
                f"[XSS TEST] "
                f"Exact reflection: "
                f"{exact_reflection}"
            )

            

            if not exact_reflection:

                print(
                    "[XSS TEST] "
                    "Payload was not reflected."
                )

                continue

            
            if not html_response:

                print(
                    "[XSS TEST] "
                    "Payload reflected, but response "
                    "is not HTML. No XSS finding."
                )

                continue

            

            print(
                "[XSS TEST] "
                "Payload reflected in HTML response."
            )

          

            encoded_payloads = [
                "&lt;script&gt;",
                "&lt;img",
                "&lt;/script&gt;",
                "&quot;&gt;",
                "&#60;script&#62;",
                "&#60;img",
            ]

            encoded = any(
                encoded_value in body
                for encoded_value
                in encoded_payloads
            )

            if encoded:

                print(
                    "[XSS TEST] "
                    "Payload appears to be HTML encoded."
                )

                continue

            

            return SecurityFinding(
                type="POSSIBLE_REFLECTED_XSS",
                severity=Severity.HIGH,
                description=(
                    f"User-controlled parameter "
                    f"'{parameter_name}' was reflected "
                    "directly in an HTML response without "
                    "evidence of HTML output encoding."
                ),
                evidence=(
                    f"Parameter: {parameter_name}. "
                    f"Payload: {payload}. "
                    f"HTTP status: "
                    f"{response.status_code}. "
                    f"Content-Type: {content_type}. "
                    "The exact payload was reflected "
                    "in the HTML response."
                ),
                confidence=0.85,
            )

        return None

    

    @staticmethod
    def _deduplicate(
        findings
    ):

        unique = []
        seen = set()

        for finding in findings:

            fingerprint = (
                finding.type,
                finding.description,
                finding.evidence,
            )

            if fingerprint in seen:
                continue

            seen.add(
                fingerprint
            )

            unique.append(
                finding
            )

        return unique