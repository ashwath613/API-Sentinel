import re

import requests

from app.db.models import Severity
from app.security.base import SecurityFinding, SecurityTester
from app.security.request_builder import RequestBuilder


class SQLInjectionTester(SecurityTester):

    TRUE_PAYLOADS = [
        "' OR '1'='1",
        '" OR "1"="1',
        "' OR 1=1 --",
        "' OR 1=1#",
    ]

    FALSE_PAYLOADS = [
        "' AND '1'='2",
        '" AND "1"="2',
        "' AND 1=2 --",
        "' AND 1=2#",
    ]

    ERROR_PAYLOADS = [
        "'",
        '"',
        "')",
        '")',
    ]

    ERROR_SIGNATURES = {
        "sql syntax",
        "mysql",
        "postgresql",
        "sqlite",
        "ora-",
        "oracle",
        "syntax error",
        "unclosed quotation mark",
        "sqlstate",
        "odbc",
        "jdbc",
        "database error",
    }

    def __init__(self):
        self.request_builder = RequestBuilder()

    
    def test(self, endpoint):

        findings = []

        metadata = (
            endpoint.request_metadata
            or {}
        )

        parameters = metadata.get(
            "parameters",
            []
        )

        query_parameters = [
            parameter
            for parameter in parameters
            if parameter.get("in") == "query"
        ]

        if not query_parameters:
            return findings

        request = self.request_builder.build(
            endpoint
        )

        method = endpoint.method.upper()

        for parameter in query_parameters:

            name = parameter.get(
                "name"
            )

            if not name:
                continue

            schema = parameter.get(
                "schema",
                {}
            )

            parameter_type = schema.get(
                "type"
            )

            

            if parameter_type not in {
                None,
                "string",
            }:
                continue

            print(
                f"[SQLI TEST] Parameter: {name}"
            )

            print(
                f"[SQLI TEST] Type: "
                f"{parameter_type or 'unknown'}"
            )

            baseline_value = self._default_value(
                parameter
            )

            print(
                f"[SQLI TEST] Normal: {baseline_value}"
            )

            

            baseline = self._send(
                method=method,
                url=request["url"],
                params=request.get(
                    "params",
                    {}
                ),
                json_body=request.get(
                    "json"
                ),
                headers=request.get(
                    "headers",
                    {}
                ),
                parameter_name=name,
                parameter_value=baseline_value,
            )

            if baseline is None:
                continue

            print(
                f"[SQLI TEST] "
                f"{name}={baseline_value}"
            )

            print(
                f"[SQLI TEST] "
                f"Status: {baseline['status']}"
            )

            print(
                f"[SQLI TEST] "
                f"Response length: "
                f"{baseline['length']}"
            )

            

            true_payload = self.TRUE_PAYLOADS[0]
            false_payload = self.FALSE_PAYLOADS[0]

            print(
                f"[SQLI TEST] TRUE: "
                f"{true_payload}"
            )

            print(
                f"[SQLI TEST] FALSE: "
                f"{false_payload}"
            )

            true_response = self._send(
                method=method,
                url=request["url"],
                params=request.get(
                    "params",
                    {}
                ),
                json_body=request.get(
                    "json"
                ),
                headers=request.get(
                    "headers",
                    {}
                ),
                parameter_name=name,
                parameter_value=true_payload,
            )

            false_response = self._send(
                method=method,
                url=request["url"],
                params=request.get(
                    "params",
                    {}
                ),
                json_body=request.get(
                    "json"
                ),
                headers=request.get(
                    "headers",
                    {}
                ),
                parameter_name=name,
                parameter_value=false_payload,
            )

            if (
                true_response is None
                or false_response is None
            ):
                continue

            print(
                f"[SQLI TEST] "
                f"{name}={true_payload}"
            )

            print(
                f"[SQLI TEST] "
                f"Status: {true_response['status']}"
            )

            print(
                f"[SQLI TEST] "
                f"Response length: "
                f"{true_response['length']}"
            )

            print(
                f"[SQLI TEST] "
                f"{name}={false_payload}"
            )

            print(
                f"[SQLI TEST] "
                f"Status: {false_response['status']}"
            )

            print(
                f"[SQLI TEST] "
                f"Response length: "
                f"{false_response['length']}"
            )

            normal_true_similarity = (
                self._similarity(
                    baseline["body"],
                    true_response["body"]
                )
            )

            normal_false_similarity = (
                self._similarity(
                    baseline["body"],
                    false_response["body"]
                )
            )

            true_false_similarity = (
                self._similarity(
                    true_response["body"],
                    false_response["body"]
                )
            )

            print(
                f"[SQLI BOOLEAN] "
                f"Normal/TRUE similarity: "
                f"{normal_true_similarity:.3f}"
            )

            print(
                f"[SQLI BOOLEAN] "
                f"Normal/FALSE similarity: "
                f"{normal_false_similarity:.3f}"
            )

            print(
                f"[SQLI BOOLEAN] "
                f"TRUE/FALSE similarity: "
                f"{true_false_similarity:.3f}"
            )

            
            strong_boolean_signal = (
                true_false_similarity >= 0.90
                and normal_true_similarity <= 0.30
                and normal_false_similarity <= 0.30
            )

            status_difference_signal = (
                baseline["status"]
                != true_response["status"]
                or baseline["status"]
                != false_response["status"]
            )

            large_response_difference = (
                self._relative_length_difference(
                    baseline["length"],
                    true_response["length"]
                ) >= 0.30
                or
                self._relative_length_difference(
                    baseline["length"],
                    false_response["length"]
                ) >= 0.30
            )

            if (
                strong_boolean_signal
                or (
                    true_false_similarity >= 0.90
                    and large_response_difference
                )
                or (
                    true_false_similarity >= 0.90
                    and status_difference_signal
                )
            ):

                print(
                    "[SQLI BOOLEAN] "
                    "Possible boolean-based SQL injection detected."
                )

                findings.append(
                    SecurityFinding(
                        type="POSSIBLE_SQL_INJECTION",
                        severity=Severity.HIGH,
                        description=(
                            f"The parameter '{name}' "
                            "produced substantially different "
                            "behavior for the baseline request "
                            "while TRUE and FALSE SQL-style "
                            "payloads produced highly similar "
                            "responses."
                        ),
                        evidence=(
                            f"Parameter '{name}': "
                            f"baseline length={baseline['length']}, "
                            f"TRUE length={true_response['length']}, "
                            f"FALSE length={false_response['length']}; "
                            f"Normal/TRUE similarity="
                            f"{normal_true_similarity:.3f}, "
                            f"Normal/FALSE similarity="
                            f"{normal_false_similarity:.3f}, "
                            f"TRUE/FALSE similarity="
                            f"{true_false_similarity:.3f}."
                        ),
                        confidence=0.90,
                    )
                )

            

            for payload in self.ERROR_PAYLOADS:

                print(
                    f"[SQLI ERROR] "
                    f"{name}={payload}"
                )

                response = self._send(
                    method=method,
                    url=request["url"],
                    params=request.get(
                        "params",
                        {}
                    ),
                    json_body=request.get(
                        "json"
                    ),
                    headers=request.get(
                        "headers",
                        {}
                    ),
                    parameter_name=name,
                    parameter_value=payload,
                )

                if response is None:
                    continue

                lowered_body = (
                    response["body"]
                    .lower()
                )

                matched_signature = next(
                    (
                        signature
                        for signature
                        in self.ERROR_SIGNATURES
                        if signature in lowered_body
                    ),
                    None,
                )

                if matched_signature:

                    print(
                        "[SQLI ERROR] "
                        f"Database error signature detected: "
                        f"{matched_signature}"
                    )

                    findings.append(
                        SecurityFinding(
                            type="POSSIBLE_SQL_INJECTION",
                            severity=Severity.HIGH,
                            description=(
                                f"The parameter '{name}' "
                                "appears to trigger a database "
                                "error when supplied with a "
                                "SQL metacharacter payload."
                            ),
                            evidence=(
                                f"Payload '{payload}' caused "
                                f"a response containing the "
                                f"database error signature "
                                f"'{matched_signature}'."
                            ),
                            confidence=0.95,
                        )
                    )

                    break

        return self._deduplicate(
            findings
        )

    

    @staticmethod
    def _send(
        method,
        url,
        params,
        json_body,
        headers,
        parameter_name,
        parameter_value,
    ):

        request_params = dict(
            params
            or {}
        )

        request_params[
            parameter_name
        ] = parameter_value

        try:

            response = requests.request(
                method=method,
                url=url,
                params=request_params,
                json=json_body,
                headers=headers,
                timeout=10,
            )

        except requests.RequestException as error:

            print(
                f"[SQLI TEST ERROR] "
                f"{error}"
            )

            return None

        return {
            "status": response.status_code,
            "body": response.text,
            "length": len(
                response.text
            ),
        }

    

    @staticmethod
    def _default_value(
        parameter
    ):

        schema = parameter.get(
            "schema",
            {}
        )

        if "default" in schema:
            return schema["default"]

        if "example" in parameter:
            return parameter["example"]

        if "example" in schema:
            return schema["example"]

        parameter_type = schema.get(
            "type"
        )

        if parameter_type == "integer":
            return 1

        if parameter_type == "number":
            return 1

        if parameter_type == "boolean":
            return True

        return "test"

    

    @staticmethod
    def _similarity(
        first,
        second
    ) -> float:

        if not first and not second:
            return 1.0

        if not first or not second:
            return 0.0

        first_tokens = set(
            re.findall(
                r"\w+",
                first.lower()
            )
        )

        second_tokens = set(
            re.findall(
                r"\w+",
                second.lower()
            )
        )

        if not first_tokens and not second_tokens:
            return 1.0

        if not first_tokens or not second_tokens:
            return 0.0

        intersection = (
            first_tokens
            & second_tokens
        )

        union = (
            first_tokens
            | second_tokens
        )

        return (
            len(intersection)
            / len(union)
        )

    

    @staticmethod
    def _relative_length_difference(
        first_length,
        second_length
    ) -> float:

        maximum = max(
            first_length,
            second_length,
            1
        )

        return (
            abs(
                first_length
                - second_length
            )
            / maximum
        )

    

    @staticmethod
    def _deduplicate(
        findings
    ):

        unique = []

        seen = set()

        for finding in findings:

            fingerprint = (
                finding.type,
                finding.description,
                finding.evidence,
            )

            if fingerprint in seen:
                continue

            seen.add(
                fingerprint
            )

            unique.append(
                finding
            )

        return unique