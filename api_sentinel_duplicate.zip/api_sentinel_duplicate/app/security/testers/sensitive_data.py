import re

import requests

from app.db.models import Severity
from app.security.base import SecurityFinding, SecurityTester
from app.security.request_builder import RequestBuilder


class SensitiveDataTester(SecurityTester):

    

    SENSITIVE_PATTERNS = {

        "JWT": re.compile(
            r"\beyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\b"
        ),

        "API_KEY": re.compile(
            r"\b(?:sk-[A-Za-z0-9_-]{16,}|"
            r"AIza[A-Za-z0-9_-]{20,})\b"
        ),

        "AWS_ACCESS_KEY": re.compile(
            r"\bAKIA[0-9A-Z]{16}\b"
        ),

        "EMAIL": re.compile(
            r"\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b",
            re.IGNORECASE,
        ),

        "PHONE": re.compile(
            r"\b(?:\+?\d[\d\s().-]{7,}\d)\b"
        ),
    }

    

    SENSITIVE_FIELD_NAMES = {
        "password",
        "passwd",
        "secret",
        "token",
        "access_token",
        "refresh_token",
        "api_key",
        "apikey",
        "authorization",
        "ssn",
        "credit_card",
        "card_number",
        "payment_card",
        "cvv",
        "customer_phone",
        "phone",
        "customer_email",
    }

    
    HIGH_CONFIDENCE_PATTERNS = {
        "JWT",
        "API_KEY",
        "AWS_ACCESS_KEY",
    }

    

    def __init__(self):

        self.request_builder = RequestBuilder()

    

    def test(self, endpoint):

        findings = []

        print(
            f"[SENSITIVE DATA TEST] "
            f"Endpoint: {endpoint.method.upper()} "
            f"{endpoint.path}"
        )

        

        request = self.request_builder.build(
            endpoint
        )

        try:

            response = requests.request(
                method=endpoint.method.upper(),
                url=request["url"],
                params=request.get(
                    "params",
                    {}
                ),
                json=request.get(
                    "json"
                ),
                headers=request.get(
                    "headers",
                    {}
                ),
                timeout=10,
            )

        except requests.RequestException as error:

            print(
                f"[SENSITIVE DATA TEST ERROR] "
                f"{error}"
            )

            return findings

        

        print(
            f"[SENSITIVE DATA TEST] "
            f"Status: {response.status_code}"
        )

        content_type = response.headers.get(
            "Content-Type",
            ""
        ).lower()

        print(
            f"[SENSITIVE DATA TEST] "
            f"Content-Type: {content_type}"
        )

        
        if response.status_code >= 400:

            print(
                "[SENSITIVE DATA TEST] "
                "Skipping response because HTTP status "
                f"is {response.status_code}."
            )

            return findings

        body = response.text

        

        response_data = None

        try:

            response_data = response.json()

        except ValueError:

            response_data = None

        if isinstance(
            response_data,
            (dict, list)
        ):

            exposed_fields = (
                self._find_sensitive_fields(
                    response_data
                )
            )

            for field_name, field_value in exposed_fields:

                # Ignore null fields because they don't expose
                # an actual value.
                if field_value is None:
                    continue

                masked_value = self._mask_value(
                    str(field_value)
                )

                print(
                    f"[SENSITIVE DATA TEST] "
                    f"Sensitive response field: "
                    f"{field_name}"
                )

                findings.append(
                    SecurityFinding(
                        type=(
                            "POSSIBLE_SENSITIVE_DATA_EXPOSURE"
                        ),
                        severity=Severity.HIGH,
                        description=(
                            f"Sensitive response field "
                            f"'{field_name}' appears to "
                            "be exposed."
                        ),
                        evidence=(
                            f"Response contains sensitive "
                            f"field '{field_name}' with "
                            f"value '{masked_value}'."
                        ),
                        confidence=0.90,
                    )
                )

        

        for pattern_name, pattern in (
            self.SENSITIVE_PATTERNS.items()
        ):

            match = pattern.search(
                body
            )

            if not match:
                continue

            matched_value = match.group(
                0
            )

            if self._is_placeholder_value(
                matched_value,
                pattern_name
            ):
                continue

            confidence = (
                0.90
                if pattern_name
                in self.HIGH_CONFIDENCE_PATTERNS
                else 0.65
            )

            severity = (
                Severity.HIGH
                if pattern_name
                in self.HIGH_CONFIDENCE_PATTERNS
                else Severity.MEDIUM
            )

            masked_value = self._mask_value(
                matched_value
            )

            print(
                f"[SENSITIVE DATA TEST] "
                f"Detected {pattern_name}: "
                f"{masked_value}"
            )

            findings.append(
                SecurityFinding(
                    type=(
                        "POSSIBLE_SENSITIVE_DATA_EXPOSURE"
                    ),
                    severity=severity,
                    description=(
                        "The response appears to contain "
                        f"a recognizable {pattern_name} "
                        "value."
                    ),
                    evidence=(
                        f"A {pattern_name} pattern was "
                        "detected in the response. "
                        f"Observed value: {masked_value}."
                    ),
                    confidence=confidence,
                )
            )

        
        

        return self._deduplicate(
            findings
        )

    

    @staticmethod
    def _find_sensitive_fields(
        data
    ):

        findings = []

        if isinstance(
            data,
            dict
        ):

            for key, value in data.items():

                normalized_key = (
                    str(key)
                    .strip()
                    .lower()
                )

                if (
                    normalized_key
                    in SensitiveDataTester.SENSITIVE_FIELD_NAMES
                ):

                    findings.append(
                        (
                            normalized_key,
                            value
                        )
                    )

                # Check nested objects/lists
                findings.extend(
                    SensitiveDataTester._find_sensitive_fields(
                        value
                    )
                )

        elif isinstance(
            data,
            list
        ):

            for item in data:

                findings.extend(
                    SensitiveDataTester._find_sensitive_fields(
                        item
                    )
                )

        return findings

    

    @staticmethod
    def _is_sensitive_parameter(
        parameter
    ) -> bool:

        name = (
            parameter.get(
                "name",
                ""
            )
            .strip()
            .lower()
        )

        return (
            name
            in SensitiveDataTester.SENSITIVE_FIELD_NAMES
        )

    

    @staticmethod
    def _field_appears_in_response(
        body,
        field_name
    ):

        patterns = [
            f'"{field_name}"',
            f"'{field_name}'",
            f'"{field_name}":',
            f"'{field_name}':",
        ]

        return any(
            pattern in body
            for pattern in patterns
        )

    

    @staticmethod
    def _mask_value(
        value
    ):

        if not value:

            return "***"

        if len(value) <= 6:

            return "***"

        return (
            value[:3]
            + "***"
            + value[-3:]
        )

    

    @staticmethod
    def _is_placeholder_value(
        value,
        pattern_name
    ):

        normalized = (
            value
            .lower()
            .strip()
        )

        placeholders = {
            "example.com",
            "test@example.com",
            "alice@example.com",
            "example.org",
            "localhost",
        }

        if pattern_name == "EMAIL":

            return any(
                placeholder
                in normalized
                for placeholder in placeholders
            )

        if pattern_name == "PHONE":

            digits = re.sub(
                r"\D",
                "",
                value
            )

            return (
                digits
                in {
                    "1234567890",
                    "5550101234",
                }
                or "555" in digits
            )

        return False

    

    @staticmethod
    def _deduplicate(
        findings
    ):

        unique = []

        seen = set()

        for finding in findings:

            fingerprint = (
                finding.type,
                finding.description,
                finding.evidence,
            )

            if fingerprint in seen:

                continue

            seen.add(
                fingerprint
            )

            unique.append(
                finding
            )

        return unique