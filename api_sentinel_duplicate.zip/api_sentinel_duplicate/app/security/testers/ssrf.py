import requests
from urllib.parse import urlparse

from app.db.models import Severity
from app.security.base import SecurityFinding, SecurityTester
from app.security.request_builder import RequestBuilder


class SSRFTester(SecurityTester):
    @staticmethod
    def _build_test_payloads(endpoint):
        parsed = urlparse(endpoint.url)

        if not parsed.scheme or not parsed.netloc:
            return []

        origin = (
            f"{parsed.scheme}://"
            f"{parsed.netloc}"
        )

        return [
        f"{origin}/",
        f"{origin}/health",
        f"{origin}/openapi.json",
    ]

    def __init__(self):
        self.request_builder = RequestBuilder()

    def test(self, endpoint):

        findings = []

        metadata = endpoint.request_metadata or {}

        parameters = metadata.get(
            "parameters",
            []
        )

        query_parameters = [
            parameter
            for parameter in parameters
            if parameter.get("in") == "query"
        ]

        if not query_parameters:

            print(
                f"[SSRF TEST] Skipping "
                f"{endpoint.method} {endpoint.path} "
                f"- no query parameters."
            )

            return findings

        for parameter in query_parameters:

            parameter_name = parameter.get(
                "name"
            )

            if not parameter_name:
                continue

            data_type = (
                parameter
                .get("schema", {})
                .get("type")
            )

            if data_type != "string":
                continue

            print(
                f"[SSRF TEST] Parameter: "
                f"{parameter_name}"
            )

            finding = self._test_parameter(
                endpoint,
                parameter_name
            )

            if finding:
                findings.append(
                    finding
                )

        return self._deduplicate(
            findings
        )

    def _test_parameter(
        self,
        endpoint,
        parameter_name
    ):

        request = self.request_builder.build(
            endpoint
        )

        baseline_params = dict(
            request.get(
                "params",
                {}
            )
        )

        

        baseline_params[parameter_name] = (
            "test"
        )

        try:

            baseline_response = requests.request(
                method=endpoint.method.upper(),
                url=request["url"],
                params=baseline_params,
                timeout=10
            )

        except requests.RequestException as error:

            print(
                f"[SSRF TEST ERROR] "
                f"Baseline request failed: "
                f"{error}"
            )

            return None

        print(
            f"[SSRF TEST] "
            f"Baseline status: "
            f"{baseline_response.status_code}"
        )

        baseline_body = baseline_response.text

        

        test_payloads = self._build_test_payloads(
    endpoint
)

        for payload in test_payloads:

            params = dict(
                request.get(
                    "params",
                    {}
                )
            )

            params[parameter_name] = payload

            print(
                f"[SSRF TEST] "
                f"{parameter_name}={payload}"
            )

            try:

                response = requests.request(
                    method=endpoint.method.upper(),
                    url=request["url"],
                    params=params,
                    timeout=10
                )

            except requests.RequestException as error:

                print(
                    f"[SSRF TEST ERROR] "
                    f"{error}"
                )

                continue

            print(
                f"[SSRF TEST] "
                f"Status: "
                f"{response.status_code}"
            )

            response_body = response.text

            

            indicators = [
                "SentinelAI Test Target",
                '"openapi"',
                "paths",
                "components",
                "HTTPValidationError",
            ]

            matched_indicators = [
                indicator
                for indicator in indicators
                if indicator in response_body
            ]

            if (
                response.status_code < 500
                and matched_indicators
                and response_body != baseline_body
            ):

                print(
                    "[SSRF TEST] "
                    "Possible server-side request "
                    "detected."
                )

                findings = [
                    SecurityFinding(
                        type="POSSIBLE_SSRF",
                        severity=Severity.HIGH,
                        description=(
                            f"The parameter "
                            f"'{parameter_name}' appears "
                            "capable of causing the server "
                            "to request an internal resource."
                        ),
                        evidence=(
                            f"Parameter: {parameter_name}. "
                            f"Payload: {payload}. "
                            f"HTTP status: "
                            f"{response.status_code}. "
                            f"Internal-response indicators: "
                            f"{matched_indicators}."
                        ),
                        confidence=0.85
                    )
                ]

                return findings[0]

        return None

    @staticmethod
    def _deduplicate(
        findings
    ):

        unique = []

        seen = set()

        for finding in findings:

            fingerprint = (
                finding.type,
                finding.evidence,
            )

            if fingerprint in seen:
                continue

            seen.add(
                fingerprint
            )

            unique.append(
                finding
            )

        return unique