import requests

from app.db.models import Severity
from app.security.base import SecurityFinding, SecurityTester
from app.security.request_builder import RequestBuilder


class InputValidationTester(SecurityTester):

    def __init__(self):
        self.request_builder = RequestBuilder()

    def test(self, endpoint):

        findings = []

        metadata = endpoint.request_metadata or {}

        parameters = metadata.get(
            "parameters",
            []
        )

        query_parameters = [
            parameter
            for parameter in parameters
            if parameter.get("in") == "query"
        ]

        if not query_parameters:

            print(
                f"[INPUT TEST] Skipping "
                f"{endpoint.method} {endpoint.path} "
                f"- no query parameters."
            )

            return findings

        for parameter in query_parameters:

            parameter_name = parameter.get("name")

            if not parameter_name:
                continue

            schema = parameter.get(
                "schema",
                {}
            )

            parameter_type = schema.get(
                "type",
                "string"
            )

            required = parameter.get(
                "required",
                False
            )

            print(
                f"[INPUT TEST] Parameter: "
                f"{parameter_name}"
            )

            print(
                f"[INPUT TEST] Type: "
                f"{parameter_type}"
            )

            findings.extend(
                self._test_parameter(
                    endpoint=endpoint,
                    parameter=parameter,
                    parameter_name=parameter_name,
                    parameter_type=parameter_type,
                    required=required,
                    schema=schema
                )
            )

        return self._deduplicate(
            findings
        )

    # ==========================================================
    # PARAMETER TESTING
    # ==========================================================

    def _test_parameter(
        self,
        endpoint,
        parameter,
        parameter_name,
        parameter_type,
        required,
        schema
    ):

        findings = []

        # --------------------------------------------------
        # Missing required parameter
        # --------------------------------------------------

        if required:

            finding = self._test_missing_required(
                endpoint,
                parameter_name
            )

            if finding:
                findings.append(
                    finding
                )

        # --------------------------------------------------
        # Invalid type
        # --------------------------------------------------

        finding = self._test_invalid_type(
            endpoint,
            parameter_name,
            parameter_type
        )

        if finding:
            findings.append(
                finding
            )

        # --------------------------------------------------
        # Schema constraints
        # --------------------------------------------------

        constraint_cases = (
            self._build_constraint_cases(
                parameter_type,
                schema
            )
        )

        for case in constraint_cases:

            finding = self._test_constraint(
                endpoint=endpoint,
                parameter_name=parameter_name,
                value=case["value"],
                reason=case["reason"]
            )

            if finding:
                findings.append(
                    finding
                )

        return findings

    # ==========================================================
    # MISSING REQUIRED PARAMETER
    # ==========================================================

    def _test_missing_required(
        self,
        endpoint,
        parameter_name
    ):

        request = self.request_builder.build(
            endpoint
        )

        params = dict(
            request["params"]
        )

        params.pop(
            parameter_name,
            None
        )

        try:

            response = requests.request(
                method=endpoint.method.upper(),
                url=request["url"],
                params=params,
                timeout=10
            )

        except requests.RequestException as error:

            print(
                f"[INPUT TEST ERROR] "
                f"Missing-value test: {error}"
            )

            return None

        print(
            f"[INPUT TEST] "
            f"Missing {parameter_name}"
            f" -> {response.status_code}"
        )

        if response.status_code in {
            400,
            422
        }:
            return None

        if 200 <= response.status_code < 300:

            return SecurityFinding(
                type="POSSIBLE_INPUT_VALIDATION_BYPASS",
                severity=Severity.MEDIUM,
                description=(
                    f"Required parameter "
                    f"'{parameter_name}' was omitted "
                    "but the endpoint accepted the request."
                ),
                evidence=(
                    f"Required parameter "
                    f"'{parameter_name}' was omitted "
                    f"and the server returned HTTP "
                    f"{response.status_code}."
                ),
                confidence=0.80
            )

        return None

    # ==========================================================
    # INVALID TYPE
    # ==========================================================

    def _test_invalid_type(
        self,
        endpoint,
        parameter_name,
        parameter_type
    ):

        invalid_value = (
            self._invalid_value_for_type(
                parameter_type
            )
        )

        if invalid_value is None:
            return None

        request = self.request_builder.build(
            endpoint
        )

        params = dict(
            request["params"]
        )

        params[parameter_name] = invalid_value

        try:

            response = requests.request(
                method=endpoint.method.upper(),
                url=request["url"],
                params=params,
                timeout=10
            )

        except requests.RequestException as error:

            print(
                f"[INPUT TEST ERROR] "
                f"Type test: {error}"
            )

            return None

        print(
            f"[INPUT TEST] "
            f"{parameter_name}={invalid_value}"
            f" -> {response.status_code}"
        )

        if response.status_code in {
            400,
            422
        }:
            return None

        if 200 <= response.status_code < 300:

            return SecurityFinding(
                type="POSSIBLE_INPUT_VALIDATION_BYPASS",
                severity=Severity.MEDIUM,
                description=(
                    f"Parameter '{parameter_name}' "
                    f"was declared as {parameter_type} "
                    "but accepted an incompatible value."
                ),
                evidence=(
                    f"Parameter '{parameter_name}' "
                    f"received '{invalid_value}' "
                    f"and returned HTTP "
                    f"{response.status_code}."
                ),
                confidence=0.85
            )

        return None

    # ==========================================================
    # CONSTRAINT CASES
    # ==========================================================

    def _build_constraint_cases(
        self,
        parameter_type,
        schema
    ):

        cases = []

        minimum = schema.get(
            "minimum"
        )

        maximum = schema.get(
            "maximum"
        )

        exclusive_minimum = schema.get(
            "exclusiveMinimum"
        )

        exclusive_maximum = schema.get(
            "exclusiveMaximum"
        )

        min_length = schema.get(
            "minLength"
        )

        max_length = schema.get(
            "maxLength"
        )

        pattern = schema.get(
            "pattern"
        )

        enum_values = schema.get(
            "enum"
        )

        # --------------------------------------------------
        # Numeric minimum
        # --------------------------------------------------

        if parameter_type in {
            "integer",
            "number"
        }:

            if minimum is not None:

                invalid_value = (
                    minimum - 1
                )

                cases.append(
                    {
                        "value": invalid_value,
                        "reason": (
                            f"value below minimum "
                            f"{minimum}"
                        )
                    }
                )

                if exclusive_minimum is True:

                    cases.append(
                        {
                            "value": minimum,
                            "reason": (
                                f"value equal to exclusive "
                                f"minimum {minimum}"
                            )
                        }
                    )

            # --------------------------------------------------
            # Numeric maximum
            # --------------------------------------------------

            if maximum is not None:

                invalid_value = (
                    maximum + 1
                )

                cases.append(
                    {
                        "value": invalid_value,
                        "reason": (
                            f"value above maximum "
                            f"{maximum}"
                        )
                    }
                )

                if exclusive_maximum is True:

                    cases.append(
                        {
                            "value": maximum,
                            "reason": (
                                f"value equal to exclusive "
                                f"maximum {maximum}"
                            )
                        }
                    )

        # --------------------------------------------------
        # String minimum length
        # --------------------------------------------------

        if (
            parameter_type == "string"
            and min_length is not None
        ):

            if min_length > 0:

                cases.append(
                    {
                        "value": "A" * (
                            min_length - 1
                        ),
                        "reason": (
                            f"string shorter than "
                            f"minLength {min_length}"
                        )
                    }
                )

        # --------------------------------------------------
        # String maximum length
        # --------------------------------------------------

        if (
            parameter_type == "string"
            and max_length is not None
        ):

            cases.append(
                {
                    "value": "A" * (
                        max_length + 1
                    ),
                    "reason": (
                        f"string longer than "
                        f"maxLength {max_length}"
                    )
                }
            )

        # --------------------------------------------------
        # Pattern
        # --------------------------------------------------

        if (
            parameter_type == "string"
            and pattern
        ):

            cases.append(
                {
                    "value": "INVALID_PATTERN_VALUE",
                    "reason": (
                        f"value does not satisfy "
                        f"pattern '{pattern}'"
                    )
                }
            )

        # --------------------------------------------------
        # Enum
        # --------------------------------------------------

        if enum_values:

            cases.append(
                {
                    "value": "__INVALID_ENUM_VALUE__",
                    "reason": (
                        f"value is outside declared "
                        f"enum {enum_values}"
                    )
                }
            )

        return cases

    # ==========================================================
    # CONSTRAINT TEST
    # ==========================================================

    def _test_constraint(
        self,
        endpoint,
        parameter_name,
        value,
        reason
    ):

        request = self.request_builder.build(
            endpoint
        )

        params = dict(
            request["params"]
        )

        params[parameter_name] = value

        try:

            response = requests.request(
                method=endpoint.method.upper(),
                url=request["url"],
                params=params,
                timeout=10
            )

        except requests.RequestException as error:

            print(
                f"[INPUT TEST ERROR] "
                f"Constraint test: {error}"
            )

            return None

        print(
            f"[INPUT TEST] "
            f"{parameter_name}={value} "
            f"({reason})"
            f" -> {response.status_code}"
        )

        # Proper validation behavior.
        if response.status_code in {
            400,
            422
        }:

            return None

        # Server-side error indicates the invalid input
        # reached application logic without proper handling.
        if response.status_code >= 500:

            return SecurityFinding(
                type="POSSIBLE_INPUT_VALIDATION_BYPASS",
                severity=Severity.MEDIUM,
                description=(
                    f"An invalid value for "
                    f"'{parameter_name}' caused "
                    "a server-side error instead of "
                    "being rejected by input validation."
                ),
                evidence=(
                    f"Test value: {value}. "
                    f"Reason: {reason}. "
                    f"Server returned HTTP "
                    f"{response.status_code}."
                ),
                confidence=0.75
            )

        # Invalid value was accepted.
        if 200 <= response.status_code < 300:

            return SecurityFinding(
                type="POSSIBLE_INPUT_VALIDATION_BYPASS",
                severity=Severity.MEDIUM,
                description=(
                    f"Parameter '{parameter_name}' "
                    "accepted a value that violates "
                    "its declared OpenAPI constraint."
                ),
                evidence=(
                    f"Test value: {value}. "
                    f"Constraint violation: {reason}. "
                    f"Server returned HTTP "
                    f"{response.status_code}."
                ),
                confidence=0.85
            )

        return None

    # ==========================================================
    # HELPERS
    # ==========================================================

    @staticmethod
    def _invalid_value_for_type(
        parameter_type
    ):

        if parameter_type in {
            "integer",
            "number"
        }:
            return "not-a-number"

        if parameter_type == "boolean":
            return "not-a-boolean"

        if parameter_type == "array":
            return "not-an-array"

        if parameter_type == "object":
            return "not-an-object"

        return None

    @staticmethod
    def _deduplicate(
        findings
    ):

        unique = []

        seen = set()

        for finding in findings:

            fingerprint = (
                finding.type,
                finding.evidence
            )

            if fingerprint in seen:
                continue

            seen.add(
                fingerprint
            )

            unique.append(
                finding
            )

        return unique