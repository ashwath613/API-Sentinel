import json

import requests

from app.db.models import Severity
from app.security.base import SecurityFinding, SecurityTester
from app.security.request_builder import RequestBuilder


class MassAssignmentTester(SecurityTester):

    TEST_FIELDS = {
        "is_admin": True,
        "role": "admin",
        "admin": True,
        "is_staff": True,
        "permissions": ["admin"],
    }

    def __init__(self):
        self.request_builder = RequestBuilder()

    def test(self, endpoint):

        findings = []

        metadata = endpoint.request_metadata or {}

        request_body = metadata.get(
            "request_body"
        )

        if not request_body:

            print(
                f"[MASS ASSIGNMENT TEST] Skipping "
                f"{endpoint.method} {endpoint.path} "
                f"- no request body declared."
            )

            return findings

        method = endpoint.method.upper()

        if method not in {
            "POST",
            "PUT",
            "PATCH",
        }:

            print(
                f"[MASS ASSIGNMENT TEST] Skipping "
                f"{method} {endpoint.path} "
                f"- method is not a write operation."
            )

            return findings

        print(
            f"[MASS ASSIGNMENT TEST] Testing "
            f"{method} {endpoint.path}"
        )

        request = self.request_builder.build(
            endpoint
        )

        base_body = dict(
            request.get(
                "json",
                {}
            )
            or {}
        )

        if not base_body:

            base_body = {
                "name": "test"
            }

        print(
            f"[MASS ASSIGNMENT TEST] "
            f"Base body: {base_body}"
        )

        for field, value in self.TEST_FIELDS.items():

            test_body = dict(
                base_body
            )

            test_body[field] = value

            print(
                f"[MASS ASSIGNMENT TEST] "
                f"Testing field: {field}"
            )

            try:

                response = requests.request(
                    method=method,
                    url=request["url"],
                    params=request.get(
                        "params",
                        {}
                    ),
                    json=test_body,
                    headers=request.get(
                        "headers",
                        {}
                    ),
                    timeout=10,
                )

            except requests.RequestException as error:

                print(
                    f"[MASS ASSIGNMENT TEST ERROR] "
                    f"{error}"
                )

                continue

            print(
                f"[MASS ASSIGNMENT TEST] "
                f"Status: {response.status_code}"
            )

            if response.status_code >= 500:
                continue

            response_data = self._parse_response(
                response
            )

            if response_data is None:
                continue

            returned_value = self._find_field_value(
                response_data,
                field
            )

            print(
                f"[MASS ASSIGNMENT TEST] "
                f"Injected value: {value}"
            )

            print(
                f"[MASS ASSIGNMENT TEST] "
                f"Returned value: {returned_value}"
            )

            # --------------------------------------------------
            # Strong signal:
            # server returned the exact privileged value
            # supplied by the attacker-controlled request.
            # --------------------------------------------------

            if self._values_match(
                value,
                returned_value
            ):

                print(
                    f"[MASS ASSIGNMENT TEST] "
                    f"Possible privileged field "
                    f"acceptance: {field}"
                )

                findings.append(
                    SecurityFinding(
                        type="POSSIBLE_MASS_ASSIGNMENT",
                        severity=Severity.HIGH,
                        description=(
                            f"The endpoint appears to accept "
                            f"the privileged field '{field}' "
                            "from the request body."
                        ),
                        evidence=(
                            f"Injected field '{field}' with "
                            f"value '{value}'. The server "
                            f"returned the same value for "
                            f"'{field}' in its response."
                        ),
                        confidence=0.90,
                    )
                )

        return self._deduplicate(
            findings
        )

    @staticmethod
    def _parse_response(
        response
    ):

        try:

            return response.json()

        except ValueError:

            try:
                return json.loads(
                    response.text
                )

            except (
                ValueError,
                TypeError
            ):
                return None

    @staticmethod
    def _find_field_value(
        data,
        field_name
    ):

        if isinstance(data, dict):

            if field_name in data:
                return data[field_name]

            for value in data.values():

                result = (
                    MassAssignmentTester._find_field_value(
                        value,
                        field_name
                    )
                )

                if result is not None:
                    return result

        elif isinstance(data, list):

            for item in data:

                result = (
                    MassAssignmentTester._find_field_value(
                        item,
                        field_name
                    )
                )

                if result is not None:
                    return result

        return None

    @staticmethod
    def _values_match(
        injected,
        returned
    ):

        if returned is None:
            return False

        return injected == returned

    @staticmethod
    def _deduplicate(
        findings
    ):

        unique = []

        seen = set()

        for finding in findings:

            fingerprint = (
                finding.type,
                finding.evidence,
            )

            if fingerprint in seen:
                continue

            seen.add(
                fingerprint
            )

            unique.append(
                finding
            )

        return unique