import requests

from app.db.models import Severity
from app.security.base import SecurityFinding, SecurityTester
from app.security.request_builder import RequestBuilder


class BOLATester(SecurityTester):

    REQUEST_TIMEOUT = 10

    def __init__(self):
        self.request_builder = RequestBuilder()

    

    def test(self, endpoint):

        method = endpoint.method.upper()

        

        if method == "DELETE":

            print(
                f"[BOLA TEST] Skipping DELETE "
                f"{endpoint.path} - destructive testing "
                f"is disabled."
            )

            return []

        findings = []

        print(
            f"[BOLA TEST] Endpoint: "
            f"{endpoint.method} {endpoint.url}"
        )

        metadata = (
            endpoint.request_metadata
            or {}
        )

        

        security = metadata.get(
            "security"
        )

        if not security:

            print(
                f"[BOLA TEST] Skipping "
                f"{endpoint.method} {endpoint.path} "
                f"- endpoint has no authentication/"
                f"security requirement."
            )

            return []

        parameters = metadata.get(
            "parameters",
            []
        )

        path_parameters = [
            parameter
            for parameter in parameters
            if parameter.get("in") == "path"
        ]

        print(
            f"[BOLA TEST] Path parameters: "
            f"{path_parameters}"
        )

        if not path_parameters:

            print(
                "[BOLA TEST] No path parameters. "
                "Skipping object-level authorization test."
            )

            return []

        for parameter in path_parameters:

            parameter_name = parameter.get(
                "name"
            )

            if not parameter_name:
                continue

            finding = self._test_object_parameter(
                endpoint=endpoint,
                parameter=parameter,
            )

            if finding:
                findings.append(
                    finding
                )

        print(
            f"[BOLA TEST] Findings: "
            f"{len(findings)}"
        )

        return self._deduplicate(
            findings
        )

    

    def _test_object_parameter(
        self,
        endpoint,
        parameter
    ):

        parameter_name = parameter.get(
            "name"
        )

        placeholder = (
            "{"
            + parameter_name
            + "}"
        )

        print(
            f"[BOLA TEST] Looking for placeholder: "
            f"{placeholder}"
        )

        if placeholder not in endpoint.url:

            print(
                "[BOLA TEST] Placeholder not found "
                f"in URL: {endpoint.url}"
            )

            return None

     

        first_id = "1"
        second_id = "2"

        first_url = endpoint.url.replace(
            placeholder,
            first_id
        )

        second_url = endpoint.url.replace(
            placeholder,
            second_id
        )

        print(
            f"[BOLA TEST] First URL: "
            f"{first_url}"
        )

        print(
            f"[BOLA TEST] Second URL: "
            f"{second_url}"
        )

        method = endpoint.method.upper()

        request_metadata = (
            endpoint.request_metadata
            or {}
        )

        

        body = None

        if method in {
            "POST",
            "PUT",
            "PATCH",
        }:

            try:

                request = (
                    self.request_builder.build(
                        endpoint
                    )
                )

                body = request.get(
                    "json"
                )

            except Exception as error:

                print(
                    f"[BOLA TEST] Could not build "
                    f"request body: {error}"
                )

                body = None

       

        params = self._build_query_parameters(
            request_metadata
        )

        

        try:

            request = (
                self.request_builder.build(
                    endpoint
                )
            )

            headers = dict(
                request.get(
                    "headers",
                    {}
                )
            )

        except Exception:

            headers = {}

        if method in {
            "POST",
            "PUT",
            "PATCH",
        }:

            headers.setdefault(
                "Content-Type",
                "application/json"
            )


        try:

            first_response = requests.request(
                method=method,
                url=first_url,
                params=params,
                json=body,
                headers=headers,
                timeout=self.REQUEST_TIMEOUT,
            )

        except requests.RequestException as error:

            print(
                f"[BOLA TEST ERROR] "
                f"First request failed: {error}"
            )

            return None

        

        try:

            second_response = requests.request(
                method=method,
                url=second_url,
                params=params,
                json=body,
                headers=headers,
                timeout=self.REQUEST_TIMEOUT,
            )

        except requests.RequestException as error:

            print(
                f"[BOLA TEST ERROR] "
                f"Second request failed: {error}"
            )

            return None

        print(
            "[BOLA TEST] First status:",
            first_response.status_code
        )

        print(
            "[BOLA TEST] Second status:",
            second_response.status_code
        )

        

        if (
            first_response.status_code >= 400
            and second_response.status_code >= 400
        ):

            print(
                "[BOLA TEST] Both object requests "
                "were rejected."
            )

            return None

        

        if (
            first_response.status_code < 300
            and second_response.status_code >= 400
        ):

            print(
                "[BOLA TEST] Alternate object access "
                "was rejected. No BOLA detected."
            )

            return None

        

        if (
            first_response.status_code >= 400
            and second_response.status_code < 300
        ):

            print(
                "[BOLA TEST] First object was rejected "
                "but alternate object was accessible."
            )

            print(
                "[BOLA TEST] Object ownership could not "
                "be established. Result is inconclusive."
            )

            return None

        

        if (
            first_response.status_code < 300
            and second_response.status_code < 300
        ):

            first_object = self._parse_json(
                first_response
            )

            second_object = self._parse_json(
                second_response
            )

            
            if (
                first_object is None
                or second_object is None
            ):

                print(
                    "[BOLA TEST] Successful responses "
                    "are not JSON objects."
                )

                print(
                    "[BOLA TEST] Authorization result "
                    "is inconclusive."
                )

                return None

            

            first_match = (
                self._object_id_matches_response(
                    response_data=first_object,
                    parameter_name=parameter_name,
                    expected_id=first_id,
                )
            )

            second_match = (
                self._object_id_matches_response(
                    response_data=second_object,
                    parameter_name=parameter_name,
                    expected_id=second_id,
                )
            )

            print(
                f"[BOLA TEST] First object ID match: "
                f"{first_match}"
            )

            print(
                f"[BOLA TEST] Second object ID match: "
                f"{second_match}"
            )

            
            if (
                first_match
                and second_match
                and first_object != second_object
            ):

                print(
                    "[BOLA TEST] POSSIBLE BOLA DETECTED"
                )

                return SecurityFinding(
                    type="POSSIBLE_BOLA",
                    severity=Severity.HIGH,
                    description=(
                        f"The authenticated endpoint "
                        f"allowed access to multiple distinct "
                        f"objects through the '{parameter_name}' "
                        "object identifier without an observable "
                        "authorization difference."
                    ),
                    evidence=(
                        f"{method} {first_url} returned "
                        f"HTTP {first_response.status_code} "
                        f"and the response corresponded to "
                        f"object ID {first_id}. "
                        f"{method} {second_url} returned "
                        f"HTTP {second_response.status_code} "
                        f"and the response corresponded to "
                        f"object ID {second_id}. "
                        "Both distinct objects were accessible "
                        "using the same authentication context."
                    ),
                    confidence=0.85,
                )

            

            if first_object == second_object:

                print(
                    "[BOLA TEST] Both identifiers returned "
                    "the same object."
                )

                print(
                    "[BOLA TEST] No BOLA detected."
                )

                return None

           

            print(
                "[BOLA TEST] Responses were different, "
                "but object ownership could not be "
                "confirmed."
            )

            print(
                "[BOLA TEST] Authorization result "
                "is inconclusive."
            )

            return None

        return None

    

    @staticmethod
    def _build_query_parameters(
        request_metadata
    ):

        params = {}

        parameters = request_metadata.get(
            "parameters",
            []
        )

        for parameter in parameters:

            if parameter.get("in") != "query":
                continue

            name = parameter.get(
                "name"
            )

            if not name:
                continue

            schema = parameter.get(
                "schema",
                {}
            )

            parameter_type = schema.get(
                "type"
            )

            if parameter_type == "integer":

                params[name] = 1

            elif parameter_type == "number":

                params[name] = 1

            elif parameter_type == "boolean":

                params[name] = True

            else:

                params[name] = "test"

        return params

    
    @staticmethod
    def _parse_json(
        response
    ):

        try:

            return response.json()

        except ValueError:

            return None

    

    @classmethod
    def _object_id_matches_response(
        cls,
        response_data,
        parameter_name,
        expected_id,
    ):

        expected_string = str(
            expected_id
        )

        

        if cls._find_named_value(
            data=response_data,
            field_name=parameter_name,
            expected_value=expected_string,
        ):

            return True

        

        if parameter_name != "id":

            if cls._find_named_value(
                data=response_data,
                field_name="id",
                expected_value=expected_string,
            ):

                return True

        return False

   

    @classmethod
    def _find_named_value(
        cls,
        data,
        field_name,
        expected_value,
    ):

        if isinstance(
            data,
            dict
        ):

            for key, value in data.items():

                normalized_key = (
                    str(key)
                    .strip()
                    .lower()
                )

                normalized_field = (
                    str(field_name)
                    .strip()
                    .lower()
                )

                if normalized_key == normalized_field:

                    if str(value) == expected_value:

                        return True

                if cls._find_named_value(
                    data=value,
                    field_name=field_name,
                    expected_value=expected_value,
                ):

                    return True

        elif isinstance(
            data,
            list
        ):

            for item in data:

                if cls._find_named_value(
                    data=item,
                    field_name=field_name,
                    expected_value=expected_value,
                ):

                    return True

        return False

    

    @staticmethod
    def _deduplicate(
        findings
    ):

        unique = []

        seen = set()

        for finding in findings:

            fingerprint = (
                finding.type,
                finding.description,
                finding.evidence,
            )

            if fingerprint in seen:
                continue

            seen.add(
                fingerprint
            )

            unique.append(
                finding
            )

        return unique