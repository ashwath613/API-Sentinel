import time
import requests

from app.db.models import Severity
from app.security.base import SecurityFinding, SecurityTester
from app.security.request_builder import RequestBuilder


class RateLimitTester(SecurityTester):

    DEFAULT_REQUEST_COUNT = 10
    DEFAULT_DELAY = 0.05
    REQUEST_TIMEOUT = 10

    # Endpoints where burst testing is especially meaningful.
    RATE_LIMIT_PATH_KEYWORDS = {
        "login",
        "signin",
        "sign-in",
        "signup",
        "sign-up",
        "register",
        "otp",
        "verify",
        "verification",
        "password-reset",
        "reset-password",
        "forgot-password",
        "token",
        "refresh",
        "export",
        "download",
        "upload",
        "send",
        "rate-limit",
        "ratelimit",
        "throttle",
        "throttling",
    }

    RATE_LIMIT_PARAMETER_NAMES = {
        "otp",
        "token",
        "code",
        "verification_code",
        "email",
        "phone",
    }

    WRITE_METHODS = {
        "POST",
        "PUT",
        "PATCH",
    }

    def __init__(self):
        self.request_builder = RequestBuilder()

    

    def test(self, endpoint):

        method = endpoint.method.upper()

        

        if method == "DELETE":

            print(
                f"[RATE LIMIT TEST] Skipping DELETE "
                f"{endpoint.path} - destructive testing "
                f"is disabled."
            )

            return []

        

        if not self._is_rate_limit_candidate(
            endpoint
        ):

            print(
                f"[RATE LIMIT TEST] Skipping "
                f"{endpoint.method} {endpoint.path} "
                f"- endpoint is not a meaningful "
                f"rate-limit candidate."
            )

            return []

        print(
            f"[RATE LIMIT TEST] "
            f"Endpoint: {endpoint.method} "
            f"{endpoint.url}"
        )

        

        try:

            request = self.request_builder.build(
                endpoint
            )

        except Exception as error:

            print(
                f"[RATE LIMIT TEST ERROR] "
                f"Could not build request: {error}"
            )

            return []

        url = request.get(
            "url"
        )

        params = request.get(
            "params",
            {}
        )

        json_body = request.get(
            "json"
        )

        headers = request.get(
            "headers",
            {}
        )

        print(
            f"[RATE LIMIT TEST] "
            f"URL: {url}"
        )

        if params:

            print(
                f"[RATE LIMIT TEST] "
                f"Params: {params}"
            )

        if json_body:

            print(
                f"[RATE LIMIT TEST] "
                f"JSON body: {json_body}"
            )

        
        responses = []

        for index in range(
            self.DEFAULT_REQUEST_COUNT
        ):

            result = self._send_request(
                endpoint=endpoint,
                url=url,
                params=params,
                json_body=json_body,
                headers=headers,
            )

            if result is None:

                print(
                    "[RATE LIMIT TEST] "
                    "Request failed. Stopping test."
                )

                return []

            responses.append(
                result
            )

            if (
                index
                < self.DEFAULT_REQUEST_COUNT - 1
            ):

                time.sleep(
                    self.DEFAULT_DELAY
                )

        return self._analyze_responses(
            endpoint=endpoint,
            responses=responses,
        )

    
    def _is_rate_limit_candidate(
        self,
        endpoint
    ) -> bool:

        metadata = (
            endpoint.request_metadata
            or {}
        )

        parameters = metadata.get(
            "parameters",
            []
        )

        parameter_names = {
            parameter.get(
                "name",
                ""
            ).strip().lower()
            for parameter in parameters
            if parameter.get("name")
        }

        path = (
            getattr(
                endpoint,
                "path",
                ""
            )
            or ""
        ).lower()

        method = (
            getattr(
                endpoint,
                "method",
                ""
            )
            or ""
        ).upper()

        

        if getattr(
            endpoint,
            "potential_rate_limit_endpoint",
            False
        ):

            return True

        
        normalized_path = (
            path
            .replace(
                "_",
                "-"
            )
        )

        for keyword in self.RATE_LIMIT_PATH_KEYWORDS:

            if keyword in normalized_path:
                return True

        

        if (
            parameter_names
            & self.RATE_LIMIT_PARAMETER_NAMES
        ):

            return True


        if method in self.WRITE_METHODS:

            action_words = {
                "create",
                "update",
                "login",
                "signin",
                "sign-in",
                "signup",
                "sign-up",
                "register",
                "verify",
                "verification",
                "reset",
                "password",
                "upload",
                "download",
                "send",
                "export",
                "import",
                "token",
                "refresh",
            }

            path_parts = {
                part
                for part in normalized_path.split("/")
                if part
            }

            if path_parts & action_words:

                return True

        return False

    

    def _send_request(
        self,
        endpoint,
        url,
        params,
        json_body,
        headers,
    ):

        method = endpoint.method.upper()

        start = time.perf_counter()

        try:

            response = requests.request(
                method=method,
                url=url,
                params=params,
                json=json_body,
                headers=headers,
                timeout=self.REQUEST_TIMEOUT,
            )

        except requests.RequestException as error:

            print(
                f"[RATE LIMIT TEST ERROR] "
                f"{error}"
            )

            return None

        elapsed = (
            time.perf_counter()
            - start
        )

        retry_after = response.headers.get(
            "Retry-After"
        )

        print(
            f"[RATE LIMIT TEST] "
            f"Status={response.status_code} "
            f"Time={elapsed:.3f}s"
        )

        if retry_after:

            print(
                f"[RATE LIMIT TEST] "
                f"Retry-After={retry_after}"
            )

        return {
            "status": response.status_code,
            "elapsed": elapsed,
            "retry_after": retry_after,
            "body_length": len(
                response.text
            ),
        }

    
    def _analyze_responses(
        self,
        endpoint,
        responses
    ):

        if not responses:

            return []

        statuses = [
            response["status"]
            for response in responses
        ]

        status_429_count = statuses.count(
            429
        )

        retry_after_count = sum(
            1
            for response in responses
            if response["retry_after"]
        )

        successful_count = sum(
            1
            for status in statuses
            if 200 <= status < 300
        )

        rate_limited_count = sum(
            1
            for status in statuses
            if status in {
                429,
                503,
                509,
            }
        )

        total_requests = len(
            responses
        )

        success_ratio = (
            successful_count
            / total_requests
        )

        rate_limit_ratio = (
            rate_limited_count
            / total_requests
        )

        print()

        print(
            f"[RATE LIMIT TEST] "
            f"Requests: {total_requests}"
        )

        print(
            f"[RATE LIMIT TEST] "
            f"Successful: {successful_count}"
        )

        print(
            f"[RATE LIMIT TEST] "
            f"429 responses: {status_429_count}"
        )

        print(
            f"[RATE LIMIT TEST] "
            f"Rate-limited responses: "
            f"{rate_limited_count}"
        )

        print(
            f"[RATE LIMIT TEST] "
            f"Success ratio: "
            f"{success_ratio:.2f}"
        )

        print(
            f"[RATE LIMIT TEST] "
            f"Rate-limit ratio: "
            f"{rate_limit_ratio:.2f}"
        )

        

        if (
            status_429_count > 0
            or retry_after_count > 0
            or rate_limited_count > 0
        ):

            print(
                "[RATE LIMIT TEST] "
                "Rate limiting response detected."
            )

            return []

        

        if (
            total_requests >= 10
            and successful_count >= 8
            and success_ratio >= 0.80
        ):

            print(
                "[RATE LIMIT TEST] "
                "No observable rate limiting signal "
                "detected on a rate-limit candidate."
            )

            return [
                SecurityFinding(
                    type="POSSIBLE_MISSING_RATE_LIMITING",
                    severity=Severity.MEDIUM,
                    description=(
                        "The rate-limit-sensitive endpoint "
                        "accepted a controlled burst of "
                        "requests without returning HTTP 429 "
                        "or another observable throttling signal."
                    ),
                    evidence=(
                        f"Endpoint: "
                        f"{endpoint.method.upper()} "
                        f"{endpoint.path}. "
                        f"Sent {total_requests} controlled "
                        f"requests. "
                        f"Successful responses: "
                        f"{successful_count}. "
                        f"HTTP 429 responses: "
                        f"{status_429_count}. "
                        f"Rate-limited responses: "
                        f"{rate_limited_count}. "
                        f"Response statuses: {statuses}."
                    ),
                    confidence=0.70,
                )
            ]

        return []