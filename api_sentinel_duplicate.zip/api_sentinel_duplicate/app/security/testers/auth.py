import requests

from app.db.models import Severity
from app.security.base import SecurityFinding, SecurityTester
from app.security.request_builder import RequestBuilder


class AuthenticationTester(SecurityTester):

    def __init__(self):
        self.request_builder = RequestBuilder()

    def test(self, endpoint):

        findings = []

        metadata = endpoint.request_metadata or {}

        security = metadata.get(
            "security"
        )

        # --------------------------------------------------
        # Authentication is only meaningful when the
        # OpenAPI definition declares a security requirement.
        # --------------------------------------------------

        if not security:

            print(
                f"[AUTH TEST] Skipping "
                f"{endpoint.method} {endpoint.path} "
                f"- no OpenAPI authentication requirement."
            )

            return findings

        request = self.request_builder.build(
            endpoint
        )

        url = request["url"]
        params = request["params"]

        method = endpoint.method.upper()

        print(
            f"[AUTH TEST] Testing "
            f"{method} {url}"
        )

        

        try:

            response = requests.request(
                method=method,
                url=url,
                params=params,
                timeout=10
            )

        except requests.RequestException as error:

            print(
                f"[AUTH TEST ERROR] "
                f"{error}"
            )

            return findings

        status_code = response.status_code

        print(
            f"[AUTH TEST] "
            f"Unauthenticated status: "
            f"{status_code}"
        )

        

        if status_code in {
            401,
            403
        }:

            print(
                "[AUTH TEST] "
                "Authentication was enforced."
            )

            return findings

       

        if status_code == 404:

            print(
                "[AUTH TEST] "
                "404 received. "
                "Authentication result is inconclusive."
            )

            return findings

        

        if status_code >= 500:

            print(
                "[AUTH TEST] "
                "Server error received. "
                "Authentication result is inconclusive."
            )

            return findings

        

        if 200 <= status_code < 300:

            print(
                "[AUTH TEST] "
                "POSSIBLE AUTHENTICATION BYPASS"
            )

            findings.append(
                SecurityFinding(
                    type="POSSIBLE_AUTHENTICATION_BYPASS",
                    severity=Severity.HIGH,
                    description=(
                        "An endpoint declared as requiring "
                        "authentication accepted an "
                        "unauthenticated request."
                    ),
                    evidence=(
                        f"{method} {url} returned HTTP "
                        f"{status_code} without an "
                        "authentication header."
                    ),
                    confidence=0.90
                )
            )

            return findings

        

        print(
            "[AUTH TEST] "
            "No authentication finding."
        )

        return findings