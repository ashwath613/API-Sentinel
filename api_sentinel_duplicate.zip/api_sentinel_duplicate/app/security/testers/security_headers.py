import requests

from app.db.models import Severity
from app.security.base import SecurityFinding, SecurityTester
from app.security.request_builder import RequestBuilder


class SecurityHeadersTester(SecurityTester):

    def __init__(self):
        self.request_builder = RequestBuilder()

    def test(self, endpoint):

        findings = []

        request = self.request_builder.build(
            endpoint
        )

        method = request["method"]
        url = request["url"]
        params = request.get(
            "params",
            {}
        )
        json_body = request.get(
            "json"
        )
        headers = request.get(
            "headers",
            {}
        )

        print(
            f"[HEADER TEST] Testing "
            f"{method} {url}"
        )

        if params:

            print(
                f"[HEADER TEST] Params: "
                f"{params}"
            )

        if json_body is not None:

            print(
                f"[HEADER TEST] "
                f"JSON body: "
                f"{json_body}"
            )

        try:

            response = requests.request(
                method=method,
                url=url,
                params=params,
                json=json_body,
                headers=headers,
                timeout=10
            )

            print(
                f"[HEADER TEST] Status: "
                f"{response.status_code}"
            )

        except requests.RequestException as error:

            print(
                f"[HEADER TEST ERROR] "
                f"{error}"
            )

            return findings

        required_headers = [
            "X-Content-Type-Options",
            "Content-Security-Policy",
            "Strict-Transport-Security",
        ]

        for header in required_headers:

            if header not in response.headers:

                findings.append(
                    SecurityFinding(
                        type="MISSING_SECURITY_HEADER",
                        severity=Severity.LOW,
                        description=(
                            f"Security header {header} "
                            "is missing."
                        ),
                        evidence=(
                            f"Response from {method} "
                            f"{url} does not contain "
                            f"{header}."
                        ),
                        confidence=0.95,
                    )
                )

        print(
            f"[HEADER TEST] Findings: "
            f"{len(findings)}"
        )

        return findings