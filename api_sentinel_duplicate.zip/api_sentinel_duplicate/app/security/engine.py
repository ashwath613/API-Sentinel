from app.security.testers.security_headers import SecurityHeadersTester
from app.security.testers.sqli import SQLInjectionTester
from app.security.testers.bola import BOLATester
from app.security.testers.rate_limit import RateLimitTester
from app.security.testers.cors import CORSTester

from app.security.intelligence.endpoint_classifier import (
    classify_endpoint
)

from app.security.planning.risk_mapper import (
    map_security_risks
)

from app.security.intelligence.test_planner import (
    create_test_plan
)


class SecurityTestEngine:

    def __init__(self):

        self.testers = {
            "SecurityHeadersTester": SecurityHeadersTester(),
            "SQLInjectionTester": SQLInjectionTester(),
            "BOLATester": BOLATester(),
            "RateLimitTester": RateLimitTester(),
            "CORSTester": CORSTester()
        }

    def run(self, endpoint):

        findings = []

      

        profile = classify_endpoint(endpoint)

        

        risks = map_security_risks(profile)

       

        test_plan = create_test_plan(risks)

        

        print(
            f"\n[INTELLIGENCE] "
            f"{endpoint.method} {endpoint.path}"
        )

        print(
            "[PROFILE]",
            profile
        )

        print(
            "[RISKS]",
            [risk.name for risk in risks]
        )

        print(
            "[PLAN]",
            [test.tester for test in test_plan]
        )

        

        for planned_test in test_plan:

            tester = self.testers.get(
                planned_test.tester
            )

            if tester is None:
                print(
                    f"[WARNING] Tester not found: "
                    f"{planned_test.tester}"
                )
                continue

            print(
                f"[RUNNING] {planned_test.tester}"
            )

            try:

                tester_findings = tester.test(
                    endpoint
                )

                if tester_findings:
                    print(
                        f"[FOUND] "
                        f"{len(tester_findings)} finding(s)"
                    )

                else:
                    print(
                        f"[NO FINDINGS] "
                        f"{planned_test.tester}"
                    )

                findings.extend(
                    tester_findings
                )

            except Exception as exc:

                print(
                    f"[ERROR] "
                    f"{planned_test.tester}: {exc}"
                )

        

        header_tester = self.testers[
            "SecurityHeadersTester"
        ]

        print(
            "[RUNNING] SecurityHeadersTester"
        )

        try:

            header_findings = header_tester.test(
                endpoint
            )

            if header_findings:

                print(
                    f"[FOUND] "
                    f"{len(header_findings)} "
                    f"security header finding(s)"
                )

            else:

                print(
                    "[NO FINDINGS] "
                    "SecurityHeadersTester"
                )

            findings.extend(
                header_findings
            )

        except Exception as exc:

            print(
                f"[ERROR] "
                f"SecurityHeadersTester: {exc}"
            )

        print(
            f"[ENGINE RESULT] "
            f"{len(findings)} finding(s) "
            f"for {endpoint.method} {endpoint.path}"
        )

        return findings