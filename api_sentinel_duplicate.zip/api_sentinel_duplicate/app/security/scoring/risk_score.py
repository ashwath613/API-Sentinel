from app.db.models import Severity


SEVERITY_WEIGHTS = {
    "CRITICAL": 10.0,
    "HIGH": 8.0,
    "MEDIUM": 5.0,
    "LOW": 2.0,
}


class RiskScoreCalculator:

    def calculate(
        self,
        severity,
        confidence: float,
        correlation_multiplier: float = 1.0
    ) -> float:

        severity_name = self._normalize_severity(
            severity
        )

        severity_weight = (
            SEVERITY_WEIGHTS.get(
                severity_name,
                SEVERITY_WEIGHTS["LOW"]
            )
        )

        confidence = max(
            0.0,
            min(
                float(confidence),
                1.0
            )
        )

        correlation_multiplier = max(
            0.0,
            float(correlation_multiplier)
        )

        score = (
            severity_weight
            * confidence
            * correlation_multiplier
        )

        return round(
            min(score, 10.0),
            2
        )

    def _normalize_severity(
        self,
        severity
    ) -> str:

        if hasattr(
            severity,
            "value"
        ):
            severity = severity.value

        normalized = str(
            severity
        ).upper().strip()

        if "." in normalized:
            normalized = normalized.rsplit(
                ".",
                1
            )[-1]

        return normalized