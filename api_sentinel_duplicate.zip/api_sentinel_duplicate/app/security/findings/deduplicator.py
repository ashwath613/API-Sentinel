from typing import List, Set

from app.security.findings.normalizer import (
    NormalizedFinding,
)


class FindingDeduplicator:

    def deduplicate(
        self,
        findings: List[NormalizedFinding]
    ) -> List[NormalizedFinding]:

        unique_findings = []

        seen_fingerprints: Set[str] = set()

        for finding in findings:

            if finding.fingerprint in seen_fingerprints:

                print(
                    "[DEDUPLICATOR] "
                    "Duplicate finding removed: "
                    f"{finding.fingerprint}"
                )

                continue

            seen_fingerprints.add(
                finding.fingerprint
            )

            unique_findings.append(
                finding
            )

        return unique_findings