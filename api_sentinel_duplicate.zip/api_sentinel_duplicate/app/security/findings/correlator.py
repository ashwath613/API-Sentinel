from dataclasses import dataclass
from typing import List

from app.security.findings.normalizer import (
    NormalizedFinding,
)


@dataclass
class CorrelatedFinding:
    finding: NormalizedFinding
    related_types: List[str]
    correlation_group: str


class FindingCorrelator:

    CORRELATION_GROUPS = {
    

        "AUTHENTICATION_AUTHORIZATION": {
            "POSSIBLE_AUTHENTICATION_BYPASS",
            "AUTHENTICATION_BYPASS",
            "POSSIBLE_BROKEN_AUTHORIZATION",
            "BROKEN_AUTHORIZATION",
            "FUNCTION_LEVEL_AUTHORIZATION",
            "MISSING_AUTHENTICATION",
        },

      

        "AUTHORIZATION": {
            "POSSIBLE_BOLA",
            "BOLA",
            "OBJECT_LEVEL_AUTHORIZATION",
        },

        "INJECTION": {
            "POSSIBLE_SQL_INJECTION",
            "SQL_INJECTION",
            "COMMAND_INJECTION",
            "PATH_TRAVERSAL",
        },


        "CONFIGURATION": {
            "CORS_WILDCARD",
            "CORS_REFLECTS_ORIGIN",
            "CORS_REFLECTS_ORIGIN_WITH_CREDENTIALS",
            "CORS_WILDCARD_WITH_CREDENTIALS",
            "MISSING_SECURITY_HEADER",
            "CORS",
            "SECURITY_HEADERS",
        },


        "INPUT_HANDLING": {
            "INPUT_VALIDATION",
            "POSSIBLE_SQL_INJECTION",
            "SQL_INJECTION",
            "COMMAND_INJECTION",
            "PATH_TRAVERSAL",
        },


        "RATE_LIMITING": {
            "POSSIBLE_MISSING_RATE_LIMITING",
            "MISSING_RATE_LIMITING",
            "RATE_LIMITING",
        },
    }

    def correlate(
        self,
        findings: List[NormalizedFinding],
    ) -> List[CorrelatedFinding]:

        correlated = []

        for finding in findings:

            finding_type = (
                finding.type
                .upper()
                .strip()
            )

            correlation_group = "GENERAL"
            related_types = []

            for (
                group_name,
                types,
            ) in self.CORRELATION_GROUPS.items():

                if finding_type in types:

                    correlation_group = (
                        group_name
                    )

                    related_types = sorted(
                        types
                    )

                    break

            correlated.append(
                CorrelatedFinding(
                    finding=finding,
                    related_types=related_types,
                    correlation_group=(
                        correlation_group
                    ),
                )
            )

        return correlated