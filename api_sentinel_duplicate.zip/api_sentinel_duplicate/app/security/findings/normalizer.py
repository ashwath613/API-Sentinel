from dataclasses import dataclass
from typing import Optional, Any

from app.security.base import SecurityFinding


@dataclass
class NormalizedFinding:
    type: str
    severity: str
    description: str
    evidence: str
    confidence: float

    fingerprint: str

    parameter: Optional[str] = None
    location: Optional[str] = None

    original_finding: Optional[Any] = None


class FindingNormalizer:

    def normalize(
        self,
        finding: SecurityFinding
    ) -> NormalizedFinding:

        finding_type = self._normalize_type(
            finding.type
        )

        severity = self._normalize_severity(
            finding.severity
        )

        description = (
            finding.description or ""
        ).strip()

        evidence = (
            finding.evidence or ""
        ).strip()

        confidence = float(
            finding.confidence
        )

        parameter = self._extract_parameter(
            description,
            evidence
        )

        location = self._determine_location(
            finding_type
        )

        fingerprint = self._build_fingerprint(
            finding_type=finding_type,
            description=description,
            parameter=parameter,
            location=location
        )

        return NormalizedFinding(
            type=finding_type,
            severity=severity,
            description=description,
            evidence=evidence,
            confidence=confidence,
            fingerprint=fingerprint,
            parameter=parameter,
            location=location,
            original_finding=finding
        )

    def _normalize_type(
        self,
        finding_type
    ) -> str:

        if hasattr(
            finding_type,
            "value"
        ):
            finding_type = finding_type.value

        return str(
            finding_type
        ).upper().strip()

    def _normalize_severity(
        self,
        severity
    ) -> str:

        if hasattr(
            severity,
            "value"
        ):
            severity = severity.value

        normalized = str(
            severity
        ).upper().strip()

        if "." in normalized:
            normalized = normalized.rsplit(
                ".",
                1
            )[-1]

        return normalized

    def _build_fingerprint(
        self,
        finding_type: str,
        description: str,
        parameter: Optional[str],
        location: Optional[str]
    ) -> str:

        parameter_value = (
            parameter or "none"
        )

        location_value = (
            location or "unknown"
        )

        normalized_description = (
            description
            .lower()
            .strip()
        )

        return (
            f"{finding_type.lower()}"
            f"|{location_value}"
            f"|{parameter_value.lower()}"
            f"|{normalized_description}"
        )

    def _extract_parameter(
        self,
        description: str,
        evidence: str
    ) -> Optional[str]:

        combined_text = (
            f"{description} {evidence}"
        )

        marker = "parameter '"

        if marker in combined_text:

            start = (
                combined_text.find(marker)
                + len(marker)
            )

            end = combined_text.find(
                "'",
                start
            )

            if end != -1:
                return combined_text[
                    start:end
                ]

        lower_text = combined_text.lower()

        marker = "parameter:"

        if marker in lower_text:

            start = (
                lower_text.find(marker)
                + len(marker)
            )

            remaining = (
                combined_text[start:]
                .strip()
            )

            if "," in remaining:
                remaining = (
                    remaining.split(
                        ",",
                        1
                    )[0]
                )

            if remaining:
                return remaining.strip()

        return None

    def _determine_location(
        self,
        finding_type: str
    ) -> Optional[str]:

        if (
            "BOLA" in finding_type
        ):
            return "path"

        if (
            "SQL_INJECTION"
            in finding_type
        ):
            return "query"

        return None