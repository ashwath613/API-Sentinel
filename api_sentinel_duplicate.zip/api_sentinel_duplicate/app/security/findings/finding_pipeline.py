from typing import List

from app.security.base import SecurityFinding

from app.security.findings.normalizer import (
    FindingNormalizer,
)

from app.security.findings.deduplicator import (
    FindingDeduplicator,
)

from app.security.findings.analyzer import (
    FindingAnalyzer,
    AnalyzedFinding,
)


class FindingPipeline:

    def __init__(self):

        self.normalizer = FindingNormalizer()

        self.deduplicator = FindingDeduplicator()

        self.analyzer = FindingAnalyzer()

    def process(
        self,
        findings: List[SecurityFinding]
    ) -> List[AnalyzedFinding]:

        if not findings:
            return []

        normalized_findings = []

        for finding in findings:

            normalized = self.normalizer.normalize(
                finding
            )

            normalized.original_finding = finding

            normalized_findings.append(
                normalized
            )

        unique_normalized = (
            self.deduplicator.deduplicate(
                normalized_findings
            )
        )

        unique_findings = [
            normalized.original_finding
            for normalized in unique_normalized
        ]

        analyzed_findings = self.analyzer.analyze(
            unique_findings
        )

        print()
        print(
            f"[FINDING PIPELINE] "
            f"Raw findings: "
            f"{len(findings)}"
        )

        print(
            f"[FINDING PIPELINE] "
            f"Unique findings: "
            f"{len(unique_findings)}"
        )

        print(
            f"[FINDING PIPELINE] "
            f"Analyzed findings: "
            f"{len(analyzed_findings)}"
        )

        return analyzed_findings