from dataclasses import dataclass
from typing import List

from app.security.base import SecurityFinding

from app.security.findings.normalizer import (
    FindingNormalizer,
    NormalizedFinding,
)

from app.security.findings.correlator import (
    FindingCorrelator,
    CorrelatedFinding,
)

from app.security.scoring.risk_score import (
    RiskScoreCalculator,
)


@dataclass
class AnalyzedFinding:
    original: SecurityFinding
    normalized: NormalizedFinding
    correlated: CorrelatedFinding
    risk_score: float


class FindingAnalyzer:

    def __init__(self):

        self.normalizer = FindingNormalizer()

        self.correlator = FindingCorrelator()

        self.score_calculator = RiskScoreCalculator()

    def analyze(
        self,
        findings: List[SecurityFinding]
    ) -> List[AnalyzedFinding]:

        if not findings:
            return []

        normalized_findings = []

        for finding in findings:

            normalized = self.normalizer.normalize(
                finding
            )

            normalized.original_finding = finding

            normalized_findings.append(
                normalized
            )

        correlated_findings = (
            self.correlator.correlate(
                normalized_findings
            )
        )

        analyzed_findings = []

        for correlated in correlated_findings:

            risk_score = (
                self.score_calculator.calculate(
                    severity=correlated.finding.severity,
                    confidence=correlated.finding.confidence,
                )
            )

            analyzed_findings.append(
                AnalyzedFinding(
                    original=correlated.finding.original_finding,
                    normalized=correlated.finding,
                    correlated=correlated,
                    risk_score=risk_score,
                )
            )

        return analyzed_findings