import requests

from app.db.models import Severity
from app.security.base import SecurityFinding, SecurityTester
from app.security.request_builder import RequestBuilder


class XSSTester(SecurityTester):

    TEST_PAYLOADS = [
        "<script>alert(1)</script>",
        '"><script>alert(1)</script>',
        "<img src=x onerror=alert(1)>",
    ]

    REFLECTION_MARKERS = [
        "<script>alert(1)</script>",
        '"><script>alert(1)</script>',
        "<img src=x onerror=alert(1)>",
    ]

    def __init__(self):
        self.request_builder = RequestBuilder()

    def test(self, endpoint):

        findings = []

        metadata = endpoint.request_metadata or {}

        parameters = metadata.get(
            "parameters",
            []
        )

        query_parameters = [
            parameter
            for parameter in parameters
            if parameter.get("in") == "query"
        ]

        if not query_parameters:

            print(
                f"[XSS TEST] Skipping "
                f"{endpoint.method} {endpoint.path} "
                f"- no query parameters."
            )

            return findings

        for parameter in query_parameters:

            parameter_name = parameter.get(
                "name"
            )

            if not parameter_name:
                continue

            print(
                f"[XSS TEST] Parameter: "
                f"{parameter_name}"
            )

            finding = self._test_parameter(
                endpoint,
                parameter_name
            )

            if finding:
                findings.append(
                    finding
                )

        return self._deduplicate(
            findings
        )



    def _test_parameter(
        self,
        endpoint,
        parameter_name
    ):

        for payload in self.TEST_PAYLOADS:

            request = self.request_builder.build(
                endpoint
            )

            params = dict(
                request["params"]
            )

            params[parameter_name] = payload

            print(
                f"[XSS TEST] "
                f"{parameter_name}={payload}"
            )

            try:

                response = requests.request(
                    method=endpoint.method.upper(),
                    url=request["url"],
                    params=params,
                    timeout=10
                )

            except requests.RequestException as error:

                print(
                    f"[XSS TEST ERROR] "
                    f"{error}"
                )

                continue

            print(
                f"[XSS TEST] "
                f"Status: {response.status_code}"
            )

            if response.status_code < 200:
                continue

            if response.status_code >= 500:
                continue

            body = response.text

            
            if payload in body:

                print(
                    "[XSS TEST] "
                    "Payload reflected in response."
                )

                return SecurityFinding(
                    type="POSSIBLE_REFLECTED_XSS",
                    severity=Severity.MEDIUM,
                    description=(
                        f"User-controlled parameter "
                        f"'{parameter_name}' was reflected "
                        "in the HTTP response without "
                        "being safely transformed."
                    ),
                    evidence=(
                        f"Parameter: {parameter_name}. "
                        f"Payload: {payload}. "
                        f"HTTP status: "
                        f"{response.status_code}. "
                        "The exact payload was found "
                        "in the response body."
                    ),
                    confidence=0.70
                )

        return None

    

    @staticmethod
    def _deduplicate(
        findings
    ):

        unique = []

        seen = set()

        for finding in findings:

            fingerprint = (
                finding.type,
                finding.evidence,
            )

            if fingerprint in seen:
                continue

            seen.add(
                fingerprint
            )

            unique.append(
                finding
            )

        return unique