from dataclasses import dataclass
from typing import List


@dataclass
class EndpointProfile:
    has_path_parameter: bool
    has_query_parameter: bool
    is_write_operation: bool
    is_sensitive_operation: bool
    potential_object_endpoint: bool
    potential_search_endpoint: bool


SENSITIVE_KEYWORDS = {
    "payment",
    "payments",
    "password",
    "credential",
    "credentials",
    "admin",
    "transfer",
    "transaction",
    "billing",
    "account",
}


SEARCH_KEYWORDS = {
    "search",
    "query",
    "filter",
}


def classify_endpoint(endpoint) -> EndpointProfile:

    path = (endpoint.path or "").lower()
    method = (endpoint.method or "").upper()

    metadata = endpoint.request_metadata or {}

    parameters = metadata.get("parameters", [])

    has_path_parameter = any(
        parameter.get("in") == "path"
        for parameter in parameters
    )

    has_query_parameter = any(
        parameter.get("in") == "query"
        for parameter in parameters
    )

    is_write_operation = method in {
        "POST",
        "PUT",
        "PATCH",
        "DELETE",
    }

    is_sensitive_operation = any(
        keyword in path
        for keyword in SENSITIVE_KEYWORDS
    )

    potential_object_endpoint = (
        has_path_parameter
        and any(
            value in path
            for value in [
                "user",
                "account",
                "order",
                "product",
                "payment",
                "transaction",
            ]
        )
    )

    potential_search_endpoint = (
        any(
            keyword in path
            for keyword in SEARCH_KEYWORDS
        )
        or has_query_parameter
    )

    return EndpointProfile(
        has_path_parameter=has_path_parameter,
        has_query_parameter=has_query_parameter,
        is_write_operation=is_write_operation,
        is_sensitive_operation=is_sensitive_operation,
        potential_object_endpoint=potential_object_endpoint,
        potential_search_endpoint=potential_search_endpoint,
    )