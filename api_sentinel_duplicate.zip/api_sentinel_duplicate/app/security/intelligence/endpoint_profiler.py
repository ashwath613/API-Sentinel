from dataclasses import dataclass
from typing import Any, Dict, List


@dataclass
class EndpointProfile:

    has_path_parameter: bool
    has_query_parameter: bool

    is_write_operation: bool
    is_sensitive_operation: bool

    potential_object_endpoint: bool
    potential_search_endpoint: bool
    potential_rate_limit_endpoint: bool
    potential_sensitive_data_endpoint: bool
    has_security_requirement: bool

    path_parameters: List[Dict[str, Any]]
    query_parameters: List[Dict[str, Any]]

    parameter_names: List[str]
    sensitive_parameter_names: List[str]


class EndpointProfiler:


    WRITE_METHODS = {
        "POST",
        "PUT",
        "PATCH",
        "DELETE",
    }

   
    OBJECT_PARAMETER_NAMES = {
        "id",
        "user_id",
        "account_id",
        "order_id",
        "product_id",
        "customer_id",
        "item_id",
        "resource_id",
    }

    

    SENSITIVE_PARAMETER_NAMES = {
        "password",
        "passwd",
        "token",
        "access_token",
        "refresh_token",
        "api_key",
        "apikey",
        "secret",
        "authorization",
        "email",
        "phone",
        "ssn",
    }


    SEARCH_PARAMETER_NAMES = {
        "q",
        "query",
        "search",
        "keyword",
        "term",
        "name",
        "filter",
    }


    SEARCH_PATH_WORDS = {
        "search",
        "query",
        "find",
        "lookup",
    }


    SENSITIVE_PATH_WORDS = {
        "account",
        "admin",
        "user",
        "payment",
        "payments",
        "billing",
        "credential",
        "credentials",
        "secret",
        "sensitive",
        "profile",
        "personal",
        "pii",
        "details",
        "private",
        "customer",
    }

    

    RATE_LIMIT_PARAMETER_NAMES = {
        "otp",
        "token",
        "code",
        "verification_code",
        "email",
        "phone",
    }

   
    def profile(
        self,
        endpoint
    ) -> EndpointProfile:

        metadata = (
            endpoint.request_metadata
            or {}
        )

        parameters = metadata.get(
            "parameters",
            []
        )


        path_parameters = [
            parameter
            for parameter in parameters
            if parameter.get("in") == "path"
        ]

       

        query_parameters = [
            parameter
            for parameter in parameters
            if parameter.get("in") == "query"
        ]
        parameter_names = [
            parameter.get(
                "name",
                ""
            ).lower()
            for parameter in parameters
            if parameter.get("name")
        ]

        

        path = (
            getattr(
                endpoint,
                "path",
                None
            )
            or ""
        ).lower()

       
        method = (
            getattr(
                endpoint,
                "method",
                None
            )
            or "GET"
        ).upper()

       
        security = metadata.get(
            "security"
        )

        has_security_requirement = bool(
            security
        )


        has_path_parameter = bool(
            path_parameters
        )

        has_query_parameter = bool(
            query_parameters
        )

        is_write_operation = (
            method in self.WRITE_METHODS
        )

        

        potential_object_endpoint = (
            self._is_object_endpoint(
                path_parameters
            )
        )


        potential_search_endpoint = (
            self._is_search_endpoint(
                path,
                query_parameters
            )
        )

        
        is_sensitive_operation = (
            self._is_sensitive_operation(
                path,
                parameter_names
            )
        )

      

        potential_rate_limit_endpoint = (
            self._is_rate_limit_endpoint(
                path=path,
                method=method,
                parameter_names=parameter_names,
                is_sensitive_operation=(
                    is_sensitive_operation
                )
            )
        )


        potential_sensitive_data_endpoint = (
            self._is_sensitive_data_endpoint(
                path
            )
        )

        

        sensitive_parameter_names = [
            name
            for name in parameter_names
            if name in self.SENSITIVE_PARAMETER_NAMES
        ]

        

        return EndpointProfile(
            has_path_parameter=(
                has_path_parameter
            ),
            has_query_parameter=(
                has_query_parameter
            ),
            is_write_operation=(
                is_write_operation
            ),
            is_sensitive_operation=(
                is_sensitive_operation
            ),
            potential_object_endpoint=(
                potential_object_endpoint
            ),
            potential_search_endpoint=(
                potential_search_endpoint
            ),
            potential_rate_limit_endpoint=(
                potential_rate_limit_endpoint
            ),
            potential_sensitive_data_endpoint=(
                potential_sensitive_data_endpoint
            ),
            has_security_requirement=(
                has_security_requirement
            ),
            path_parameters=(
                path_parameters
            ),
            query_parameters=(
                query_parameters
            ),
            parameter_names=(
                parameter_names
            ),
            sensitive_parameter_names=(
                sensitive_parameter_names
            ),
        )

 

    def _is_object_endpoint(
        self,
        path_parameters: List[Dict[str, Any]]
    ) -> bool:

        if not path_parameters:
            return False

        for parameter in path_parameters:

            name = (
                parameter.get(
                    "name",
                    ""
                ).lower()
            )

            if name in self.OBJECT_PARAMETER_NAMES:
                return True

            if (
                name.endswith("_id")
                or name.endswith("id")
            ):
                return True

        return True

   

    def _is_search_endpoint(
        self,
        path: str,
        query_parameters: List[Dict[str, Any]]
    ) -> bool:

        for parameter in query_parameters:

            name = (
                parameter.get(
                    "name",
                    ""
                ).lower()
            )

            if name in self.SEARCH_PARAMETER_NAMES:
                return True

        path_parts = [
            part
            for part in path.split("/")
            if part
        ]

        return any(
            word in path_parts
            for word in self.SEARCH_PATH_WORDS
        )


    def _is_sensitive_operation(
        self,
        path: str,
        parameter_names: List[str]
    ) -> bool:

        for name in parameter_names:

            if name in self.SENSITIVE_PARAMETER_NAMES:
                return True

        path_parts = [
            part
            for part in path.split("/")
            if part
        ]

        for part in path_parts:

            if part in self.SENSITIVE_PATH_WORDS:
                return True

        return False

    

    def _is_rate_limit_endpoint(
        self,
        path: str,
        method: str,
        parameter_names: List[str],
        is_sensitive_operation: bool
    ) -> bool:

        normalized_path = (
            path
            .lower()
            .replace(
                "_",
                "-"
            )
        )

        rate_limit_keywords = {
            "rate-limit",
            "ratelimit",
            "throttle",
            "throttling",
        }

        for keyword in rate_limit_keywords:

            if keyword in normalized_path:
                return True

        sensitive_action_keywords = {
            "login",
            "signin",
            "sign-in",
            "signup",
            "sign-up",
            "register",
            "otp",
            "verify",
            "verification",
            "password-reset",
            "reset-password",
            "forgot-password",
            "export",
            "download",
            "upload",
            "send",
        }

        for keyword in sensitive_action_keywords:

            if keyword in normalized_path:
                return True

        if method in self.WRITE_METHODS:
            return True

        for name in parameter_names:

            if name in self.RATE_LIMIT_PARAMETER_NAMES:
                return True

        if is_sensitive_operation:
            return True

        return False

    def _is_sensitive_data_endpoint(
        self,
        path: str
    ) -> bool:

        normalized_path = (
            path
            .lower()
            .replace(
                "_",
                "-"
            )
        )

        sensitive_data_keywords = {
            "sensitive-data",
            "sensitive",
            "secret",
            "profile",
            "personal",
            "pii",
            "credential",
            "credentials",
            "details",
            "payment",
            "payments",
            "billing",
            "account",
            "customer",
            "private",
        }

        path_parts = [
            part
            for part in normalized_path.split("/")
            if part
        ]

        return any(
            part in sensitive_data_keywords
            for part in path_parts
        )