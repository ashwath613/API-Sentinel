from dataclasses import dataclass
from typing import Any, Dict, List


@dataclass
class ParameterProfile:
    name: str
    location: str
    data_type: str
    required: bool

    is_numeric: bool
    is_boolean: bool
    is_string: bool

    is_object_identifier: bool
    is_search_parameter: bool
    is_sensitive_parameter: bool

    injection_candidate: bool


class ParameterAnalyzer:

    OBJECT_PARAMETER_NAMES = {
        "id",
        "user_id",
        "account_id",
        "order_id",
        "product_id",
        "customer_id",
        "item_id",
        "resource_id"
    }

    SEARCH_PARAMETER_NAMES = {
        "q",
        "query",
        "search",
        "keyword",
        "term",
        "filter"
    }

    SENSITIVE_PARAMETER_NAMES = {
        "password",
        "passwd",
        "token",
        "access_token",
        "refresh_token",
        "api_key",
        "apikey",
        "secret",
        "authorization",
        "email",
        "phone",
        "ssn"
    }

    INJECTION_PARAMETER_NAMES = {
    "q",
    "query",
    "search",
    "keyword",
    "term",
    "filter",
    "name",
    "username"
}

    def analyze(self, endpoint) -> List[ParameterProfile]:

        metadata = endpoint.request_metadata or {}

        parameters = metadata.get(
            "parameters",
            []
        )

        profiles = []

        for parameter in parameters:

            name = parameter.get("name")

            if not name:
                continue

            location = parameter.get(
                "in",
                "unknown"
            )

            required = parameter.get(
                "required",
                False
            )

            schema = parameter.get(
                "schema",
                {}
            )

            data_type = schema.get(
                "type",
                "unknown"
            )

            normalized_name = name.lower()

            is_numeric = data_type in {
                "integer",
                "number"
            }

            is_boolean = data_type == "boolean"

            is_string = data_type == "string"

            is_object_identifier = (
                location == "path"
                and self._is_object_identifier(
                    normalized_name
                )
            )

            is_search_parameter = (
                location == "query"
                and normalized_name
                in self.SEARCH_PARAMETER_NAMES
            )

            is_sensitive_parameter = (
                normalized_name
                in self.SENSITIVE_PARAMETER_NAMES
            )

            injection_candidate = (
                self._is_injection_candidate(
                    normalized_name,
                    location,
                    data_type
                )
            )

            profiles.append(
                ParameterProfile(
                    name=name,
                    location=location,
                    data_type=data_type,
                    required=required,
                    is_numeric=is_numeric,
                    is_boolean=is_boolean,
                    is_string=is_string,
                    is_object_identifier=is_object_identifier,
                    is_search_parameter=is_search_parameter,
                    is_sensitive_parameter=is_sensitive_parameter,
                    injection_candidate=injection_candidate
                )
            )

        return profiles

    def _is_object_identifier(
        self,
        name: str
    ) -> bool:

        if name in self.OBJECT_PARAMETER_NAMES:
            return True

        if name.endswith("_id"):
            return True

        if name.endswith("id"):
            return True

        return False

    def _is_injection_candidate(
        self,
        name: str,
        location: str,
        data_type: str
    ) -> bool:

        if location not in {
            "query",
            "path"
        }:
            return False

        if name in self.INJECTION_PARAMETER_NAMES:
            return True


        return False