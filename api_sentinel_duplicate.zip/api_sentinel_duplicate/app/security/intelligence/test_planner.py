from dataclasses import dataclass
from typing import List

from app.security.planning.risk_mapper import SecurityRisk


@dataclass
class PlannedTest:
    tester: str
    reason: str
    priority: str


RISK_TO_TESTER = {
    "BOLA": "BOLATester",
    "SQL_INJECTION": "SQLInjectionTester",
    "RATE_LIMITING": "RateLimitTester",
    "CORS": "CORSTester",
    "BROKEN_AUTHORIZATION": "AuthorizationTester",
    "AUTHENTICATION": "AuthenticationTester",
}


def create_test_plan(
    risks: List[SecurityRisk]
) -> List[PlannedTest]:

    plan = []

    for risk in risks:

        tester_name = RISK_TO_TESTER.get(risk.name)

        if not tester_name:
            continue

        plan.append(
            PlannedTest(
                tester=tester_name,
                reason=risk.reason,
                priority=risk.relevance
            )
        )

    return plan