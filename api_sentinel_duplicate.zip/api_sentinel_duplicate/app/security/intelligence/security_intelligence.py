from dataclasses import dataclass
from typing import List

from app.security.intelligence.endpoint_profiler import (
    EndpointProfiler,
    EndpointProfile,
)

from app.security.intelligence.parameter_analyzer import (
    ParameterAnalyzer,
    ParameterProfile,
)


@dataclass
class EndpointIntelligence:
    endpoint_profile: EndpointProfile
    parameter_profiles: List[ParameterProfile]


class SecurityIntelligence:

    def __init__(self):
        self.endpoint_profiler = EndpointProfiler()
        self.parameter_analyzer = ParameterAnalyzer()

    def analyze(self, endpoint) -> EndpointIntelligence:

        endpoint_profile = self.endpoint_profiler.profile(
            endpoint
        )

        parameter_profiles = self.parameter_analyzer.analyze(
            endpoint
        )

        return EndpointIntelligence(
            endpoint_profile=endpoint_profile,
            parameter_profiles=parameter_profiles
        )