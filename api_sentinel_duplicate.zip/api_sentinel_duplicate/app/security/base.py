from abc import ABC, abstractmethod
from dataclasses import dataclass

from app.db.models import Severity


@dataclass
class SecurityFinding:
    type: str
    severity: Severity
    description: str
    evidence: str
    confidence: float


class SecurityTester(ABC):

    @abstractmethod
    def test(self, endpoint):
        pass