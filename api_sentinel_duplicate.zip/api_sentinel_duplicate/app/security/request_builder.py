from typing import Any, Dict, Optional

from app.db.models import Endpoint
from app.security.requests.parameter_generator import (
    ParameterGenerator,
)


class RequestBuilder:

    def build_url(
        self,
        endpoint: Endpoint,
        path_values: Optional[Dict[str, Any]] = None
    ) -> str:

        url = endpoint.url

        path_values = path_values or {}

        metadata = (
            endpoint.request_metadata
            or {}
        )

        parameters = metadata.get(
            "parameters",
            []
        )

        components = metadata.get(
            "components",
            {}
        )

        schemas = components.get(
            "schemas",
            {}
        )

        for parameter in parameters:

            if parameter.get("in") != "path":
                continue

            name = parameter.get(
                "name"
            )

            if not name:
                continue

            value = path_values.get(
                name,
                self._generate_parameter_value(
                    parameter,
                    schemas
                )
            )

            placeholder = (
                "{"
                + name
                + "}"
            )

            url = url.replace(
                placeholder,
                str(value)
            )

        return url



    def build_query_params(
        self,
        endpoint: Endpoint,
        query_values: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:

        query_values = (
            query_values
            or {}
        )

        metadata = (
            endpoint.request_metadata
            or {}
        )

        parameters = metadata.get(
            "parameters",
            []
        )

        components = metadata.get(
            "components",
            {}
        )

        schemas = components.get(
            "schemas",
            {}
        )

        params = {}

        for parameter in parameters:

            if parameter.get("in") != "query":
                continue

            name = parameter.get(
                "name"
            )

            if not name:
                continue

            params[name] = query_values.get(
                name,
                self._generate_parameter_value(
                    parameter,
                    schemas
                )
            )

        return params

   

    def build_json_body(
        self,
        endpoint: Endpoint
    ) -> Optional[Dict[str, Any]]:

        metadata = (
            endpoint.request_metadata
            or {}
        )

        request_body = metadata.get(
            "request_body"
        )

        if not request_body:
            return None

        components = metadata.get(
            "components",
            {}
        )

        schemas = components.get(
            "schemas",
            {}
        )

        content = request_body.get(
            "content",
            {}
        )

        if not content:
            return None

        json_content = content.get(
            "application/json"
        )

        if not json_content:

            json_content = next(
                iter(
                    content.values()
                ),
                None
            )

        if not json_content:
            return None

        schema = json_content.get(
            "schema",
            {}
        )

        return self._generate_schema_value(
            schema,
            schemas
        )

    

    def build(
        self,
        endpoint: Endpoint,
        path_values: Optional[Dict[str, Any]] = None,
        query_values: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:

        return {
            "method": endpoint.method.upper(),

            "url": self.build_url(
                endpoint,
                path_values
            ),

            "params": self.build_query_params(
                endpoint,
                query_values
            ),

            "json": self.build_json_body(
                endpoint
            ),

            "headers": {
                "Content-Type": "application/json"
            }
        }

    

    @staticmethod
    def _generate_parameter_value(
        parameter: Dict[str, Any],
        schemas: Dict[str, Any]
    ) -> Any:

        schema = parameter.get(
            "schema",
            {}
        )

        schema = (
            RequestBuilder._resolve_schema(
                schema,
                schemas
            )
        )

        parameter_copy = dict(
            parameter
        )

        parameter_copy["schema"] = schema

        return ParameterGenerator.generate(
            parameter_copy
        )

    

    @staticmethod
    def _generate_schema_value(
        schema: Dict[str, Any],
        schemas: Dict[str, Any]
    ) -> Any:

        schema = (
            RequestBuilder._resolve_schema(
                schema,
                schemas
            )
        )

        if not schema:
            return {}

        

        if "example" in schema:
            return schema["example"]

        

        if "default" in schema:
            return schema["default"]

       

        enum_values = schema.get(
            "enum"
        )

        if enum_values:
            return enum_values[0]

        schema_type = schema.get(
            "type"
        )

        

        if schema_type == "object":

            properties = schema.get(
                "properties",
                {}
            )

            body = {}

            for name, property_schema in properties.items():

                body[name] = (
                    RequestBuilder._generate_schema_value(
                        property_schema,
                        schemas
                    )
                )

            return body

        

        if schema_type == "array":

            item_schema = schema.get(
                "items",
                {}
            )

            item = (
                RequestBuilder._generate_schema_value(
                    item_schema,
                    schemas
                )
            )

            return [
                item
            ]

        

        return ParameterGenerator.generate_from_schema(
    schema
    )

    

    @staticmethod
    def _resolve_schema(
        schema: Dict[str, Any],
        schemas: Dict[str, Any]
    ) -> Dict[str, Any]:

        if not isinstance(
            schema,
            dict
        ):
            return {}

        reference = schema.get(
            "$ref"
        )

        if not reference:
            return schema

        prefix = (
            "#/components/schemas/"
        )

        if not reference.startswith(
            prefix
        ):
            return {}

        schema_name = (
            reference[len(prefix):]
        )

        return schemas.get(
            schema_name,
            {}
        )