import json
from datetime import datetime, timezone

from app.db.models import Endpoint


HTTP_METHODS = {
    "get",
    "post",
    "put",
    "patch",
    "delete",
    "options",
    "head",
    "trace",
}


def load_openapi_file(file_path):

    with open(
        file_path,
        "r",
        encoding="utf-8",
    ) as file:

        return json.load(file)


def discover_from_openapi(
    db,
    scan_id,
    file_path,
    base_url=None,
):

    specification = load_openapi_file(
        file_path
    )

    

    if not base_url:

        servers = specification.get(
            "servers",
            []
        )

        if servers:

            base_url = (
                servers[0]
                .get("url", "")
                .rstrip("/")
            )

    if not base_url:
        base_url = ""

    

    root_security = specification.get(
        "security"
    )

    endpoints = []

    paths = specification.get(
        "paths",
        {}
    )

    

    for path, path_data in paths.items():

        if not isinstance(
            path_data,
            dict
        ):
            continue

        common_parameters = (
            path_data.get(
                "parameters",
                []
            )
        )

        

        for method, operation in path_data.items():

            if (
                method.lower()
                not in HTTP_METHODS
            ):
                continue

            if not isinstance(
                operation,
                dict
            ):
                continue

            

            parameters = list(
                common_parameters
            )

            parameters.extend(
                operation.get(
                    "parameters",
                    []
                )
            )

            

            request_body = (
                operation.get(
                    "requestBody"
                )
            )

            

            if "security" in operation:

                # Explicit operation-level security.
                #
                # [] means the operation is explicitly public
                # and overrides any root-level security.

                security = operation.get(
                    "security"
                )

            else:

                

                security = root_security

            

            request_metadata = {
                "parameters": parameters,
                "request_body": request_body,
                "security": security,
                "components": specification.get(
                    "components",
                    {}
                ),
            }

            

            full_url = (
    f"{base_url.rstrip('/')}/"
    f"{path.lstrip('/')}"
)

            

            endpoint = Endpoint(
                scan_id=scan_id,
                path=path,
                method=method.upper(),
                url=full_url,
                discovered_at=datetime.now(
                    timezone.utc
                ),
                request_metadata=request_metadata,
            )

            db.add(
                endpoint
            )

            endpoints.append(
                endpoint
            )

    db.commit()

    for endpoint in endpoints:

        db.refresh(
            endpoint
        )

    return endpoints