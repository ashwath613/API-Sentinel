from sqlalchemy import select
from sqlalchemy.orm import Session

from app.db.models import Endpoint


def get_scan_endpoints(db: Session, scan_id: int):
    statement = select(Endpoint).where(Endpoint.scan_id == scan_id)
    result = db.execute(statement)

    return result.scalars().all()