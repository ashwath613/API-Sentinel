from sqlalchemy.orm import Session
from datetime import datetime,timezone
from app.db.models import Endpoint

def discover_from_url(db:Session,scan_id:int,target:str):
    endpoint = Endpoint(
        scan_id=scan_id,
        path="/",
        method="GEt",
        url=target,
        discovered_at = datetime.now(timezone.utc)

    )
    db.add(endpoint)
    db.commit()
    db.refresh(endpoint)
    return endpoint