from app.db.models import Severity


SEVERITY_SCORE = {
    Severity.CRITICAL: 10.0,
    Severity.HIGH: 8.0,
    Severity.MEDIUM: 5.0,
    Severity.LOW: 2.0
}


def calculate_priority_score(
    severity: Severity,
    confidence: float
):
    severity_score = SEVERITY_SCORE.get(
        severity,
        0.0
    )

    confidence = max(
        0.0,
        min(confidence, 1.0)
    )

    return round(
        severity_score * confidence,
        2
    )