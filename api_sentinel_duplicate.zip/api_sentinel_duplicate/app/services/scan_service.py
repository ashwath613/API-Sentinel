from datetime import datetime, timezone
from urllib.parse import urlsplit

import requests
from sqlalchemy import select
from sqlalchemy.orm import Session, selectinload

from app.db.models import (
    Scan,
    Status,
    Endpoint,
)

from app.db.session import SessionLocal

from app.security.scan_engine import SecurityScanEngine

from app.services.finding_persistence import (
    save_analyzed_finding,
)



def get_scan(
    db: Session,
    scan_id: int
):

    statement = (
        select(Scan)
        .options(
            selectinload(Scan.endpoints)
            .selectinload(Endpoint.vulnerabilities)
        )
        .where(
            Scan.id == scan_id
        )
    )

    return db.execute(
        statement
    ).scalar_one_or_none()



def get_all_scans(
    db: Session,
    skip: int = 0,
    limit: int = 10
):

    statement = (
        select(Scan)
        .order_by(
            Scan.id.desc()
        )
        .offset(skip)
        .limit(limit)
    )

    return db.execute(
        statement
    ).scalars().all()



def get_scan_summary(
    db: Session,
    scan_id: int
):

    statement = (
        select(Scan)
        .options(
            selectinload(Scan.endpoints)
            .selectinload(Endpoint.vulnerabilities)
        )
        .where(
            Scan.id == scan_id
        )
    )

    scan = (
        db.execute(
            statement
        )
        .scalar_one_or_none()
    )

    if scan is None:
        return None

    endpoints = scan.endpoints

    vulnerabilities = [
        vulnerability
        for endpoint in endpoints
        for vulnerability in endpoint.vulnerabilities
    ]

    severity_counts = {
        "CRITICAL": 0,
        "HIGH": 0,
        "MEDIUM": 0,
        "LOW": 0,
    }

    for vulnerability in vulnerabilities:

        severity = (
            vulnerability.severity.value
        )

        if severity in severity_counts:
            severity_counts[severity] += 1

    highest_score = max(
        (
            vulnerability.priority_score
            for vulnerability in vulnerabilities
        ),
        default=0.0
    )

    return {
        "scan_id": scan.id,
        "target": scan.target,
        "status": scan.status,
        "input_type": scan.input_type,
        "started_at": scan.started_at,
        "completed_at": scan.completed_at,
        "total_endpoints": len(endpoints),
        "total_vulnerabilities": len(vulnerabilities),
        "critical_count": severity_counts["CRITICAL"],
        "high_count": severity_counts["HIGH"],
        "medium_count": severity_counts["MEDIUM"],
        "low_count": severity_counts["LOW"],
        "highest_risk_score": highest_score,
    }


 
 

def get_base_url(
    endpoint_url: str
) -> str:

    parsed = urlsplit(
        endpoint_url
    )

    if not parsed.scheme or not parsed.netloc:

        raise ValueError(
            f"Invalid endpoint URL: {endpoint_url}"
        )

    return (
        f"{parsed.scheme}://"
        f"{parsed.netloc}"
    )





def reset_target_state(
    endpoints
):

    if not endpoints:

        print(
            "[SCAN SERVICE] "
            "No endpoints available for target reset."
        )

        return False

    

    endpoint_url = endpoints[0].url

    base_url = get_base_url(
        endpoint_url
    )

    reset_url = (
        base_url
        + "/orders/test/reset"
    )

    print(
        f"[SCAN SERVICE] "
        f"Target reset URL: "
        f"{reset_url}"
    )

    try:

        response = requests.post(
            reset_url,
            timeout=10,
        )

        

        if response.status_code == 200:

            print(
                "[SCAN SERVICE] "
                "Target state reset successfully."
            )

            print(
                f"[SCAN SERVICE] "
                f"Reset response: "
                f"{response.text}"
            )

            return True

        

        if response.status_code == 404:

            print(
                "[SCAN SERVICE] "
                "Target reset endpoint not available. "
                "Continuing scan without reset."
            )

            return False

    

        print(
            "[SCAN SERVICE] "
            f"Target reset returned HTTP "
            f"{response.status_code}. "
            "Continuing scan without reset."
        )

        if response.text:

            print(
                f"[SCAN SERVICE] "
                f"Reset response: "
                f"{response.text}"
            )

        return False

    except requests.RequestException as error:

        print(
            "[SCAN SERVICE] "
            f"Target reset unavailable: "
            f"{error}"
        )

        print(
            "[SCAN SERVICE] "
            "Continuing scan without target reset."
        )

        return False

    except ValueError as error:

        print(
            "[SCAN SERVICE] "
            f"Could not determine target base URL: "
            f"{error}"
        )

        print(
            "[SCAN SERVICE] "
            "Continuing scan without target reset."
        )

        return False




def run_scan(
    scan_id: int
):

    db: Session = SessionLocal()

    scan = None

    try:

        

        statement = (
            select(Scan)
            .where(
                Scan.id == scan_id
            )
        )

        scan = (
            db.execute(
                statement
            )
            .scalar_one_or_none()
        )

        if scan is None:

            print(
                f"[SCAN SERVICE] "
                f"Scan {scan_id} not found."
            )

            return

        

        if scan.status == Status.COMPLETED:

            print(
                f"[SCAN SERVICE] "
                f"Scan {scan.id} is already completed."
            )

            return

        if scan.status == Status.RUNNING:

            print(
                f"[SCAN SERVICE] "
                f"Scan {scan.id} is already running."
            )

            return

        

        scan.status = Status.RUNNING

        scan.started_at = (
            datetime.now(timezone.utc)
        )

        scan.completed_at = None

        db.commit()

        print()
        print("=" * 70)

        print(
            f"[SCAN SERVICE] "
            f"Scan {scan.id} started."
        )

        print(
            f"[SCAN SERVICE] "
            f"Target: {scan.target}"
        )

        print(
            f"[SCAN SERVICE] "
            f"Input type: {scan.input_type}"
        )

        print("=" * 70)

        

        endpoint_statement = (
            select(Endpoint)
            .where(
                Endpoint.scan_id == scan.id
            )
            .order_by(
                Endpoint.id
            )
        )

        endpoints = (
            db.execute(
                endpoint_statement
            )
            .scalars()
            .all()
        )

        total_endpoints = len(
            endpoints
        )

        print(
            f"[SCAN SERVICE] "
            f"Endpoints discovered: "
            f"{total_endpoints}"
        )

        

        if endpoints:

            reset_target_state(
                endpoints
            )

        else:

            print(
                "[SCAN SERVICE] "
                "No endpoints discovered. "
                "Skipping target reset."
            )

        

        engine = SecurityScanEngine()

        total_findings = 0

        successful_endpoints = 0

        failed_endpoints = 0

        for index, endpoint in enumerate(
            endpoints,
            start=1
        ):

            print()
            print("=" * 70)

            print(
                f"[SCAN SERVICE] "
                f"Endpoint "
                f"{index}/{total_endpoints}"
            )

            print(
                f"[SCAN SERVICE] "
                f"{endpoint.method} "
                f"{endpoint.path}"
            )

            try:

               

                analyzed_findings = engine.run(
                    endpoint
                )

                print(
                    f"[SCAN SERVICE] "
                    f"Analyzed findings returned: "
                    f"{len(analyzed_findings)}"
                )

             

                for analyzed_finding in analyzed_findings:

                    vulnerability = (
                        save_analyzed_finding(
                            db=db,
                            endpoint_id=endpoint.id,
                            analyzed_finding=analyzed_finding,
                        )
                    )

                    print(
                        f"[SCAN SERVICE] "
                        f"Saved vulnerability: "
                        f"{vulnerability.id} "
                        f"| type="
                        f"{vulnerability.type} "
                        f"| score="
                        f"{vulnerability.priority_score}"
                    )

                    total_findings += 1

                successful_endpoints += 1

            except Exception as endpoint_error:

                failed_endpoints += 1

                print(
                    "[SCAN SERVICE] "
                    "Endpoint testing failed."
                )

                print(
                    f"[SCAN SERVICE] "
                    f"Endpoint: "
                    f"{endpoint.method} "
                    f"{endpoint.path}"
                )

                print(
                    f"[SCAN SERVICE] "
                    f"Error: "
                    f"{endpoint_error}"
                )

                # Continue remaining endpoints.
                continue

       

        scan.status = Status.COMPLETED

        scan.completed_at = (
            datetime.now(timezone.utc)
        )

        db.commit()

    

        print()
        print("=" * 70)

        print(
            f"[SCAN SERVICE] "
            f"Scan {scan.id} completed."
        )

        print(
            f"[SCAN SERVICE] "
            f"Total endpoints: "
            f"{total_endpoints}"
        )

        print(
            f"[SCAN SERVICE] "
            f"Successful endpoints: "
            f"{successful_endpoints}"
        )

        print(
            f"[SCAN SERVICE] "
            f"Failed endpoints: "
            f"{failed_endpoints}"
        )

        print(
            f"[SCAN SERVICE] "
            f"Total analyzed findings: "
            f"{total_findings}"
        )

        print(
            f"[SCAN SERVICE] "
            f"Started: "
            f"{scan.started_at}"
        )

        print(
            f"[SCAN SERVICE] "
            f"Completed: "
            f"{scan.completed_at}"
        )

        print("=" * 70)

    except Exception as error:

        print()
        print("=" * 70)

        print(
            f"[SCAN SERVICE] "
            f"SCAN {scan_id} FAILED"
        )

        print(
            f"[SCAN SERVICE] "
            f"Error: {error}"
        )

        print("=" * 70)

        db.rollback()

        statement = (
            select(Scan)
            .where(
                Scan.id == scan_id
            )
        )

        scan = (
            db.execute(
                statement
            )
            .scalar_one_or_none()
        )

        if scan:

            scan.status = Status.FAILED

            scan.completed_at = (
                datetime.now(timezone.utc)
            )

            db.commit()

        raise

    finally:

        db.close()