import requests
from urllib.parse import urlparse

from app.services.openapi_service import discover_from_openapi


def discover_openapi_from_url(
    db,
    scan_id: int,
    openapi_url: str
):
    
    response = requests.get(
        openapi_url,
        timeout=10
    )

    response.raise_for_status()

    content_type = response.headers.get(
    "Content-Type",
    ""
    ).lower()

    if "json" not in content_type:
        raise ValueError(
        "The provided OpenAPI URL did not return JSON. "
        f"Content-Type: {content_type}"
    )

    
    try:
        specification = response.json()
    except ValueError as error:
        raise ValueError(
        "The provided OpenAPI URL did not return valid JSON."
    ) from error

   

    file_path = (
        f"data/scan_{scan_id}_openapi.json"
    )

    with open(
        file_path,
        "w",
        encoding="utf-8"
    ) as file:

        file.write(
            response.text
        )

    

    parsed_url = urlparse(
        openapi_url
    )

    base_url = (
        f"{parsed_url.scheme}://"
        f"{parsed_url.netloc}"
    )

    

    servers = specification.get(
        "servers",
        []
    )

    if servers:

        server_url = servers[0].get(
            "url",
            ""
        ).strip()

        if server_url:

            
            if (
                server_url.startswith("http://")
                or
                server_url.startswith("https://")
            ):

                base_url = (
                    server_url.rstrip("/")
                )

            

            else:

                base_url = (
                    f"{base_url}/"
                    f"{server_url.lstrip('/').rstrip('/')}"
                )


    return discover_from_openapi(
        db=db,
        scan_id=scan_id,
        file_path=file_path,
        base_url=base_url
    )