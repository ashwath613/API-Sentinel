from datetime import datetime, timezone

from sqlalchemy.orm import Session

from app.security.findings.analyzer import AnalyzedFinding
from app.db.models import Vulnerability


def save_analyzed_finding(
    db: Session,
    endpoint_id: int,
    analyzed_finding: AnalyzedFinding,
):
    finding = analyzed_finding.original

    vulnerability = Vulnerability(
        endpoint_id=endpoint_id,
        type=analyzed_finding.normalized.type,
        severity=analyzed_finding.normalized.severity,
        description=analyzed_finding.normalized.description,
        evidence=analyzed_finding.normalized.evidence,
        confidence=analyzed_finding.normalized.confidence,
        priority_score=analyzed_finding.risk_score,
        detected_at=datetime.now(timezone.utc),
    )

    db.add(vulnerability)
    db.flush()

    return vulnerability