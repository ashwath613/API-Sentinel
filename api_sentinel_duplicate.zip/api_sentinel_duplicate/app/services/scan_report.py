from collections import Counter, defaultdict
from datetime import datetime
from typing import Any, Dict, List

from sqlalchemy import select
from sqlalchemy.orm import Session, selectinload

from app.db.models import (
    Scan,
    Endpoint,
    Vulnerability,
)


class ScanReportService:
    """
    Builds a developer-friendly security report from an existing scan.

    Database structure used:

        Scan
          └── Endpoint
                └── Vulnerability
    """

    

    @staticmethod
    def generate_scan_report(
        db: Session,
        scan_id: int,
    ) -> Dict[str, Any]:
        """
        Generate a complete report for one scan.

        Returns None when the scan does not exist.
        """

        scan = ScanReportService._get_scan(
            db=db,
            scan_id=scan_id,
        )

        if scan is None:
            return None

        endpoints = list(
            scan.endpoints
            or []
        )

        vulnerabilities = [
            vulnerability
            for endpoint in endpoints
            for vulnerability in (
                endpoint.vulnerabilities
                or []
            )
        ]

        return {
            "report_version": "1.0",

            "scan": (
                ScanReportService._build_scan_metadata(
                    scan
                )
            ),

            "summary": (
                ScanReportService._build_summary(
                    endpoints=endpoints,
                    vulnerabilities=vulnerabilities,
                )
            ),

            "risk_distribution": (
                ScanReportService._build_risk_distribution(
                    vulnerabilities
                )
            ),

            "endpoint_summary": (
                ScanReportService._build_endpoint_summary(
                    endpoints
                )
            ),

            "findings": (
                ScanReportService._build_findings(
                    vulnerabilities
                )
            ),

            "recommendations": (
                ScanReportService._build_recommendations(
                    vulnerabilities
                )
            ),

            "generated_at": (
                datetime.utcnow().isoformat()
                + "Z"
            ),
        }

    

    @staticmethod
    def _get_scan(
        db: Session,
        scan_id: int,
    ):
        """
        Load the complete scan tree.

        Scan
          -> Endpoints
          -> Vulnerabilities
        """

        statement = (
            select(Scan)
            .options(
                selectinload(
                    Scan.endpoints
                ).selectinload(
                    Endpoint.vulnerabilities
                )
            )
            .where(
                Scan.id == scan_id
            )
        )

        return (
            db.execute(
                statement
            )
            .scalar_one_or_none()
        )

    

    @staticmethod
    def _build_scan_metadata(
        scan: Scan,
    ) -> Dict[str, Any]:

        return {
            "scan_id": scan.id,
            "target": scan.target,
            "input_type": (
                scan.input_type.value
                if scan.input_type
                else None
            ),
            "status": (
                scan.status.value
                if scan.status
                else None
            ),
            "started_at": (
                ScanReportService._datetime_to_string(
                    scan.started_at
                )
            ),
            "completed_at": (
                ScanReportService._datetime_to_string(
                    scan.completed_at
                )
            ),
        }

    

    @staticmethod
    def _build_summary(
        endpoints: List[Endpoint],
        vulnerabilities: List[Vulnerability],
    ) -> Dict[str, Any]:

        severity_counts = {
            "CRITICAL": 0,
            "HIGH": 0,
            "MEDIUM": 0,
            "LOW": 0,
        }

        for vulnerability in vulnerabilities:

            severity = (
                vulnerability.severity.value
                if vulnerability.severity
                else "LOW"
            )

            if severity in severity_counts:
                severity_counts[severity] += 1

        highest_score = max(
            (
                vulnerability.priority_score
                for vulnerability in vulnerabilities
            ),
            default=0.0,
        )

        average_confidence = 0.0

        if vulnerabilities:

            average_confidence = (
                sum(
                    vulnerability.confidence
                    for vulnerability
                    in vulnerabilities
                )
                / len(vulnerabilities)
            )

        return {
            "total_endpoints": len(
                endpoints
            ),
            "total_vulnerabilities": len(
                vulnerabilities
            ),
            "critical_count": (
                severity_counts["CRITICAL"]
            ),
            "high_count": (
                severity_counts["HIGH"]
            ),
            "medium_count": (
                severity_counts["MEDIUM"]
            ),
            "low_count": (
                severity_counts["LOW"]
            ),
            "highest_priority_score": (
                highest_score
            ),
            "average_confidence": round(
                average_confidence,
                2,
            ),
        }

    

    @staticmethod
    def _build_risk_distribution(
        vulnerabilities: List[Vulnerability],
    ) -> Dict[str, int]:

        distribution = {
            "CRITICAL": 0,
            "HIGH": 0,
            "MEDIUM": 0,
            "LOW": 0,
        }

        for vulnerability in vulnerabilities:

            severity = (
                vulnerability.severity.value
                if vulnerability.severity
                else "LOW"
            )

            if severity in distribution:
                distribution[severity] += 1

        return distribution

    

    @staticmethod
    def _build_endpoint_summary(
        endpoints: List[Endpoint],
    ) -> List[Dict[str, Any]]:

        endpoint_reports = []

        for endpoint in endpoints:

            vulnerabilities = list(
                endpoint.vulnerabilities
                or []
            )

            severity_counts = {
                "CRITICAL": 0,
                "HIGH": 0,
                "MEDIUM": 0,
                "LOW": 0,
            }

            highest_score = 0.0

            for vulnerability in vulnerabilities:

                severity = (
                    vulnerability.severity.value
                    if vulnerability.severity
                    else "LOW"
                )

                if severity in severity_counts:
                    severity_counts[severity] += 1

                highest_score = max(
                    highest_score,
                    vulnerability.priority_score,
                )

            endpoint_reports.append(
                {
                    "endpoint_id": endpoint.id,
                    "method": endpoint.method,
                    "path": endpoint.path,
                    "url": endpoint.url,
                    "vulnerability_count": len(
                        vulnerabilities
                    ),
                    "highest_priority_score": (
                        highest_score
                    ),
                    "critical_count": (
                        severity_counts["CRITICAL"]
                    ),
                    "high_count": (
                        severity_counts["HIGH"]
                    ),
                    "medium_count": (
                        severity_counts["MEDIUM"]
                    ),
                    "low_count": (
                        severity_counts["LOW"]
                    ),
                }
            )

        return endpoint_reports

    

    @staticmethod
    def _build_findings(
        vulnerabilities: List[Vulnerability],
    ) -> List[Dict[str, Any]]:

        findings = []

        sorted_vulnerabilities = sorted(
            vulnerabilities,
            key=lambda vulnerability: (
                -vulnerability.priority_score,
                -vulnerability.confidence,
            ),
        )

        for vulnerability in sorted_vulnerabilities:

            endpoint = vulnerability.endpoint

            severity = (
                vulnerability.severity.value
                if vulnerability.severity
                else None
            )

            finding = {
                "vulnerability_id": (
                    vulnerability.id
                ),

                "type": (
                    vulnerability.type
                ),

                "severity": severity,

                "priority_score": (
                    vulnerability.priority_score
                ),

                "confidence": (
                    vulnerability.confidence
                ),

                "endpoint": {
                    "endpoint_id": (
                        endpoint.id
                        if endpoint
                        else None
                    ),
                    "method": (
                        endpoint.method
                        if endpoint
                        else None
                    ),
                    "path": (
                        endpoint.path
                        if endpoint
                        else None
                    ),
                    "url": (
                        endpoint.url
                        if endpoint
                        else None
                    ),
                },

                "description": (
                    vulnerability.description
                ),

                "evidence": (
                    vulnerability.evidence
                ),

                "detected_at": (
                    ScanReportService._datetime_to_string(
                        vulnerability.detected_at
                    )
                ),
            }

            findings.append(
                finding
            )

        return findings

    
    @staticmethod
    def _build_recommendations(
        vulnerabilities: List[Vulnerability],
    ) -> List[Dict[str, Any]]:

        grouped = defaultdict(list)

        for vulnerability in vulnerabilities:

            grouped[
                vulnerability.type
            ].append(
                vulnerability
            )

        recommendations = []

        for vulnerability_type, items in (
            grouped.items()
        ):

            recommendation = (
                ScanReportService._get_recommendation(
                    vulnerability_type
                )
            )

            if recommendation is None:
                continue

            recommendation = {
                "type": vulnerability_type,
                "affected_count": len(items),
                **recommendation,
            }

            recommendations.append(
                recommendation
            )

        recommendations.sort(
            key=lambda item: item[
                "affected_count"
            ],
            reverse=True,
        )

        return recommendations

    

    @staticmethod
    def _get_recommendation(
        vulnerability_type: str,
    ) -> Dict[str, str]:

        recommendations = {

            "POSSIBLE_BOLA": {
                "title": (
                    "Enforce object-level authorization"
                ),
                "action": (
                    "Verify that the authenticated user "
                    "is authorized to access the requested "
                    "object before returning or modifying it."
                ),
            },

            "POSSIBLE_AUTHENTICATION_BYPASS": {
                "title": (
                    "Enforce authentication"
                ),
                "action": (
                    "Require valid authentication before "
                    "allowing access to protected endpoints."
                ),
            },

            "POSSIBLE_BROKEN_AUTHORIZATION": {
                "title": (
                    "Enforce authorization checks"
                ),
                "action": (
                    "Validate the user's permissions and "
                    "role before performing the requested "
                    "operation."
                ),
            },

            "POSSIBLE_SQL_INJECTION": {
                "title": (
                    "Use parameterized database queries"
                ),
                "action": (
                    "Avoid string-built SQL queries and use "
                    "parameterized queries or ORM query "
                    "parameters."
                ),
            },

            "POSSIBLE_REFLECTED_XSS": {
                "title": (
                    "Encode untrusted output"
                ),
                "action": (
                    "HTML-escape untrusted input before "
                    "placing it into an HTML response."
                ),
            },

            "POSSIBLE_SSRF": {
                "title": (
                    "Validate outbound URLs"
                ),
                "action": (
                    "Allow only approved destinations and "
                    "block private, loopback and internal "
                    "network addresses."
                ),
            },

            "POSSIBLE_MASS_ASSIGNMENT": {
                "title": (
                    "Use an explicit allow-list"
                ),
                "action": (
                    "Only accept fields that are explicitly "
                    "allowed for user-controlled updates."
                ),
            },

            "POSSIBLE_SENSITIVE_DATA_EXPOSURE": {
                "title": (
                    "Remove sensitive response fields"
                ),
                "action": (
                    "Do not return passwords, tokens, "
                    "credentials, payment data or other "
                    "sensitive values unless strictly required."
                ),
            },

            "POSSIBLE_MISSING_RATE_LIMITING": {
                "title": (
                    "Add rate limiting"
                ),
                "action": (
                    "Apply request throttling to sensitive "
                    "or abuse-prone endpoints and return "
                    "an appropriate rate-limit response."
                ),
            },

            "MISSING_SECURITY_HEADER": {
                "title": (
                    "Add security response headers"
                ),
                "action": (
                    "Configure the recommended HTTP security "
                    "headers at the API or reverse-proxy layer."
                ),
            },
        }

        return recommendations.get(
            vulnerability_type
        )

    

    @staticmethod
    def _datetime_to_string(
        value
    ):

        if value is None:
            return None

        if isinstance(
            value,
            datetime
        ):
            return value.isoformat()

        return str(value)




def generate_scan_report(
    db: Session,
    scan_id: int,
) -> Dict[str, Any]:

    return (
        ScanReportService.generate_scan_report(
            db=db,
            scan_id=scan_id,
        )
    )