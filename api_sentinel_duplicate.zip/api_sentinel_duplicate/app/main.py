from fastapi import FastAPI
from fastapi import Depends
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.api.routes.scans import router
from app.api.routes.endpoints import endpoint_router
from app.api.routes.vulnerabilities import router as vulnerability_router
from fastapi.staticfiles import StaticFiles
from app.target_api import router as target_router
from fastapi.responses import JSONResponse
from fastapi.responses import FileResponse
app = FastAPI()
app.mount(
    "/static",
    StaticFiles(directory="static"),
    name="static",
)
app.include_router(router)
app.include_router(endpoint_router)
app.include_router(vulnerability_router)
app.include_router(
    target_router
)

@app.get(
    "/target/openapi.json",
    include_in_schema=False
)
def target_openapi():

    schema = app.openapi()

    target_paths = {
        path: operations
        for path, operations in schema["paths"].items()
        if path.startswith("/target/")
    }

    for path in list(target_paths):
        new_path = path.removeprefix("/target/")
        target_paths[new_path] = target_paths.pop(path)

    target_schema = {
    "openapi": schema["openapi"],
    "info": {
        "title": "SentinelAI Test Target",
        "version": "1.0.0",
    },
    "servers": [
        {
            "url": "/target"
        }
    ],
    "paths": target_paths,
    "components": schema.get(
        "components",
        {}
    ),
}

    return JSONResponse(
        content=target_schema
    )
@app.get("/health")
def health_check():
    return {
        "status": "ok"
    }
@app.get("/db-test")
def check_db(db:Session=Depends(get_db)):
    return {
         "message": "data base connected"
    }